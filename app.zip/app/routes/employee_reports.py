from fastapi import APIRouter, HTTPException, Query, Body, Depends
from typing import Dict, Optional, List, Any
from bson import ObjectId
from datetime import datetime, timedelta
import logging
import calendar

from app.database import get_database
from app.dependencies import get_current_user
from app.routes.employees import (
    extract_user_roles, 
    has_admin_or_hr_permission, 
    make_serializable
)
from app.models.auth import UserInfo

# Configure logger
logger = logging.getLogger(__name__)

# Initialize router
employee_reports_router = APIRouter(prefix="/api/employee-reports", tags=["employee-reports"])

@employee_reports_router.get("/daily-summary", status_code=200)
async def get_daily_summary(
    date: Optional[str] = Query(None, description="Date for report (YYYY-MM-DD)"),
    current_user: UserInfo = Depends(get_current_user)
):
    """Get daily summary report (HR only)"""
    try:
        # Extract user roles
        user_dict = current_user.dict()
        user_roles = extract_user_roles(user_dict)
        
        # Check HR permission
        if not has_admin_or_hr_permission(user_roles):
            raise HTTPException(status_code=403, detail="Insufficient permissions")
        
        db = get_database()
        
        if not date:
            date = datetime.now().strftime("%Y-%m-%d")
        
        # Get attendance summary
        attendance_records = list(db.attendance.find({"date": date}))
        total_employees = db.users.count_documents({"is_active": True})
        present_today = len([r for r in attendance_records if r.get("status") == "present"])
        
        # Get leads assigned today
        try:
            date_obj = datetime.strptime(date, "%Y-%m-%d") if date else datetime.now()
            start_dt = date_obj
            end_dt = date_obj + timedelta(days=1)
        except (ValueError, TypeError):
            # Fallback to today if date parsing fails
            date_obj = datetime.now()
            start_dt = date_obj
            end_dt = date_obj + timedelta(days=1)
        
        leads_assigned_today = db.leads.count_documents({
            "created_at": {"$gte": start_dt, "$lt": end_dt}
        })
        
        # Get activities today
        activities_today = db.lead_activities.count_documents({
            "created_at": {"$gte": start_dt, "$lt": end_dt}
        })
        
        # Get follow-ups due today
        followups_today = db.lead_activities.count_documents({
            "follow_up_date": date,
            "status": {"$ne": "completed"}
        })
        
        # Department wise breakdown
        dept_attendance = {}
        for record in attendance_records:
            user = db.users.find_one({"user_id": record["user_id"]})
            if user:
                dept = user.get("department", "Unknown")
                if dept not in dept_attendance:
                    dept_attendance[dept] = {"present": 0, "total": 0}
                dept_attendance[dept]["present"] += 1 if record.get("status") == "present" else 0
        
        # Get total employees per department
        for dept in dept_attendance:
            dept_attendance[dept]["total"] = db.users.count_documents({
                "department": dept,
                "is_active": True
            })
        
        return make_serializable({
            "success": True,
            "date": date,
            "summary": {
                "total_employees": total_employees,
                "present_today": present_today,
                "attendance_rate": round((present_today / total_employees * 100), 2) if total_employees > 0 else 0,
                "leads_assigned_today": leads_assigned_today,
                "activities_today": activities_today,
                "followups_due_today": followups_today
            },
            "department_breakdown": dept_attendance
        })
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting daily summary: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to get daily summary: {str(e)}")

@employee_reports_router.get("/dashboard-stats", status_code=200)
async def get_dashboard_stats(
    current_user: UserInfo = Depends(get_current_user)
):
    """Get dashboard statistics for HR module"""
    try:
        db = get_database()
        user_dict = current_user.dict()
        current_user_id = user_dict.get("user_id") or user_dict.get("id")
        current_user_roles = extract_user_roles(user_dict)
        
        # Check if user has HR permissions
        is_hr = has_admin_or_hr_permission(current_user_roles)
        
        today = datetime.now().strftime("%Y-%m-%d")
        
        # Base query for employees
        employee_query: Dict[str, Any] = {"is_active": True}
        
        if not is_hr and current_user_id:
            # Non-HR users see limited scope
            employee_query["$or"] = [
                {"reporting_user_id": current_user_id},  # Direct reports
                {"user_id": current_user_id},  # Self
                {"reporting_user_id": {"$in": [None, ""]}},  # Top level
            ]
        
        # Get total employees count
        total_employees = db.users.count_documents(employee_query)
        
        # Get attendance stats for today
        attendance_query: Dict[str, Any] = {"date": today}
        if not is_hr and current_user_id:
            # Filter attendance based on visible employees
            visible_users = list(db.users.find(employee_query, {"user_id": 1}))
            visible_user_ids = [str(user["user_id"]) for user in visible_users if user.get("user_id")]
            if visible_user_ids:
                attendance_query["user_id"] = {"$in": visible_user_ids}
        
        present_today = db.attendance.count_documents({
            **attendance_query,
            "status": "present"
        })
        
        absent_today = total_employees - present_today
        
        # Get pending leave requests
        leave_query: Dict[str, Any] = {"status": "pending"}
        if not is_hr and current_user_id:
            visible_users = list(db.users.find(employee_query, {"user_id": 1}))
            visible_user_ids = [str(user["user_id"]) for user in visible_users if user.get("user_id")]
            
            if visible_user_ids:
                leave_query["user_id"] = {"$in": visible_user_ids}
        
        pending_leaves = db.leave_requests.count_documents(leave_query)
        
        # Get on leave today count
        today_date = datetime.now().date()
        on_leave_today = db.leave_requests.count_documents({
            **leave_query.copy(),
            "status": "approved",
            "start_date": {"$lte": today},
            "end_date": {"$gte": today}
        })
        
        stats = {
            "total_employees": total_employees,
            "present_today": present_today,
            "absent_today": absent_today,
            "pending_leaves": pending_leaves,
            "on_leave_today": on_leave_today,
            "attendance_rate": round((present_today / total_employees * 100), 2) if total_employees > 0 else 0
        }
        
        return make_serializable({
            "success": True,
            "stats": stats
        })
        
    except Exception as e:
        logger.error(f"Error getting dashboard stats: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to get dashboard stats: {str(e)}")

@employee_reports_router.get("/performance/{employee_id}", status_code=200)
async def get_employee_performance_report(
    employee_id: str,
    start_date: Optional[str] = Query(None, description="Start date (YYYY-MM-DD)"),
    end_date: Optional[str] = Query(None, description="End date (YYYY-MM-DD)"),
    current_user: UserInfo = Depends(get_current_user)
):
    """Get detailed employee performance report"""
    try:
        db = get_database()
        user_dict = current_user.dict()
        current_user_id = user_dict.get("user_id") or user_dict.get("id")
        current_user_roles = extract_user_roles(user_dict)
        
        # Check permissions - HR or the employee themselves
        is_hr = has_admin_or_hr_permission(current_user_roles)
        if not is_hr and current_user_id != employee_id:
            raise HTTPException(status_code=403, detail="Insufficient permissions")
        
        # Verify employee exists
        employee = db.users.find_one({"user_id": employee_id})
        if not employee:
            # Try with ObjectId if user_id search failed
            try:
                employee = db.users.find_one({"_id": ObjectId(employee_id)})
            except:
                pass
            
            if not employee:
                raise HTTPException(status_code=404, detail="Employee not found")
        
        # Set default date range (last 30 days)
        if not start_date:
            start_date = (datetime.now() - timedelta(days=30)).strftime("%Y-%m-%d")
        if not end_date:
            end_date = datetime.now().strftime("%Y-%m-%d")
        
        # Convert to datetime for queries
        start_dt = datetime.strptime(start_date, "%Y-%m-%d")
        end_dt = datetime.strptime(end_date, "%Y-%m-%d") + timedelta(days=1)
        
        # Leads Activity
        total_leads = db.leads.count_documents({
            "assigned_to": employee_id,
            "created_at": {"$gte": start_dt, "$lt": end_dt}
        })
        
        converted_leads = db.leads.count_documents({
            "assigned_to": employee_id,
            "status": "qualified",
            "created_at": {"$gte": start_dt, "$lt": end_dt}
        })
        
        # Activity breakdown
        activities = list(db.lead_activities.find({
            "created_by": employee_id,
            "created_at": {"$gte": start_dt, "$lt": end_dt}
        }))
        
        activity_breakdown = {}
        for activity in activities:
            activity_type = activity.get("activity_type", "unknown")
            activity_breakdown[activity_type] = activity_breakdown.get(activity_type, 0) + 1
        
        # Attendance metrics
        attendance_records = list(db.attendance.find({
            "user_id": employee_id,
            "date": {"$gte": start_date, "$lte": end_date}
        }))
        
        present_days = sum(1 for record in attendance_records if record.get("status") == "present")
        total_working_hours = sum(record.get("working_hours", 0) for record in attendance_records)
        
        performance_data = {
            "employee_id": employee_id,
            "employee_name": employee.get("full_name", employee.get("username")),
            "period": {"start_date": start_date, "end_date": end_date},
            "leads_metrics": {
                "total_leads": total_leads,
                "converted_leads": converted_leads,
                "conversion_rate": round((converted_leads / total_leads * 100), 2) if total_leads > 0 else 0
            },
            "activity_metrics": {
                "total_activities": len(activities),
                "activity_breakdown": activity_breakdown,
                "avg_activities_per_day": round(len(activities) / len(attendance_records), 2) if attendance_records else 0
            },
            "attendance_metrics": {
                "present_days": present_days,
                "total_working_hours": round(total_working_hours, 1),
                "avg_hours_per_day": round(total_working_hours / present_days, 1) if present_days > 0 else 0
            }
        }
        
        return make_serializable({
            "success": True,
            "data": performance_data
        })
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting employee performance report: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to get employee performance report: {str(e)}")

@employee_reports_router.get("/calendar/attendance/{employee_id}", status_code=200)
async def get_attendance_calendar(
    employee_id: str,
    month: int = Query(..., description="Month (1-12)"),
    year: int = Query(..., description="Year"),
    current_user: UserInfo = Depends(get_current_user)
):
    """Get attendance calendar for employee"""
    try:
        db = get_database()
        user_dict = current_user.dict()
        current_user_id = user_dict.get("user_id") or user_dict.get("id")
        current_user_roles = extract_user_roles(user_dict)
        
        # Check permissions
        is_hr = has_admin_or_hr_permission(current_user_roles)
        if not is_hr and current_user_id != employee_id:
            raise HTTPException(status_code=403, detail="Insufficient permissions")
        
        # Verify employee exists
        employee = db.users.find_one({"user_id": employee_id})
        if not employee:
            # Try with ObjectId if user_id search failed
            try:
                employee = db.users.find_one({"_id": ObjectId(employee_id)})
            except:
                pass
                
            if not employee:
                raise HTTPException(status_code=404, detail="Employee not found")
        
        # Create date range for the month
        start_date = datetime(year, month, 1)
        if month == 12:
            end_date = datetime(year + 1, 1, 1) - timedelta(days=1)
        else:
            end_date = datetime(year, month + 1, 1) - timedelta(days=1)
        
        date_start_str = start_date.strftime("%Y-%m-%d")
        date_end_str = end_date.strftime("%Y-%m-%d")
        
        # Get attendance records
        attendance_records = list(db.attendance.find({
            "user_id": employee_id,
            "date": {"$gte": date_start_str, "$lte": date_end_str}
        }))
        
        # Get leave records
        leave_records = list(db.leave_requests.find({
            "user_id": employee_id,
            "status": "approved",
            "start_date": {"$lte": date_end_str},
            "end_date": {"$gte": date_start_str}
        }))
        
        # Build calendar data
        calendar_data = {}
        
        # Add attendance data
        for record in attendance_records:
            date_key = record["date"]
            calendar_data[date_key] = {
                "type": "attendance",
                "status": record.get("status", "unknown"),
                "checkin_time": record.get("checkin_time"),
                "checkout_time": record.get("checkout_time"),
                "working_hours": record.get("working_hours", 0)
            }
        
        # Add leave data
        for leave in leave_records:
            current_date = datetime.strptime(leave["start_date"], "%Y-%m-%d")
            end_leave_date = datetime.strptime(leave["end_date"], "%Y-%m-%d")
            
            while current_date <= end_leave_date:
                if start_date <= current_date <= end_date:
                    date_key = current_date.strftime("%Y-%m-%d")
                    calendar_data[date_key] = {
                        "type": "leave",
                        "leave_type": leave.get("leave_type", "unknown"),
                        "reason": leave.get("reason", "")
                    }
                current_date += timedelta(days=1)
        
        # Add weekend markers
        current_date = start_date
        while current_date <= end_date:
            date_key = current_date.strftime("%Y-%m-%d")
            if current_date.weekday() >= 5 and date_key not in calendar_data:  # Saturday = 5, Sunday = 6
                calendar_data[date_key] = {
                    "type": "weekend"
                }
            current_date += timedelta(days=1)
        
        return make_serializable({
            "success": True,
            "calendar_data": calendar_data,
            "month": month,
            "year": year,
            "employee_name": employee.get("full_name", employee.get("username"))
        })
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting attendance calendar: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to get attendance calendar: {str(e)}")