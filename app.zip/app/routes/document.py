from fastapi import APIRouter, File, UploadFile, HTTPException, Depends, Form
from typing import List, Optional
from datetime import datetime
from app.database.schemas.document_schema import DocumentModel, DocumentCreate, DocumentBase
from app.database import document_collection
import shutil
import os, re

document_router = APIRouter(prefix="/api/documents", tags=["documents"])

UPLOAD_DIR = "uploaded_pdfs"
os.makedirs(UPLOAD_DIR, exist_ok=True)

@document_router.post("/upload", response_model=DocumentModel)
async def upload_document(
    type: str = Form(...),
    generated_for: str = Form(...),
    linked_lead: Optional[str] = Form(None),
    linked_franchise: Optional[str] = Form(None),
    linked_invoice: Optional[str] = Form(None),
    description: Optional[str] = Form(None),
    status: Optional[str] = Form("pending"),
    uploaded_by: Optional[str] = Form(None),
    uploaded_by_id: Optional[str] = Form(None),
    file: UploadFile = File(...),
    collection=Depends(document_collection)
):
    # --- Sanitize and construct new filename ---
    safe_name = re.sub(r'[^A-Za-z0-9_-]', '_', generated_for)
    # Optionally add date/time for uniqueness:
    date_str = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename_with_ext = file.filename or "document.pdf"
    ext = os.path.splitext(filename_with_ext)[-1] or ".pdf"
    filename = f"{safe_name}_{date_str}{ext}"

    file_path = os.path.join(UPLOAD_DIR, filename)
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    pdf_url = f"/{UPLOAD_DIR}/{filename}"

    # Ensure uploaded_by is populated even if not provided
    if not uploaded_by and uploaded_by_id:
        # Try to fetch user name from database if only ID is provided
        try:
            from app.database import users_collection
            user_doc = users_collection().find_one({"$or": [{"_id": uploaded_by_id}, {"id": uploaded_by_id}, {"user_id": uploaded_by_id}]})
            if user_doc:
                uploaded_by = user_doc.get("full_name") or user_doc.get("username") or user_doc.get("email") or uploaded_by_id
        except Exception:
            # If we can't fetch user data, use the ID as fallback
            uploaded_by = uploaded_by_id
    elif not uploaded_by and not uploaded_by_id:
        # If neither is provided, use generated_for as fallback
        uploaded_by = f"User {generated_for}"
    
    doc = {
        "type": type,
        "generated_for": generated_for,
        "pdf_url": pdf_url,
        "timestamp": datetime.now(),
        "linked_lead": linked_lead,
        "linked_franchise": linked_franchise,
        "linked_invoice": linked_invoice,
        "description": description,
        "status": status,  # pending, approved, rejected, resubmit
        "uploaded_by": uploaded_by or f"User {generated_for}",
        "uploaded_by_id": uploaded_by_id or generated_for,
        "hr_comments": None,
        "reviewed_by": None,
        "reviewed_at": None,
    }
    result = collection.insert_one(doc)
    doc["id"] = str(result.inserted_id)
    return doc

@document_router.post("/generate", response_model=DocumentModel)
async def generate_document(
    req: DocumentCreate,
    collection=Depends(document_collection)
):
    safe_name = re.sub(r'[^A-Za-z0-9_-]', '_', req.generated_for)
    pdf_url = f"/{UPLOAD_DIR}/{safe_name}.pdf"

    doc = {
        "type": req.type,
        "generated_for": req.generated_for,
        "template_data": req.template_data,
        "pdf_url": pdf_url,
        "timestamp": datetime.now(),
        "linked_lead": req.linked_lead,
        "linked_franchise": req.linked_franchise,
        "linked_invoice": req.linked_invoice,
    }
    result = collection.insert_one(doc)
    doc["id"] = str(result.inserted_id)
    return DocumentModel(**doc)

# --- List & Search Documents ---
@document_router.get("/", response_model=List[DocumentModel])
async def list_documents(
    type: Optional[str] = None,
    generated_for: Optional[str] = None,
    linked_lead: Optional[str] = None,
    linked_franchise: Optional[str] = None,
    linked_invoice: Optional[str] = None,
    status: Optional[str] = None,
    collection=Depends(document_collection)
):
    query = {}
    if type: query["type"] = type
    if generated_for: query["generated_for"] = generated_for
    if linked_lead: query["linked_lead"] = linked_lead
    if linked_franchise: query["linked_franchise"] = linked_franchise
    if linked_invoice: query["linked_invoice"] = linked_invoice
    if status: query["status"] = status

    docs = list(collection.find(query).sort("timestamp", -1))  # Sort by newest first
    for d in docs:
        d["id"] = str(d.pop("_id"))
    return docs


# --- HR Review Endpoints ---
@document_router.patch("/review/{document_id}")
async def review_document(
    document_id: str,
    status: str = Form(...),  # approved, rejected, resubmit
    hr_comments: Optional[str] = Form(None),
    reviewed_by: str = Form(...),
    collection=Depends(document_collection)
):
    """HR endpoint to review and approve/reject documents"""
    from bson import ObjectId
    
    try:
        update_data = {
            "status": status,
            "hr_comments": hr_comments,
            "reviewed_by": reviewed_by,
            "reviewed_at": datetime.now()
        }
        
        result = collection.update_one(
            {"_id": ObjectId(document_id)},
            {"$set": update_data}
        )
        
        if result.modified_count == 0:
            raise HTTPException(status_code=404, detail="Document not found")
        
        updated_doc = collection.find_one({"_id": ObjectId(document_id)})
        updated_doc["id"] = str(updated_doc.pop("_id"))
        
        return {"success": True, "message": f"Document {status}", "document": updated_doc}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@document_router.get("/pending", response_model=List[DocumentModel])
async def get_pending_documents(
    collection=Depends(document_collection)
):
    """Get all documents pending HR review"""
    docs = list(collection.find({"status": "pending"}).sort("timestamp", -1))
    for d in docs:
        d["id"] = str(d.pop("_id"))
    return docs

