from fastapi import APIRouter, HTTPException, Depends, Header, Request, status, Body
from pydantic import BaseModel
import base64
import aiohttp
from aiohttp import ClientError, ClientResponseError, ClientConnectorError
from jwt.exceptions import PyJWTError
from app.utils.gmail_token_refresh import fetch_gmail_messages
from jose import JWTError, jwt
from app.dependencies import get_current_user
from app.utils.gmail_token_refresh import send_gmail_message, refresh_google_token_for_user_id
from app.database.repositories.user_repository import UserRepository
import logging
from typing import List, Dict, Any
from app.utils.gmail_token_refresh import refresh_google_token_for_user, reply_to_gmail_message, forward_gmail_message
from app.models.auth import UserInfo
import logging
import json
from datetime import datetime

# Define constants at the top
logger = logging.getLogger(__name__)
GMAIL_API_BASE = "https://gmail.googleapis.com/gmail/v1/users/me"
GMAIL_API_URL = "https://gmail.googleapis.com/gmail/v1/users/me/messages"

email_router = APIRouter(prefix="/api" , tags=["Gmail"])

class EmailRequest(BaseModel):
    To: str
    Subject: str
    Compose_email_body: str

def format_time(dt_str: str):
    """Converts ISO datetime string to readable format"""
    try:
        dt = datetime.fromisoformat(dt_str)
        return dt.strftime("%Y-%m-%d %H:%M:%S")
    except Exception as e:
        logger.warning(f"Error formatting time string {dt_str}: {e}")
        # Return a default formatted time
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

async def modify_gmail_labels(access_token: str, id: str, add_labels=[], remove_labels=[]):
    # Validate the message ID to prevent reserved keywords from being used
    reserved_keywords = ['spam', 'drafts', 'trash', 'inbox', 'sent', 'starred']
    if id.lower() in reserved_keywords:
        raise HTTPException(status_code=400, detail=f"Invalid message ID: '{id}' is a reserved keyword")
        
    async with aiohttp.ClientSession() as session:
        url = f"https://gmail.googleapis.com/gmail/v1/users/me/messages/{id}/modify"
        headers = {"Authorization": f"Bearer {access_token}", "Content-Type": "application/json"}
        payload = {"addLabelIds": add_labels, "removeLabelIds": remove_labels}
        async with session.post(url, headers=headers, json=payload) as response:
            if response.status != 200:
                error_text = await response.text()
                raise HTTPException(status_code=response.status, detail=error_text)
            return await response.json()

import asyncio
from fastapi import HTTPException, Request
import jwt

# Python Backend Code (email_router.py)

@email_router.get("/lead/inbox", response_model=Dict[str, Any])
async def get_gmail_inbox(current_user=Depends(get_current_user)):
    try:
        logger.info(f"[DEBUG] get_gmail_inbox called with current_user: {type(current_user)} {current_user}")
        # Ensure current_user is properly handled
        user_email = None
        user_id = None
        if isinstance(current_user, UserInfo):
            user_email = current_user.email
            user_id = current_user.id
        elif isinstance(current_user, dict):
            user_email = current_user.get('email') or current_user.get('user_email')
            user_id = current_user.get('id') or current_user.get('user_id')
        else:
            user_email = str(current_user)
            user_id = str(current_user)
            
        if not user_email:
            raise HTTPException(status_code=400, detail="Unable to determine user email.")
            
        if not user_id:
            raise HTTPException(status_code=400, detail="Unable to determine user ID.")
            
        logger.info(f"Fetching inbox for user_id: {user_id}, email: {user_email}")
        access_token, gmail_email = await refresh_google_token_for_user_id(user_id)
        messages = await fetch_gmail_messages(access_token, max_results=50)
        
        # Format messages to match frontend expectations
        formatted_messages = []
        for message in messages:
            # Determine initial folder based on starred status
            initial_folder = 'Starred' if message.get('isStarred') else 'Inbox'
            
            formatted_message = {
                "id": message.get("id"),
                "sender": message.get("from", "Unknown Sender"),
                "subject": message.get("subject", "(No Subject)"),
                "snippet": message.get("snippet", "No preview available."),
                "time": message.get("date"),
                "read": not message.get("isUnread", False),  # Invert isUnread to get read status
                "folder": initial_folder,
                "isStarred": message.get("isStarred", False)
            }
            formatted_messages.append(formatted_message)
        
        return {"success": True, "messages": formatted_messages, "count": len(formatted_messages)}
        
    except ClientResponseError as e:
        # 4xx or 5xx response from Gmail API
        logger.error(f"Gmail API error fetching inbox: {e.message}")
        raise HTTPException(status_code=e.status, detail=f"Gmail API error: {e.message}")
    except Exception as e:
        logger.error(f"Internal server error fetching inbox: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

@email_router.get("/sent-emails", response_model=Dict[str, Any])
async def get_gmail_sent_emails(current_user=Depends(get_current_user)):
    try:
        logger.info(f"[DEBUG] get_gmail_sent_emails called with current_user: {type(current_user)} {current_user}")
        # Ensure current_user is properly handled
        user_email = None
        user_id = None
        if isinstance(current_user, UserInfo):
            user_email = current_user.email
            user_id = current_user.id
        elif isinstance(current_user, dict):
            user_email = current_user.get('email') or current_user.get('user_email')
            user_id = current_user.get('id') or current_user.get('user_id')
        else:
            user_email = str(current_user)
            user_id = str(current_user)
            
        if not user_email:
            raise HTTPException(status_code=400, detail="Unable to determine user email.")
            
        if not user_id:
            raise HTTPException(status_code=400, detail="Unable to determine user ID.")
            
        logger.info(f"Fetching sent emails for user_id: {user_id}, email: {user_email}")
        access_token, gmail_email = await refresh_google_token_for_user_id(user_id)
        headers = {"Authorization": f"Bearer {access_token}"}
        
        # 💡 Gmail API URL to list messages with the 'SENT' label
        # We also ask for maxResults=100 (or whatever limit you need)
        list_url = "https://gmail.googleapis.com/gmail/v1/users/me/messages?labelIds=SENT&maxResults=50" 
        
        async with aiohttp.ClientSession() as session:
            async with session.get(list_url, headers=headers) as list_response:
                list_response.raise_for_status()
                message_list = await list_response.json()

                if "messages" not in message_list:
                    return {"success": True, "messages": [], "message": "No sent emails found", "count": 0}

                message_ids = [msg["id"] for msg in message_list["messages"]]
                
                sent_messages = []
                
                # Fetch details for each sent message
                for msg_id in message_ids:
                    try:
                        # Validate the message ID to prevent reserved keywords from being used
                        reserved_keywords = ['spam', 'drafts', 'trash', 'inbox', 'sent', 'starred']
                        if msg_id.lower() in reserved_keywords:
                            logger.warning(f"Skipping message with reserved keyword ID: {msg_id}")
                            continue
                            
                        # Get message details
                        detail_url = f"https://gmail.googleapis.com/gmail/v1/users/me/messages/{msg_id}"
                        async with session.get(detail_url, headers=headers) as detail_response:
                            if detail_response.status == 200:
                                msg_data = await detail_response.json()
                                
                                # Extract headers
                                payload = msg_data.get("payload", {})
                                headers_list = payload.get("headers", [])
                                
                                subject = next((h["value"] for h in headers_list if h["name"] == "Subject"), "No Subject")
                                sender = next((h["value"] for h in headers_list if h["name"] == "From"), "Me")
                                recipient = next((h["value"] for h in headers_list if h["name"] == "To"), "Unknown Recipient")
                                
                                # Get snippet
                                snippet = msg_data.get("snippet", "No preview available")
                                
                                # Get internal date and format it
                                internal_date = msg_data.get("internalDate")
                                if internal_date:
                                    time_str = format_time(datetime.fromtimestamp(int(internal_date)/1000).isoformat())
                                else:
                                    time_str = format_time(datetime.now().isoformat())
                                
                                # Check if starred
                                label_ids = msg_data.get("labelIds", [])
                                is_starred = "STARRED" in label_ids
                                is_unread = "UNREAD" in label_ids
                                
                                sent_messages.append({
                                    "id": msg_id,
                                    "sender": sender,
                                    "recipient": recipient,
                                    "subject": subject,
                                    "snippet": snippet,
                                    "time": time_str,
                                    "read": True,
                                    "folder": "Sent",
                                    "isStarred": is_starred,
                                    "isUnread": is_unread
                                })
                            else:
                                # Fallback if we can't get details
                                sent_messages.append({
                                    "id": msg_id,
                                    "sender": "Me",
                                    "recipient": "Unknown",
                                    "subject": "Fetching subject...",
                                    "snippet": "Message details unavailable.",
                                    "time": format_time(datetime.now().isoformat()),
                                    "read": True,
                                    "folder": "Sent",
                                    "isStarred": False,
                                    "isUnread": False
                                })
                    except Exception as detail_error:
                        # Fallback if we can't get details
                        sent_messages.append({
                            "id": msg_id,
                            "sender": "Me",
                            "recipient": "Unknown",
                            "subject": "Fetching subject...",
                            "snippet": "Message details unavailable.",
                            "time": format_time(datetime.now().isoformat()),
                            "read": True,
                            "folder": "Sent",
                            "isStarred": False,
                            "isUnread": False
                        })
                    
                return {"success": True, "messages": sent_messages, "count": len(sent_messages)}

    except ClientResponseError as e:
        # 4xx or 5xx response from Gmail API
        logger.error(f"Gmail API error fetching sent mail: {e.message}")
        raise HTTPException(status_code=e.status, detail=f"Gmail API error: {e.message}")
    except Exception as e:
        logger.error(f"Internal server error fetching sent mail: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

# --- FIX 2: Placeholder for the actual email sending logic (POST) ---

@email_router.post("/send-email")
async def send_new_email(email_data: Dict[str, str], current_user=Depends(get_current_user)):
    try:
        # Ensure current_user is properly handled
        user_email = None
        user_id = None
        if isinstance(current_user, UserInfo):
            user_email = current_user.email
            user_id = current_user.id
        elif isinstance(current_user, dict):
            user_email = current_user.get('email') or current_user.get('user_email')
            user_id = current_user.get('id') or current_user.get('user_id')
        else:
            user_email = str(current_user)
            user_id = str(current_user)
            
        if not user_email:
            raise HTTPException(status_code=400, detail="Unable to determine user email.")
        
        if not user_id:
            raise HTTPException(status_code=400, detail="Unable to determine user ID.")
        
        # 1. Get token
        access_token, gmail_email = await refresh_google_token_for_user_id(user_id)
        headers = {"Authorization": f"Bearer {access_token}"}
        
        # 2. Construct raw email content (MIME format)
        import base64
        from email.mime.text import MIMEText
        from email.mime.multipart import MIMEMultipart
        
        # Create message
        message = MIMEMultipart()
        to_email = email_data.get("To", "")
        if to_email:
            message["to"] = to_email
        subject = email_data.get("Subject", "")
        if subject:
            message["subject"] = subject
            
        body = email_data.get("Compose_email_body", "")
        if body:
            message.attach(MIMEText(body, "plain"))
        
        # Encode message
        raw_message = base64.urlsafe_b64encode(message.as_bytes()).decode("utf-8")
        
        # 3. Call Gmail API's send endpoint
        send_url = "https://gmail.googleapis.com/gmail/v1/users/me/messages/send"
        
        async with aiohttp.ClientSession() as session:
            async with session.post(
                send_url,
                headers=headers,
                json={"raw": raw_message}
            ) as response:
                response.raise_for_status()
                result = await response.json()
        
        # If successful:
        return {"success": True, "message": "Email successfully sent.", "id": result.get("id")}
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to send email: {str(e)}")

# Helper: Star or unstar a Gmail message

import logging
from fastapi import APIRouter, Depends, HTTPException, status

logger = logging.getLogger(__name__)
GMAIL_API_BASE = "https://gmail.googleapis.com/gmail/v1/users/me"
GMAIL_API_URL = "https://gmail.googleapis.com/gmail/v1/users/me/messages"

@email_router.get("/email/drafts")
async def get_gmail_drafts(current_user=Depends(get_current_user)):
    try:
        logger.info(f"[DEBUG] get_gmail_drafts called with current_user: {type(current_user)} {current_user}")
        # Ensure current_user is properly handled
        user_email = None
        user_id = None
        if isinstance(current_user, UserInfo):
            user_email = current_user.email
            user_id = current_user.id
        elif isinstance(current_user, dict):
            user_email = current_user.get('email') or current_user.get('user_email')
            user_id = current_user.get('id') or current_user.get('user_id')
        else:
            user_email = str(current_user)
            user_id = str(current_user)
            
        if not user_email:
            raise HTTPException(status_code=400, detail="Unable to determine user email.")
            
        if not user_id:
            raise HTTPException(status_code=400, detail="Unable to determine user ID.")
            
        logger.info(f"Fetching drafts for user_id: {user_id}, email: {user_email}")
        access_token, gmail_email = await refresh_google_token_for_user_id(user_id)
        if not access_token:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Token refresh failed or missing.")
        headers = {"Authorization": f"Bearer {access_token}"}
        async with aiohttp.ClientSession() as session:
            logger.info("Calling Gmail API for drafts...")
            # Use the correct Gmail API endpoint for drafts
            async with session.get(
                f"{GMAIL_API_BASE}/drafts",
                headers=headers
            ) as response:
                response_text = await response.text()
                logger.debug(f"Raw Gmail response: {response_text[:500]}")
                
                # Check if response is successful before trying to parse JSON
                if response.status != 200:
                    logger.error(f"Gmail API Drafts error: {response.status} - {response_text}")
                    raise HTTPException(
                        status_code=response.status, 
                        detail=f"Gmail API error: {response.status} - {response_text}"
                    )
                
                response.raise_for_status()
                try:
                    data = await response.json()
                except Exception as e:
                    logger.exception("Error parsing Gmail API drafts response as JSON")
                    raise HTTPException(
                        status_code=500,
                        detail=f"JSON parse error: {type(e).__name__}: {str(e)} | Raw: {response_text[:250]}"
                    )
                
                # Process the draft messages to match the frontend expectations
                draft_messages = []
                if "drafts" in data and data["drafts"]:
                    for draft in data["drafts"]:
                        draft_id = draft["id"]
                        # Validate the draft ID to prevent reserved keywords from being used
                        # Only log a warning and skip the draft instead of raising an error
                        reserved_keywords = ['spam', 'drafts', 'trash', 'inbox', 'sent', 'starred']
                        if draft_id.lower() in reserved_keywords:
                            logger.warning(f"Skipping draft with reserved keyword ID: {draft_id}")
                            continue
                            
                        # Get full draft details
                        detail_url = f"https://gmail.googleapis.com/gmail/v1/users/me/drafts/{draft_id}"
                        async with session.get(detail_url, headers=headers) as detail_response:
                            if detail_response.status == 200:
                                draft_data = await detail_response.json()
                                # Extract message from draft
                                message = draft_data.get("message", {})
                                
                                # Extract headers
                                payload = message.get("payload", {})
                                headers_list = payload.get("headers", [])
                                
                                subject = next((h["value"] for h in headers_list if h["name"] == "Subject"), "(No Subject)")
                                sender = next((h["value"] for h in headers_list if h["name"] == "From"), "Me (Draft)")
                                
                                # Get snippet
                                snippet = message.get("snippet", "No preview available")
                                
                                # Get internal date and format it
                                internal_date = message.get("internalDate")
                                if internal_date:
                                    time_str = format_time(datetime.fromtimestamp(int(internal_date)/1000).isoformat())
                                else:
                                    time_str = format_time(datetime.now().isoformat())
                                
                                # Check if starred and unread
                                label_ids = message.get("labelIds", [])
                                is_starred = "STARRED" in label_ids
                                is_unread = "UNREAD" in label_ids
                                
                                draft_messages.append({
                                    "id": draft_id,
                                    "sender": sender,
                                    "subject": subject,
                                    "snippet": snippet,
                                    "time": time_str,
                                    "read": True,
                                    "folder": "Drafts",
                                    "isStarred": is_starred,
                                    "isUnread": is_unread
                                })
                
                return {
                    "success": True,
                    "drafts": draft_messages
                }
    except ClientResponseError as e:
        logger.warning(f"Gmail API Drafts error ({e.status}): {e.message}")
        raise HTTPException(status_code=e.status, detail=f"Gmail API error: {e.message}")
    except ClientConnectorError:
        logger.error("Could not connect to Gmail API (Drafts).")
        raise HTTPException(status_code=503, detail="Could not connect to Gmail API.")
    except Exception as e:
        logger.exception("CRITICAL ERROR - DRAFTS: Unhandled exception.")
        raise HTTPException(status_code=500, detail=f"Internal Server Error: {type(e).__name__} - {str(e)}")

@email_router.get("/email/spam")
async def get_gmail_spam(current_user=Depends(get_current_user)):
    try:
        logger.info(f"[DEBUG] get_gmail_spam called with current_user: {type(current_user)} {current_user}")
        # Ensure current_user is properly handled
        user_email = None
        user_id = None
        if isinstance(current_user, UserInfo):
            user_email = current_user.email
            user_id = current_user.id
        elif isinstance(current_user, dict):
            user_email = current_user.get('email') or current_user.get('user_email')
            user_id = current_user.get('id') or current_user.get('user_id')
        else:
            user_email = str(current_user)
            user_id = str(current_user)
            
        if not user_email:
            raise HTTPException(status_code=400, detail="Unable to determine user email.")
            
        if not user_id:
            raise HTTPException(status_code=400, detail="Unable to determine user ID.")
            
        logger.info(f"Fetching spam for user_id: {user_id}, email: {user_email}")
        access_token, gmail_email = await refresh_google_token_for_user_id(user_id)
        if not access_token:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Token refresh failed or missing.")

        headers = {"Authorization": f"Bearer {access_token}"}
        async with aiohttp.ClientSession() as session:
            logger.info("Calling Gmail API for spam...")
            # Use the correct parameter format for labelIds - it should be a list
            params = {"labelIds": ["SPAM"]}
            async with session.get(
                f"{GMAIL_API_BASE}/messages",
                params=params,
                headers=headers
            ) as response:
                response_text = await response.text()
                logger.debug(f"Raw Gmail response: {response_text}")
                
                # Check if response is successful before trying to parse JSON
                if response.status != 200:
                    logger.error(f"Gmail API Spam error: {response.status} - {response_text}")
                    raise HTTPException(
                        status_code=response.status, 
                        detail=f"Gmail API error: {response.status} - {response_text}"
                    )
                
                response.raise_for_status()
                try:
                    data = await response.json()
                except Exception as e:
                    logger.exception("Error parsing Gmail API spam response as JSON")
                    raise HTTPException(
                        status_code=500,
                        detail=f"JSON parse error: {type(e).__name__} - {str(e)}"
                    )
                
                # Process the spam messages to match the frontend expectations
                spam_messages = []
                if "messages" in data and data["messages"]:
                    for msg in data["messages"]:
                        msg_id = msg["id"]
                        # Validate the message ID to prevent reserved keywords from being used
                        # Only log a warning and skip the message instead of raising an error
                        reserved_keywords = ['spam', 'drafts', 'trash', 'inbox', 'sent', 'starred']
                        if msg_id.lower() in reserved_keywords:
                            logger.warning(f"Skipping message with reserved keyword ID: {msg_id}")
                            continue
                            
                        # Get full message details
                        detail_url = f"https://gmail.googleapis.com/gmail/v1/users/me/messages/{msg_id}?format=full"
                        async with session.get(detail_url, headers=headers) as detail_response:
                            if detail_response.status == 200:
                                msg_data = await detail_response.json()
                                
                                # Extract headers
                                payload = msg_data.get("payload", {})
                                headers_list = payload.get("headers", [])
                                
                                subject = next((h["value"] for h in headers_list if h["name"] == "Subject"), "(No Subject)")
                                sender = next((h["value"] for h in headers_list if h["name"] == "From"), "Unknown Sender")
                                
                                # Get snippet
                                snippet = msg_data.get("snippet", "This message was identified as spam.")
                                
                                # Get internal date and format it
                                internal_date = msg_data.get("internalDate")
                                if internal_date:
                                    time_str = format_time(datetime.fromtimestamp(int(internal_date)/1000).isoformat())
                                else:
                                    time_str = format_time(datetime.now().isoformat())
                                
                                # Check if starred and unread
                                label_ids = msg_data.get("labelIds", [])
                                is_starred = "STARRED" in label_ids
                                is_unread = "UNREAD" in label_ids
                                
                                spam_messages.append({
                                    "id": msg_id,
                                    "sender": sender,
                                    "subject": subject,
                                    "snippet": snippet,
                                    "time": time_str,
                                    "read": True,
                                    "folder": "Spam",
                                    "isStarred": is_starred,
                                    "isUnread": is_unread
                                })
                
                return {
                    "success": True,
                    "spam": spam_messages
                }
    except ClientResponseError as e:
        logger.warning(f"Gmail API Spam error ({e.status}): {e.message}")
        raise HTTPException(status_code=e.status, detail=f"Gmail API error: {e.message}")
    except ClientConnectorError:
        logger.error("Could not connect to Gmail API (Spam).")
        raise HTTPException(status_code=503, detail="Could not connect to Gmail API.")
    except Exception as e:
        logger.exception("CRITICAL ERROR - SPAM: Unhandled exception.")
        raise HTTPException(status_code=500, detail=f"Internal Server Error: {type(e).__name__} - {str(e)}")


@email_router.post("/trash/{message_id}")
async def move_email_to_trash(message_id: str, current_user=Depends(get_current_user)):
    try:
        # Ensure current_user is properly handled
        user_email = None
        user_id = None
        if isinstance(current_user, UserInfo):
            user_email = current_user.email
            user_id = current_user.id
        elif isinstance(current_user, dict):
            user_email = current_user.get('email') or current_user.get('user_email')
            user_id = current_user.get('id') or current_user.get('user_id')
        else:
            user_email = str(current_user)
            user_id = str(current_user)
            
        if not user_email:
            raise HTTPException(status_code=400, detail="Unable to determine user email.")
            
        if not user_id:
            raise HTTPException(status_code=400, detail="Unable to determine user ID.")
        
        # Validate the message ID to prevent reserved keywords from being used
        reserved_keywords = ['spam', 'drafts', 'trash', 'inbox', 'sent', 'starred']
        if message_id.lower() in reserved_keywords:
            raise HTTPException(status_code=400, detail=f"Invalid message ID: '{message_id}' is a reserved keyword")
        
        # Get fresh access token
        access_token, gmail_email = await refresh_google_token_for_user_id(user_id)
        headers = {"Authorization": f"Bearer {access_token}"}
        
        # Use aiohttp instead of httpx
        # Fix the URL format - it should be /gmail/v1/users/me/messages/{id}/trash
        url = f"{GMAIL_API_BASE}/messages/{message_id}/trash"
        
        logger.info(f"Moving message {message_id} to trash for user_id {user_id}, email {user_email}")
        
        async with aiohttp.ClientSession() as session:
            async with session.post(url, headers=headers) as response:
                response_text = await response.text()
                logger.info(f"Gmail API Trash response for message {message_id}: {response.status} - {response_text}")
                
                # Check if response is successful
                if response.status != 200:
                    logger.error(f"Gmail API Trash error: {response.status} - {response_text}")
                    raise HTTPException(
                        status_code=response.status, 
                        detail=f"Gmail API error: {response.status} - {response_text}"
                    )
                
                result = await response.json()
                
                # Add a small delay to allow Gmail API to process the label change
                await asyncio.sleep(0.5)
                
                return {"success": True, "message": f"Email {message_id} moved to Trash successfully", "data": result}

    except HTTPException:
        raise
    except Exception as e:
        logger.exception("CRITICAL ERROR - MOVE TO TRASH: Unhandled exception.")
        raise HTTPException(status_code=500, detail=f"Internal Server Error: {type(e).__name__} - {str(e)}")


@email_router.post("/email/trash")
async def move_emails_to_trash(email_data: Dict[str, Any], current_user=Depends(get_current_user)):
    try:
        # Ensure current_user is properly handled
        user_email = None
        user_id = None
        if isinstance(current_user, UserInfo):
            user_email = current_user.email
            user_id = current_user.id
        elif isinstance(current_user, dict):
            user_email = current_user.get('email') or current_user.get('user_email')
            user_id = current_user.get('id') or current_user.get('user_id')
        else:
            user_email = str(current_user)
            user_id = str(current_user)
            
        if not user_email:
            raise HTTPException(status_code=400, detail="Unable to determine user email.")
            
        if not user_id:
            raise HTTPException(status_code=400, detail="Unable to determine user ID.")
        
        # Get message IDs from request data
        message_ids = email_data.get("message_ids", [])
        if not message_ids:
            # If no array provided, check for single message_id
            single_id = email_data.get("message_id")
            if single_id:
                message_ids = [single_id]
            else:
                raise HTTPException(status_code=400, detail="No message IDs provided")
        
        # Validate message IDs to prevent reserved keywords from being used
        reserved_keywords = ['spam', 'drafts', 'trash', 'inbox', 'sent', 'starred']
        for message_id in message_ids:
            if message_id.lower() in reserved_keywords:
                raise HTTPException(status_code=400, detail=f"Invalid message ID: '{message_id}' is a reserved keyword")
        
        # Get fresh access token
        access_token, gmail_email = await refresh_google_token_for_user_id(user_id)
        headers = {"Authorization": f"Bearer {access_token}"}
        
        results = []
        errors = []
        
        logger.info(f"Moving {len(message_ids)} messages to trash for user_id {user_id}, email {user_email}")
        
        # Move each email to trash
        for message_id in message_ids:
            try:
                # Fix the URL format - it should be /gmail/v1/users/me/messages/{id}/trash
                url = f"{GMAIL_API_BASE}/messages/{message_id}/trash"
                async with aiohttp.ClientSession() as session:
                    async with session.post(url, headers=headers) as response:
                        response_text = await response.text()
                        logger.info(f"Gmail API Trash response for message {message_id}: {response.status}")
                        
                        if response.status == 200:
                            result = await response.json()
                            results.append({"message_id": message_id, "success": True, "data": result})
                        else:
                            logger.error(f"Gmail API Trash error for message {message_id}: {response.status} - {response_text}")
                            errors.append({"message_id": message_id, "error": f"Gmail API error: {response.status}"})
            except Exception as e:
                logger.exception(f"Error moving message {message_id} to trash")
                errors.append({"message_id": message_id, "error": str(e)})
        
        # Add a small delay to allow Gmail API to process all label changes
        if len(results) > 0:
            await asyncio.sleep(1.0)
        
        logger.info(f"Completed moving emails to trash: {len(results)} successful, {len(errors)} errors")
        
        # After moving emails to trash, fetch the updated trash list to ensure consistency
        try:
            # Fetch updated trash messages
            list_url = f"{GMAIL_API_BASE}/messages?maxResults=200"
            async with aiohttp.ClientSession() as session:
                async with session.get(list_url, headers=headers) as list_response:
                    if list_response.status == 200:
                        message_list = await list_response.json()
                        if "messages" in message_list and message_list["messages"]:
                            # Filter messages that have trash label
                            trash_messages = []
                            message_ids = [msg["id"] for msg in message_list["messages"]]
                            
                            # Fetch details for each message and check for trash label
                            for msg_id in message_ids:
                                try:
                                    # Validate the message ID to prevent reserved keywords from being used
                                    reserved_keywords = ['spam', 'drafts', 'trash', 'inbox', 'sent', 'starred']
                                    if msg_id.lower() in reserved_keywords:
                                        logger.warning(f"Skipping message with reserved keyword ID: {msg_id}")
                                        continue
                                        
                                    # Get message details
                                    detail_url = f"https://gmail.googleapis.com/gmail/v1/users/me/messages/{msg_id}?format=full"
                                    async with session.get(detail_url, headers=headers) as detail_response:
                                        if detail_response.status == 200:
                                            msg_data = await detail_response.json()
                                            
                                            # Check if message has trash label
                                            label_ids = msg_data.get("labelIds", [])
                                            is_trash = any("trash" in str(label).lower() for label in label_ids)
                                            
                                            if is_trash:
                                                trash_messages.append(msg_data)
                                except Exception as detail_error:
                                    logger.warning(f"Error fetching details for message {msg_id}: {detail_error}")
        except Exception as fetch_error:
            logger.warning(f"Error fetching updated trash list: {fetch_error}")
        
        return {
            "success": True, 
            "message": f"Processed {len(results)} emails successfully, {len(errors)} errors",
            "results": results,
            "errors": errors
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.exception("CRITICAL ERROR - MOVE EMAILS TO TRASH: Unhandled exception.")
        raise HTTPException(status_code=500, detail=f"Internal Server Error: {type(e).__name__} - {str(e)}")


@email_router.get("/email/trash")
async def get_gmail_trash(current_user=Depends(get_current_user)):
    try:
        logger.info(f"[DEBUG] get_gmail_trash called with current_user: {type(current_user)} {current_user}")
        # Ensure current_user is properly handled
        user_email = None
        user_id = None
        if isinstance(current_user, UserInfo):
            user_email = current_user.email
            user_id = current_user.id
        elif isinstance(current_user, dict):
            user_email = current_user.get('email') or current_user.get('user_email')
            user_id = current_user.get('id') or current_user.get('user_id')
        else:
            user_email = str(current_user)
            user_id = str(current_user)
            
        if not user_email:
            raise HTTPException(status_code=400, detail="Unable to determine user email.")
            
        if not user_id:
            raise HTTPException(status_code=400, detail="Unable to determine user ID.")
            
        logger.info(f"Fetching trash for user_id: {user_id}, email: {user_email}")
        access_token, gmail_email = await refresh_google_token_for_user_id(user_id)
        if not access_token:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Token refresh failed or missing.")

        headers = {"Authorization": f"Bearer {access_token}"}
        async with aiohttp.ClientSession() as session:
            logger.info("Calling Gmail API for trash...")
            
            # Use the correct parameter format for labelIds - it should be a list
            params = {"labelIds": ["TRASH"]}
            async with session.get(
                f"{GMAIL_API_BASE}/messages",
                params=params,
                headers=headers
            ) as response:
                response_text = await response.text()
                logger.debug(f"Raw Gmail response: {response_text}")
                
                # Check if response is successful before trying to parse JSON
                if response.status != 200:
                    logger.error(f"Gmail API Trash error: {response.status} - {response_text}")
                    raise HTTPException(
                        status_code=response.status, 
                        detail=f"Gmail API error: {response.status} - {response_text}"
                    )
                
                response.raise_for_status()
                try:
                    data = await response.json()
                except Exception as e:
                    logger.exception("Error parsing Gmail API trash response as JSON")
                    raise HTTPException(
                        status_code=500,
                        detail=f"JSON parse error: {type(e).__name__} - {str(e)}"
                    )
                
                # Process the trash messages to match the frontend expectations
                trash_messages = []
                if "messages" in data and data["messages"]:
                    for msg in data["messages"]:
                        msg_id = msg["id"]
                        # Validate the message ID to prevent reserved keywords from being used
                        # Only log a warning and skip the message instead of raising an error
                        reserved_keywords = ['spam', 'drafts', 'trash', 'inbox', 'sent', 'starred']
                        if msg_id.lower() in reserved_keywords:
                            logger.warning(f"Skipping message with reserved keyword ID: {msg_id}")
                            continue
                            
                        # Get full message details
                        detail_url = f"https://gmail.googleapis.com/gmail/v1/users/me/messages/{msg_id}?format=full"
                        async with session.get(detail_url, headers=headers) as detail_response:
                            if detail_response.status == 200:
                                msg_data = await detail_response.json()
                                
                                # Extract headers
                                payload = msg_data.get("payload", {})
                                headers_list = payload.get("headers", [])
                                
                                subject = next((h["value"] for h in headers_list if h["name"] == "Subject"), "(No Subject)")
                                sender = next((h["value"] for h in headers_list if h["name"] == "From"), "Unknown Sender")
                                
                                # Get snippet
                                snippet = msg_data.get("snippet", "Message in trash.")
                                
                                # Get internal date and format it
                                internal_date = msg_data.get("internalDate")
                                if internal_date:
                                    time_str = format_time(datetime.fromtimestamp(int(internal_date)/1000).isoformat())
                                else:
                                    time_str = format_time(datetime.now().isoformat())
                                
                                # Check if starred and unread
                                label_ids = msg_data.get("labelIds", [])
                                is_starred = "STARRED" in label_ids
                                is_unread = "UNREAD" in label_ids
                                
                                trash_messages.append({
                                    "id": msg_id,
                                    "sender": sender,
                                    "subject": subject,
                                    "snippet": snippet,
                                    "time": time_str,
                                    "read": True,
                                    "folder": "Trash",
                                    "isStarred": is_starred,
                                    "isUnread": is_unread
                                })
                
                return {
                    "success": True,
                    "trash": trash_messages
                }
    except ClientResponseError as e:
        logger.warning(f"Gmail API Trash error ({e.status}): {e.message}")
        raise HTTPException(status_code=e.status, detail=f"Gmail API error: {e.message}")
    except ClientConnectorError:
        logger.error("Could not connect to Gmail API (Trash).")
        raise HTTPException(status_code=503, detail="Could not connect to Gmail API.")
    except Exception as e:
        logger.exception("CRITICAL ERROR - TRASH: Unhandled exception.")
        raise HTTPException(status_code=500, detail=f"Internal Server Error: {type(e).__name__} - {str(e)}")

@email_router.get("/email/{id}")
async def get_gmail_email_detail(id: str, current_user=Depends(get_current_user)):
    try:
        # Ensure current_user is properly handled
        user_email = None
        user_id = None
        if isinstance(current_user, UserInfo):
            user_email = current_user.email
            user_id = current_user.id
        elif isinstance(current_user, dict):
            user_email = current_user.get('email') or current_user.get('user_email')
            user_id = current_user.get('id') or current_user.get('user_id')
        else:
            user_email = str(current_user)
            user_id = str(current_user)
            
        if not user_email:
            raise HTTPException(status_code=400, detail="Unable to determine user email.")
            
        if not user_id:
            raise HTTPException(status_code=400, detail="Unable to determine user ID.")
            
        # Validate the message ID to prevent reserved keywords from being used
        reserved_keywords = ['spam', 'drafts', 'trash', 'inbox', 'sent', 'starred']
        if id.lower() in reserved_keywords:
            raise HTTPException(status_code=400, detail=f"Invalid message ID: '{id}' is a reserved keyword")
            
        access_token, gmail_email = await refresh_google_token_for_user_id(user_id)

        url = f"https://gmail.googleapis.com/gmail/v1/users/me/messages/{id}?format=full"
        headers = {"Authorization": f"Bearer {access_token}"}

        async with aiohttp.ClientSession() as session:
            async with session.get(url, headers=headers) as response:
                response.raise_for_status()
                data = await response.json()

        # Extract useful info
        payload = data.get("payload", {})
        headers_list = payload.get("headers", [])
        body = ""

        # Try to extract plain text body
        if payload.get("body", {}).get("data"):
            body = base64.urlsafe_b64decode(payload["body"]["data"]).decode("utf-8", errors="ignore")
        elif payload.get("parts"):
            for part in payload["parts"]:
                if part.get("mimeType") == "text/plain" and part["body"].get("data"):
                    body = base64.urlsafe_b64decode(part["body"]["data"]).decode("utf-8", errors="ignore")
                    break

        # Extract subject, from, to
        subject = next((h["value"] for h in headers_list if h["name"] == "Subject"), None)
        sender = next((h["value"] for h in headers_list if h["name"] == "From"), None)
        to = next((h["value"] for h in headers_list if h["name"] == "To"), None)

        return {
            "success": True,
            "id": data.get("id"),
            "threadId": data.get("threadId"),
            "subject": subject,
            "from": sender,
            "to": to,
            "body": body,
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch email details: {str(e)}")

@email_router.post("/email/{id}/read")
async def mark_email_as_read(id: str, current_user=Depends(get_current_user)):
    try:
        # Ensure current_user is properly handled
        user_email = None
        user_id = None
        if isinstance(current_user, UserInfo):
            user_email = current_user.email
            user_id = current_user.id
        elif isinstance(current_user, dict):
            user_email = current_user.get('email') or current_user.get('user_email')
            user_id = current_user.get('id') or current_user.get('user_id')
        else:
            user_email = str(current_user)
            user_id = str(current_user)
            
        if not user_email:
            raise HTTPException(status_code=400, detail="Unable to determine user email.")
            
        if not user_id:
            raise HTTPException(status_code=400, detail="Unable to determine user ID.")
            
        # Validate the message ID to prevent reserved keywords from being used
        reserved_keywords = ['spam', 'drafts', 'trash', 'inbox', 'sent', 'starred']
        if id.lower() in reserved_keywords:
            raise HTTPException(status_code=400, detail=f"Invalid message ID: '{id}' is a reserved keyword")
            
        access_token, gmail_email = await refresh_google_token_for_user_id(user_id)
        result = await modify_gmail_labels(access_token, id, remove_labels=["UNREAD"])
        return {"status": "success", "message": "Email marked as read successfully", "gmail_response": result}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@email_router.post("/email/{id}/unread")
async def mark_email_as_unread(id: str, current_user=Depends(get_current_user)):
    try:
        # Ensure current_user is properly handled
        user_email = None
        user_id = None
        if isinstance(current_user, UserInfo):
            user_email = current_user.email
            user_id = current_user.id
        elif isinstance(current_user, dict):
            user_email = current_user.get('email') or current_user.get('user_email')
            user_id = current_user.get('id') or current_user.get('user_id')
        else:
            user_email = str(current_user)
            user_id = str(current_user)
            
        if not user_email:
            raise HTTPException(status_code=400, detail="Unable to determine user email.")
            
        if not user_id:
            raise HTTPException(status_code=400, detail="Unable to determine user ID.")
            
        # Validate the message ID to prevent reserved keywords from being used
        reserved_keywords = ['spam', 'drafts', 'trash', 'inbox', 'sent', 'starred']
        if id.lower() in reserved_keywords:
            raise HTTPException(status_code=400, detail=f"Invalid message ID: '{id}' is a reserved keyword")
            
        access_token, gmail_email = await refresh_google_token_for_user_id(user_id)
        result = await modify_gmail_labels(access_token, id, add_labels=["UNREAD"])
        return {"status": "success", "message": "Email marked as unread successfully", "gmail_response": result}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

