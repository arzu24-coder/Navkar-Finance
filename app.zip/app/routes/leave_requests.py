from fastapi import APIRouter, HTTPException, Query, Body, Depends
from typing import Dict, Optional, List, Any
from bson import ObjectId
from motor.motor_asyncio import AsyncIOMotorDatabase
from datetime import datetime
import logging
from app.models.employee import EmployeeUpdate, EmployeeCreate, EmployeeModel

from app.database import get_database
from app.dependencies import get_current_user
from app.routes.employees import (
    extract_user_roles, 
    has_admin_or_hr_permission, 
    make_serializable
)
from app.models.auth import UserInfo

# Configure logger
logger = logging.getLogger(__name__)

# Initialize router with explicit prefix
leave_requests_router = APIRouter(prefix="/api/leave-requests", tags=["leave-requests"])


def map_employee_doc(emp: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "id": str(emp.get("_id") or emp.get("id") or ""),
        "name": emp.get("name", "Unknown"),
        "email": emp.get("email", ""),
        "phone": emp.get("phone", ""),
        # prefer 'position' (DB) but accept 'role' if already present
        "role": emp.get("position") or emp.get("role") or "Employee",
        # prefer 'date_of_joining' (DB) but accept 'joinDate' if already present
        "joinDate": emp.get("date_of_joining") or emp.get("joinDate") or None,
        "attendance": emp.get("attendance", 0),
        "leaveBalance": emp.get("leaveBalance", emp.get("leave_balance", 0)),
        "salary": emp.get("salary", "₹0"),
        "address": emp.get("address", "Not Available"),
        "status": emp.get("status", "Active"),
        "department": emp.get("department", "Not Assigned")
    }

@leave_requests_router.post("/", status_code=201)
async def create_leave_request(
    payload: Dict = Body(...),
    current_user: UserInfo = Depends(get_current_user)
):
    try:
        db = get_database()
        user_roles = extract_user_roles(current_user.dict())
        
        user_id: str = payload.get("user_id", "")
        leave_type: str = payload.get("leave_type", "")  # sick, vacation, personal, etc.
        start_date: str = payload.get("start_date", "")
        end_date: str = payload.get("end_date", "")
        reason: str = payload.get("reason", "")
        is_half_day: bool = payload.get("is_half_day", False)
        
        if not all([user_id, leave_type, start_date, end_date]):
            raise HTTPException(status_code=400, detail="Missing required fields")
        
        # Authorization check: users can only create requests for themselves unless they're admin/HR
        current_user_id = current_user.id or getattr(current_user, "user_id", None) or current_user.username
        is_admin_or_hr = has_admin_or_hr_permission(user_roles)
        
        # Log for debugging
        logger.info(f"User {current_user.username} (ID: {current_user_id}) attempting to create leave request for user {user_id}")
        logger.info(f"User roles: {user_roles}, Is admin/HR: {is_admin_or_hr}")
        
        # Allow HR users to create leave requests for any employee
        # But regular users can only create requests for themselves
        if user_id != current_user_id and not is_admin_or_hr:
            logger.warning(f"User {current_user.username} attempted to create leave request for another user without permission")
            raise HTTPException(status_code=403, detail="You can only create leave requests for yourself. Only HR and Admin users can create requests for other employees.")
        
        # Verify user exists - handle both user_id field and ObjectId
        user = db.users.find_one({"user_id": user_id})
        if not user and ObjectId.is_valid(user_id):
            # If not found by user_id and it's a valid ObjectId, try _id
            user = db.users.find_one({"_id": ObjectId(user_id)})
        if not user:
            logger.warning(f"User with ID {user_id} not found")
            raise HTTPException(status_code=404, detail="Employee not found. Please check the employee ID and try again.")
        
        # Calculate number of days
        start = datetime.strptime(start_date, "%Y-%m-%d")
        end = datetime.strptime(end_date, "%Y-%m-%d")
        days_requested = (end - start).days + 1
        
        if is_half_day:
            days_requested = 0.5
        
        # Get employee name for display
        employee_name = user.get("full_name", user.get("username", "Unknown Employee"))
        
        leave_request = {
            "user_id": user_id,
            "employee_name": employee_name,
            "leave_type": leave_type,
            "start_date": start_date,
            "end_date": end_date,
            "days_requested": days_requested,
            "reason": reason,
            "is_half_day": is_half_day,
            "status": "pending",  # pending, approved, rejected
            "requested_at": datetime.now(),
            "approved_by": None,
            "approved_at": None,
            "rejection_reason": None
        }
        
        # Use the correct collection reference
        result = db.leave_requests.insert_one(leave_request)
        leave_request["_id"] = result.inserted_id
        
        # Update leave balance
        update_leave_balance_for_request(leave_request, db)
        
        logger.info(f"Leave request created successfully for user {user_id}")
        return make_serializable({
            "success": True,
            "message": "Leave request created successfully",
            "data": leave_request
        })
        
    except HTTPException as http_error:
        # Re-raise HTTP exceptions with their original status codes
        logger.error(f"HTTP error in create_leave_request: {http_error.detail}")
        raise
    except Exception as e:
        logger.error(f"Error creating leave request: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to create leave request: {str(e)}")

@leave_requests_router.get("/", status_code=200)
async def get_leave_requests(
    page: int = Query(1, description="Page number"),
    limit: int = Query(10, description="Items per page"),
    employee_id: Optional[str] = Query(None, description="Filter by employee ID (Admin/HR only)"),
    status: Optional[str] = Query(None, description="Filter by status"),
    leave_type: Optional[str] = Query(None, description="Filter by leave type"),
    current_user: UserInfo = Depends(get_current_user)
):
    try:
        db = get_database()
        user_roles = extract_user_roles(current_user.dict())
        
        # Check if user has admin/HR permissions
        is_admin_or_hr = has_admin_or_hr_permission(user_roles)
        
        query = {}
        
        # Role-based access control
        if is_admin_or_hr:
            # Admin/HR can see all requests or filter by specific employee
            if employee_id:
                query["user_id"] = employee_id
        else:
            # Regular employees can only see their own requests
            query["user_id"] = current_user.id or getattr(current_user, "user_id", None) or current_user.username
        
        if status:
            query["status"] = status
            
        if leave_type:
            query["leave_type"] = leave_type
        
        # Pagination
        skip = (page - 1) * limit
        
        # Use the correct collection reference
        requests = list(db.leave_requests.find(query).sort("requested_at", -1).skip(skip).limit(limit))
        total = db.leave_requests.count_documents(query)
        
        # Add employee names for admin/HR view
        if is_admin_or_hr and requests:
            user_ids = list(set(request.get("user_id") for request in requests if request.get("user_id")))
            users_data = {user["user_id"]: user for user in db.users.find({"user_id": {"$in": user_ids}})}
            
            for request in requests:
                user_id = request.get("user_id")
                if user_id in users_data:
                    request["employee_name"] = users_data[user_id].get("full_name", users_data[user_id].get("name", "Unknown"))
                    request["employee_id"] = users_data[user_id].get("employee_id", user_id)
                else:
                    request["employee_name"] = "Unknown Employee"
                    request["employee_id"] = user_id
        
        return make_serializable({
            "success": True,
            "data": requests,
            "page": page,
            "limit": limit,
            "total": total,
            "pages": (total + limit - 1) // limit,
            "user_permissions": {
                "is_admin_or_hr": is_admin_or_hr,
                "can_view_all": is_admin_or_hr,
                "can_approve_reject": is_admin_or_hr
            }
        })
        
    except Exception as e:
        logger.error(f"Error getting leave requests: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to get leave requests: {str(e)}")

@leave_requests_router.get("/all-admin", status_code=200)
async def get_all_leave_requests_admin(
    page: int = Query(1, description="Page number"),
    limit: int = Query(50, description="Items per page"),
    department: Optional[str] = Query(None, description="Filter by department"),
    status: Optional[str] = Query(None, description="Filter by status"),
    leave_type: Optional[str] = Query(None, description="Filter by leave type"),
    search: Optional[str] = Query(None, description="Search by employee name or ID"),
    start_date: Optional[str] = Query(None, description="Filter from date (YYYY-MM-DD)"),
    end_date: Optional[str] = Query(None, description="Filter to date (YYYY-MM-DD)"),
    current_user: UserInfo = Depends(get_current_user)
):
    try:
        user_roles = extract_user_roles(current_user.dict())
        
        # Check if user has admin/HR permissions
        if not has_admin_or_hr_permission(user_roles):
            raise HTTPException(status_code=403, detail="Insufficient permissions. Only Admin and HR can access all leave requests")
        
        db = get_database()
        query = {}
        
        # Status filter
        if status:
            query["status"] = status
        
        # Leave type filter
        if leave_type:
            query["leave_type"] = leave_type
        
        # Date range filter (for leave start dates)
        if start_date or end_date:
            date_query = {}
            if start_date:
                date_query["$gte"] = start_date
            if end_date:
                date_query["$lte"] = end_date
            query["start_date"] = date_query
        
        # Get user IDs based on department filter or search
        user_ids_filter = None
        if department or search:
            user_query = {}
            if department:
                user_query["department"] = department
            if search:
                user_query["$or"] = [
                    {"full_name": {"$regex": search, "$options": "i"}},
                    {"name": {"$regex": search, "$options": "i"}},
                    {"user_id": {"$regex": search, "$options": "i"}},
                    {"employee_id": {"$regex": search, "$options": "i"}}
                ]
            
            matching_users = list(db.users.find(user_query, {"user_id": 1}))
            user_ids_filter = [user["user_id"] for user in matching_users]
            
            if user_ids_filter:
                query["user_id"] = {"$in": user_ids_filter}
            else:
                # No matching users found
                return make_serializable({
                    "success": True,
                    "data": [],
                    "page": page,
                    "limit": limit,
                    "total": 0,
                    "pages": 0,
                    "filters_applied": {
                        "department": department, 
                        "search": search, 
                        "status": status,
                        "leave_type": leave_type,
                        "start_date": start_date,
                        "end_date": end_date
                    }
                })
        
        # Pagination
        skip = (page - 1) * limit
        
        # Get leave requests
        requests = list(db.leave_requests.find(query).sort("requested_at", -1).skip(skip).limit(limit))
        total = db.leave_requests.count_documents(query)
        
        # Enrich with employee information
        if requests:
            user_ids = list(set(request.get("user_id") for request in requests if request.get("user_id")))
            users_data = {user["user_id"]: user for user in db.users.find({"user_id": {"$in": user_ids}})}
            
            for request in requests:
                user_id = request.get("user_id")
                if user_id in users_data:
                    user_info = users_data[user_id]
                    request["employee_name"] = user_info.get("full_name", user_info.get("name", user_info.get("username", "Unknown Employee")))
                    request["employee_id"] = user_info.get("employee_id", user_id)
                    request["department"] = user_info.get("department", "Not assigned")
                    request["position"] = user_info.get("position", "Not assigned")
                else:
                    # Try to get user info from the database using ObjectId
                    try:
                        user_obj = db.users.find_one({"_id": ObjectId(user_id)})
                        if user_obj:
                            request["employee_name"] = user_obj.get("full_name", user_obj.get("name", user_obj.get("username", "Unknown Employee")))
                            request["employee_id"] = user_obj.get("employee_id", user_id)
                            request["department"] = user_obj.get("department", "Not assigned")
                            request["position"] = user_obj.get("position", "Not assigned")
                        else:
                            request["employee_name"] = "Unknown Employee"
                            request["employee_id"] = user_id
                            request["department"] = "Not assigned"
                            request["position"] = "Not assigned"
                    except:
                        request["employee_name"] = "Unknown Employee"
                        request["employee_id"] = user_id
                        request["department"] = "Not assigned"
                        request["position"] = "Not assigned"
        
        # Get summary statistics
        summary_stats = {
            "total_requests": total,
            "pending_requests": db.leave_requests.count_documents({**query, "status": "pending"}),
            "approved_requests": db.leave_requests.count_documents({**query, "status": "approved"}),
            "rejected_requests": db.leave_requests.count_documents({**query, "status": "rejected"})
        }
        
        return make_serializable({
            "success": True,
            "data": requests,
            "page": page,
            "limit": limit,
            "total": total,
            "pages": (total + limit - 1) // limit,
            "summary_stats": summary_stats,
            "filters_applied": {
                "department": department,
                "search": search,
                "status": status,
                "leave_type": leave_type,
                "start_date": start_date,
                "end_date": end_date
            },
            "user_permissions": {
                "is_admin_or_hr": True,
                "can_view_all": True,
                "can_approve_reject": True
            }
        })
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting all leave requests: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to get all leave requests: {str(e)}")

@leave_requests_router.get("/my-requests", status_code=200)
async def get_my_leave_requests(
    page: int = Query(1, description="Page number"),
    limit: int = Query(10, description="Items per page"),
    status: Optional[str] = Query(None, description="Filter by status"),
    leave_type: Optional[str] = Query(None, description="Filter by leave type"),
    current_user: UserInfo = Depends(get_current_user)
):
    try:
        db = get_database()
        
        # Build query for current user's requests
        user_id = current_user.id or getattr(current_user, "user_id", None) or current_user.username
        query = {"user_id": user_id}
        
        # Apply filters
        if status:
            query["status"] = status
            
        if leave_type:
            query["leave_type"] = leave_type
        
        # Pagination
        skip = (page - 1) * limit
        
        # Get leave requests
        requests = list(db.leave_requests.find(query).sort("requested_at", -1).skip(skip).limit(limit))
        total = db.leave_requests.count_documents(query)
        
        # Add employee name to each request for proper display
        for request in requests:
            # Get user information
            user = db.users.find_one({"user_id": user_id})
            if not user:
                # Try with ObjectId
                try:
                    user = db.users.find_one({"_id": ObjectId(user_id)})
                except:
                    pass
            
            # Set employee name
            if user:
                request["employee_name"] = user.get("full_name", user.get("username", "Unknown"))
            else:
                request["employee_name"] = current_user.full_name or current_user.username or "Unknown"
        
        return make_serializable({
            "success": True,
            "data": requests,
            "page": page,
            "limit": limit,
            "total": total,
            "pages": (total + limit - 1) // limit
        })
        
    except Exception as e:
        logger.error(f"Error getting my leave requests: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to get your leave requests: {str(e)}")

@leave_requests_router.get("/leave-balance/{employee_id}", status_code=200)
async def get_employee_leave_balance(
    employee_id: str,
    current_user: UserInfo = Depends(get_current_user)
):
    try:
        db = get_database()
        user_roles = extract_user_roles(current_user.dict())
        
        # Check if user has admin/HR permissions or is requesting their own balance
        current_user_id = current_user.id or getattr(current_user, "user_id", None) or current_user.username
        is_admin_or_hr = has_admin_or_hr_permission(user_roles)
        
        # Authorization check
        if employee_id != current_user_id and not is_admin_or_hr:
            raise HTTPException(
                status_code=403, 
                detail="You can only view your own leave balance. Only HR and Admin users can view other employees' leave balances."
            )
        
        # Verify employee exists - handle both user_id field and ObjectId
        employee = db.users.find_one({"user_id": employee_id})
        if not employee and ObjectId.is_valid(employee_id):
            # If not found by user_id and it's a valid ObjectId, try _id
            employee = db.users.find_one({"_id": ObjectId(employee_id)})
        if not employee:
            raise HTTPException(status_code=404, detail="Employee not found")
        
        # Get leave balance from leave_balances collection
        from datetime import datetime
        current_year = datetime.now().year
        
        leave_balance = db.leave_balances.find_one({
            "employee_id": employee_id,
            "year": current_year
        })
        
        # If no leave balance record exists, create a default one
        if not leave_balance:
            # Default leave entitlement (this could be customized per employee/role)
            annual_leave_entitlement = 20  # Default 20 days per year
            
            # Get all approved leave requests for this employee in the current year
            start_of_year = datetime(current_year, 1, 1)
            end_of_year = datetime(current_year, 12, 31)
            
            approved_requests = list(db.leave_requests.find({
                "user_id": employee_id,
                "status": "approved",
                "start_date": {
                    "$gte": start_of_year.strftime("%Y-%m-%d"),
                    "$lte": end_of_year.strftime("%Y-%m-%d")
                }
            }))
            
            # Calculate total days taken
            total_days_taken = sum(request.get("days_requested", 0) for request in approved_requests)
            
            # Calculate remaining balance
            remaining_balance = annual_leave_entitlement - total_days_taken
            
            # Create leave balance record
            leave_balance = {
                "employee_id": employee_id,
                "employee_name": employee.get("full_name", employee.get("username")),
                "year": current_year,
                "annual_entitlement": annual_leave_entitlement,
                "days_taken": total_days_taken,
                "remaining_balance": max(0, remaining_balance),  # Ensure non-negative
                "updated_at": datetime.now()
            }
            
            # Insert the new leave balance record
            db.leave_balances.insert_one(leave_balance)
        else:
            # Update the leave balance if it already exists
            # Recalculate based on current approved requests
            start_of_year = datetime(current_year, 1, 1)
            end_of_year = datetime(current_year, 12, 31)
            
            approved_requests = list(db.leave_requests.find({
                "user_id": employee_id,
                "status": "approved",
                "start_date": {
                    "$gte": start_of_year.strftime("%Y-%m-%d"),
                    "$lte": end_of_year.strftime("%Y-%m-%d")
                }
            }))
            
            # Calculate total days taken
            total_days_taken = sum(request.get("days_requested", 0) for request in approved_requests)
            
            # Get annual entitlement from existing record or default to 20
            annual_leave_entitlement = leave_balance.get("annual_entitlement", 20)
            
            # Calculate remaining balance
            remaining_balance = annual_leave_entitlement - total_days_taken
            
            # Update the leave balance record
            updated_leave_balance = {
                "employee_name": employee.get("full_name", employee.get("username")),
                "annual_entitlement": annual_leave_entitlement,
                "days_taken": total_days_taken,
                "remaining_balance": max(0, remaining_balance),  # Ensure non-negative
                "updated_at": datetime.now()
            }
            
            db.leave_balances.update_one(
                {"employee_id": employee_id, "year": current_year},
                {"$set": updated_leave_balance}
            )
            
            # Update the leave_balance object for response
            leave_balance.update(updated_leave_balance)
        
        return make_serializable({
            "success": True,
            "data": leave_balance
        })
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting employee leave balance: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to get leave balance: {str(e)}")

def update_leave_balance_for_request(leave_request, db):
    """Update leave balance when a leave request status changes"""
    try:
        from datetime import datetime
        
        employee_id = leave_request.get("user_id")
        if not employee_id:
            return
            
        # Get the year from the leave request
        start_date_str = leave_request.get("start_date")
        if not start_date_str:
            return
            
        from datetime import datetime
        start_date = datetime.strptime(start_date_str, "%Y-%m-%d")
        year = start_date.year
        
        # Get current leave balance record
        leave_balance = db.leave_balances.find_one({
            "employee_id": employee_id,
            "year": year
        })
        
        # If no leave balance record exists, create a default one
        if not leave_balance:
            # Default leave entitlement
            annual_leave_entitlement = 20
            
            # Create leave balance record
            leave_balance = {
                "employee_id": employee_id,
                "employee_name": leave_request.get("employee_name", "Unknown"),
                "year": year,
                "annual_entitlement": annual_leave_entitlement,
                "days_taken": 0,
                "remaining_balance": annual_leave_entitlement,
                "updated_at": datetime.now()
            }
            db.leave_balances.insert_one(leave_balance)
        
        # Recalculate days taken based on all approved requests for this year
        start_of_year = datetime(year, 1, 1)
        end_of_year = datetime(year, 12, 31)
        
        approved_requests = list(db.leave_requests.find({
            "user_id": employee_id,
            "status": "approved",
            "start_date": {
                "$gte": start_of_year.strftime("%Y-%m-%d"),
                "$lte": end_of_year.strftime("%Y-%m-%d")
            }
        }))
        
        # Calculate total days taken
        total_days_taken = sum(request.get("days_requested", 0) for request in approved_requests)
        
        # Get annual entitlement from existing record
        annual_leave_entitlement = leave_balance.get("annual_entitlement", 20)
        
        # Calculate remaining balance
        remaining_balance = annual_leave_entitlement - total_days_taken
        
        # Update the leave balance record
        updated_leave_balance = {
            "employee_name": leave_request.get("employee_name", "Unknown"),
            "annual_entitlement": annual_leave_entitlement,
            "days_taken": total_days_taken,
            "remaining_balance": max(0, remaining_balance),  # Ensure non-negative
            "updated_at": datetime.now()
        }
        
        db.leave_balances.update_one(
            {"employee_id": employee_id, "year": year},
            {"$set": updated_leave_balance}
        )
        
    except Exception as e:
        logger.error(f"Error updating leave balance: {str(e)}")

@leave_requests_router.put("/{request_id}/approve", status_code=200)
async def approve_leave_request(
    request_id: str,
    payload: Dict = Body(...),
    current_user: UserInfo = Depends(get_current_user)
):
    """Approve a leave request - Admin/HR only"""
    try:
        db = get_database()
        user_roles = extract_user_roles(current_user.dict())
        
        # Check if user has admin/HR permissions
        if not has_admin_or_hr_permission(user_roles):
            raise HTTPException(status_code=403, detail="Insufficient permissions. Only Admin and HR can approve leave requests")
        
        # Find the leave request
        leave_request = db.leave_requests.find_one({"_id": ObjectId(request_id)})
        if not leave_request:
            raise HTTPException(status_code=404, detail="Leave request not found")
        
        if leave_request["status"] != "pending":
            raise HTTPException(status_code=400, detail="Leave request is not pending")
        
        # Update the request
        update_data = {
            "status": "approved",
            "approved_by": current_user.get("full_name", current_user.get("name", "Admin")),
            "approved_by_id": current_user.get("user_id", current_user.get("employee_id")),
            "approved_at": datetime.now(),
            "approval_notes": payload.get("notes", "")
        }
        
        db.leave_requests.update_one(
            {"_id": ObjectId(request_id)},
            {"$set": update_data}
        )
        
        # Update leave balance
        updated_request = db.leave_requests.find_one({"_id": ObjectId(request_id)})
        update_leave_balance_for_request(updated_request, db)
        
        return {
            "success": True,
            "message": "Leave request approved successfully",
            "approved_by": update_data["approved_by"]
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error approving leave request: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to approve leave request: {str(e)}")

@leave_requests_router.put("/{request_id}/reject", status_code=200)
async def reject_leave_request(
    request_id: str,
    payload: Dict = Body(...),
    current_user: UserInfo = Depends(get_current_user)
):
    try:
        db = get_database()
        user_roles = extract_user_roles(current_user.dict())
        
        # Check if user has admin/HR permissions
        if not has_admin_or_hr_permission(user_roles):
            raise HTTPException(status_code=403, detail="Insufficient permissions. Only Admin and HR can reject leave requests")
        
        reason = payload.get("reason", "")
        if not reason:
            raise HTTPException(status_code=400, detail="Rejection reason is required")
        
        # Find the leave request
        leave_request = db.leave_requests.find_one({"_id": ObjectId(request_id)})
        if not leave_request:
            raise HTTPException(status_code=404, detail="Leave request not found")
        
        if leave_request["status"] != "pending":
            raise HTTPException(status_code=400, detail="Leave request is not pending")
        
        # Update the request
        update_data = {
            "status": "rejected",
            "rejected_by": current_user.get("full_name", current_user.get("name", "Admin")),
            "rejected_by_id": current_user.get("user_id", current_user.get("employee_id")),
            "rejected_at": datetime.now(),
            "rejection_reason": reason
        }
        
        db.leave_requests.update_one(
            {"_id": ObjectId(request_id)},
            {"$set": update_data}
        )
        
        # Update leave balance (this will recalculate based on approved requests only)
        updated_request = db.leave_requests.find_one({"_id": ObjectId(request_id)})
        update_leave_balance_for_request(updated_request, db)
        
        return {
            "success": True,
            "message": "Leave request rejected successfully",
            "rejected_by": update_data["rejected_by"]
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error rejecting leave request: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to reject leave request: {str(e)}")
    


@leave_requests_router.patch("/{leave_id}/cancel")
async def cancel_leave_request(leave_id: str):
    # Validate leave_id
    if not ObjectId.is_valid(leave_id):
        raise HTTPException(status_code=400, detail="Invalid leave request ID")

    # Find leave request
    db= get_database()
    leave_request = db["leave_requests"].find_one({"_id": ObjectId(leave_id)})
    if not leave_request:
        raise HTTPException(status_code=404, detail="Leave request not found")

    # Check if already cancelled or approved
    if leave_request.get("status") in ["cancelled", "approved"]:
        raise HTTPException(status_code=400, detail=f"Leave request already {leave_request['status']}")

    # Update status to cancelled
    db["leave_requests"].update_one(
        {"_id": ObjectId(leave_id)},
        {"$set": {"status": "cancelled"}}
    )

    return {
        "message": "Leave request cancelled successfully",
        "leave_id": leave_id,
        "new_status": "cancelled"
    }


@leave_requests_router.get("/api/leaves/type/{leave_type}")
async def get_leaves_by_type(leave_type: str, db: AsyncIOMotorDatabase = Depends(get_database)):
    valid_types = ["sick", "annual", "casual"]

    if leave_type.lower() not in valid_types:
        raise HTTPException(status_code=400, detail="Invalid leave type. Choose from sick, annual, or casual.")

    leaves_collection = db["leaves"]

    # find all matching leave documents
    leaves_cursor = leaves_collection.find({"leave_type": {"$regex": f"^{leave_type}$", "$options": "i"}})
    leaves = await leaves_cursor.to_list(length=None)

    if not leaves:
        raise HTTPException(status_code=404, detail=f"No {leave_type} leaves found.")

    return {
        "status": "success",
        "leave_type": leave_type.lower(),
        "count": len(leaves),
        "data": leaves
    }

# ✅ Add New Employee
@leave_requests_router.post("/add", status_code=201)
async def add_employee(employee: EmployeeCreate):
    emp_data = employee.dict()
    emp_data["attendance"] = 95
    emp_data["leaveBalance"] = 12
    emp_data["status"] = "Active"
    db = get_database()
    result = db.employees.insert_one(emp_data)
    new_emp = db.employees.find_one({"_id": result.inserted_id})
    
    # Map database fields to EmployeeModel fields
    employee_model_data = {
        "id": str(new_emp.get("_id")),
        "name": new_emp.get("name", ""),
        "email": new_emp.get("email", ""),
        "phone": new_emp.get("phone", ""),
        "role": new_emp.get("position", "Employee"),  # Map position -> role
        "joinDate": new_emp.get("date_of_joining", "2025-01-01"),  # Map date_of_joining -> joinDate
        "attendance": new_emp.get("attendance", 95),
        "leaveBalance": new_emp.get("leaveBalance", 12),
        "salary": new_emp.get("salary", "₹0"),
        "address": new_emp.get("address", "Not Available"),
        "status": new_emp.get("status", "Active")
    }
    
    return {"success": True, "message": "Employee added successfully", "data": employee_model_data}

# ✅ Get All Employees (with pagination + search)
@leave_requests_router.get("/employees", status_code=200)
async def get_all_employees(
    page: int = 1,
    limit: int = 10,
    search: Optional[str] = None,
    current_user: dict = Depends(get_current_user)
):
    db = get_database()

    # ✅ Check permissions (HR/Admin only)
    user_roles = extract_user_roles(current_user)
    is_admin_or_hr = has_admin_or_hr_permission(user_roles)
    if not is_admin_or_hr:
        raise HTTPException(status_code=403, detail="Only HR/Admin can view all employees")

    # ✅ Build search filter
    query = {}
    if search:
        query["$or"] = [
            {"name": {"$regex": search, "$options": "i"}},
            {"email": {"$regex": search, "$options": "i"}},
            {"role": {"$regex": search, "$options": "i"}}
        ]

    # ✅ Pagination
    skip = (page - 1) * limit

    employees_cursor = db.employees.find(query).skip(skip).limit(limit)
    # motor cursors are async - await to_list
    try:
        employees = await employees_cursor.to_list(length=limit)
    except Exception:
        # fallback for non-async DB client
        employees = list(db.employees.find(query).skip(skip).limit(limit))

    try:
        total = await db.employees.count_documents(query)
    except Exception:
        total = db.employees.count_documents(query)

    # ✅ Format response
    formatted = [map_employee_doc(emp) for emp in employees]

    return make_serializable({
        "success": True,
        "data": formatted,
        "total": total,
        "page": page,
        "pages": (total + limit - 1) // limit
    })

# ✅ Get Single Employee by ID
@leave_requests_router.get("/employees/{employee_id}")
async def get_employee(employee_id: str):
    db = get_database()
    employee = None
    # try by ObjectId first if valid
    try:
        if ObjectId.is_valid(employee_id):
            employee = db.employees.find_one({"_id": ObjectId(employee_id)})
    except Exception:
        employee = None

    if not employee:
        employee = db.employees.find_one({"_id": employee_id}) or db.employees.find_one({"id": employee_id})

    if not employee:
        raise HTTPException(status_code=404, detail="Employee not found")

    return {"success": True, "data": map_employee_doc(employee)}

# ✅ Update Employee
@leave_requests_router.put("/update/{employee_id}")
async def update_employee(employee_id: str, update_data: EmployeeUpdate):
    data = {k: v for k, v in update_data.dict().items() if v is not None}
    db = get_database()
    # attempt by ObjectId
    try:
        result = db.employees.update_one({"_id": ObjectId(employee_id)}, {"$set": data})
    except Exception:
        result = db.employees.update_one({"_id": employee_id}, {"$set": data})

    if getattr(result, "modified_count", 0) == 0:
        raise HTTPException(status_code=404, detail="Employee not found or no changes made")

    try:
        updated_emp = db.employees.find_one({"_id": ObjectId(employee_id)})
    except Exception:
        updated_emp = db.employees.find_one({"_id": employee_id})

    return {"success": True, "message": "Employee updated successfully", "data": map_employee_doc(updated_emp)}

# ✅ Delete Employee
@leave_requests_router.delete("/delete/{employee_id}")
async def delete_employee(employee_id: str):
    db = get_database()
    try:
        result = db.employees.delete_one({"_id": ObjectId(employee_id)})
    except Exception:
        result = db.employees.delete_one({"_id": employee_id})

    if getattr(result, "deleted_count", 0) == 0:
        raise HTTPException(status_code=404, detail="Employee not found")
    return {"success": True, "message": "Employee deleted successfully"}