from fastapi import APIRouter, Depends, HTTPException
from app.dependencies import get_current_user
from app.database.schemas.lead_schema import PhoneInput
from app.database.repositories.lead_repository import CallLogRepository
from datetime import datetime
import re
from typing import Optional
from twilio.rest import Client
from bson import ObjectId
import asyncio
from concurrent.futures import ThreadPoolExecutor


twilio_account_sid = 'AC773383802792004a25f87804d51dec12'
twilio_auth_token = 'ba671f74c8bbb27fb60be8e4917e129f'
twilio_client = Client(twilio_account_sid, twilio_auth_token)
twilio_phone_number = '+15101234567'

executor = ThreadPoolExecutor(max_workers=5)

async def get_twilio_all_calls(**kwargs):
    loop = asyncio.get_event_loop()
    
    def fetch_all_calls():
        all_calls = []
        page = twilio_client.calls.page(**kwargs)  # Call page() method
        while page:
            all_calls.extend(page)  # page is iterable
            next_page_method = getattr(page, 'next_page', None)
            if next_page_method is not None and callable(next_page_method):
                page = next_page_method()  # Call next_page() method
            else:
                page = None
        return all_calls
    
    calls = await loop.run_in_executor(executor, fetch_all_calls)
    return calls


call_log_router = APIRouter(prefix="/api/call-logs", tags=["call_logs"])

def serialize_object(obj):
    if isinstance(obj, list):
        return [serialize_object(item) for item in obj]
    elif isinstance(obj, dict):
        result = {}
        for k, v in obj.items():
            if isinstance(v, ObjectId):
                result[k] = str(v)
            else:
                result[k] = serialize_object(v)
        return result
    elif isinstance(obj, ObjectId):
        return str(obj)
    else:
        return obj


@call_log_router.post("/import-by-phone")
async def import_calls_by_phone(
    phone_input: PhoneInput,
    current_user: dict = Depends(get_current_user),
    call_log_repo: CallLogRepository = Depends(CallLogRepository),
):
    def normalize_number(num: str) -> str:
        digits = re.sub(r'\D', '', num)
        return digits[-10:] if digits else ""

    # Async wrapper to fetch calls filtered by from or to
    async def get_calls_by_filter(filter_field: str, number: str):
        loop = asyncio.get_event_loop()
        calls_list = []

        def fetch_calls():
            param_name = filter_field
            if filter_field == "from":
                param_name = "from_"
            page = twilio_client.calls.page(**{param_name: number})
            results = []
            while page:
                results.extend(page)
                next_page_method = getattr(page, 'next_page', None)
                page = next_page_method() if next_page_method and callable(next_page_method) else None
            return results

        calls = await loop.run_in_executor(executor, fetch_calls)
        return calls


    try:
        entered = normalize_number(phone_input.phone)
        print(f"Import started for phone number (normalized): {entered}")

        # Format the number for Twilio query - typically E.164 format expected
        # Assuming +91 prefix, adjust as needed
        query_number = f"+91{entered}"

        # Fetch calls where user is caller (from)
        from_calls = await get_calls_by_filter('from', query_number)
        # Fetch calls where user is recipient (to)
        to_calls = await get_calls_by_filter('to', query_number)

        # Combine and dedupe by call sid
        all_calls = {call.sid: call for call in from_calls + to_calls}.values()

        imported_count = 0
        for call in all_calls:
            call_sid = getattr(call, 'sid', None)
            if call_log_repo.get_call_log_by_sid(call_sid):
                print(f"Call with sid {call_sid} already exists, skipping import.")
                continue

            from_num_raw = getattr(call, "from_", None) or twilio_phone_number
            to_num_raw = getattr(call, "to", None)

            call_type = "incoming" if call.direction == "inbound" else "outgoing"

            call_data = {
                "twilio_sid": call_sid,
                "caller": from_num_raw,
                "recipient": to_num_raw,
                "call_start": call.start_time.isoformat() if call.start_time else None,
                "call_end": call.end_time.isoformat() if call.end_time else None,
                "duration": int(call.duration) if call.duration else 0,
                "call_type": call_type,
                "notes": "",
                "recording_url": None,
                "created_by": current_user.get("id"),
                "created_at": datetime.now(),
                "updated_at": datetime.now(),
            }

            print(f"Importing call data: {call_data}")
            created_log = call_log_repo.create_call_log(call_data)
            if created_log:
                print("Insert successful")
                imported_count += 1

        print(f"Total calls imported for {entered}: {imported_count}")
        return {"status": "success", "imported_count": imported_count}

    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Failed to import calls for phone: {str(e)}")


@call_log_router.post("/import-all")
async def import_all_calls(
    current_user: dict = Depends(get_current_user),
    call_log_repo: CallLogRepository = Depends(CallLogRepository),
):
    try:
        print("Import started for all calls (all recipients)")

        calls = await get_twilio_all_calls()

        imported_count = 0
        for call in calls:
            call_sid = getattr(call, 'sid', None)
            existing_log = call_log_repo.get_call_log_by_sid(call_sid)  # Sync call
            if existing_log:
                continue

            from_num = getattr(call, "from_", None) or twilio_phone_number
            to_num = getattr(call, "to", None)

            if call.direction == "inbound":
                caller = from_num
                recipient = to_num
                call_type = "incoming"
            else:
                caller = from_num
                recipient = to_num
                call_type = "outgoing"

            call_data = {
                "twilio_sid": call_sid,
                "caller": caller,
                "recipient": recipient,
                "call_start": call.start_time.isoformat() if call.start_time else None,
                "call_end": call.end_time.isoformat() if call.end_time else None,
                "duration": int(call.duration) if call.duration else 0,
                "call_type": call_type,
                "notes": "",
                "recording_url": None,
                "created_by": current_user.get("id"),
                "created_at": datetime.now(),
                "updated_at": datetime.now(),
            }
            created_log = call_log_repo.create_call_log(call_data)  # Sync call
            if created_log:
                imported_count += 1

        print(f"Total calls imported (all): {imported_count}")
        return {"status": "success", "imported_count": imported_count}

    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Failed to import all calls: {str(e)}")


@call_log_router.get("/list")
async def list_call_logs(
    current_user: dict = Depends(get_current_user),
    call_log_repo: CallLogRepository = Depends(CallLogRepository),
    limit: int = 20,
    filter_type: Optional[str] = None,
):
    try:
        if filter_type:
            call_logs = call_log_repo.get_call_logs_by_type(filter_type=filter_type, limit=limit)
        else:
            call_logs = call_log_repo.get_recent_call_logs(limit=limit)
        call_logs = serialize_object(call_logs)
        return {"call_logs": call_logs}
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Failed to list call logs: {str(e)}")


@call_log_router.delete("/cleare-all")
async def delete_all_call_logs(
    current_user: dict = Depends(get_current_user),
    call_log_repo: CallLogRepository = Depends(CallLogRepository),
):
    try:
        deleted_count = call_log_repo.delete_all_call_logs()
        return {"status": "success", "deleted_count": deleted_count}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
