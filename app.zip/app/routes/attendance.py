
from fastapi import APIRouter, HTTPException, Query, Body, Depends
from typing import Dict, Optional, List, Any
from bson import ObjectId
from datetime import datetime, timedelta
import logging
import calendar

from app.database import get_database
from app.dependencies import get_current_user
from app.routes.employees import (
    extract_user_roles, 
    has_admin_or_hr_permission, 
    make_serializable
)
from app.models.auth import UserInfo

# Configure logger
logger = logging.getLogger(__name__)

# Initialize router
attendance_router = APIRouter(prefix="/api/attendance", tags=["attendance"])

def find_user_by_multiple_ids(db, user_id: str):
   
    # Try user_id field first (for role-based IDs like USR-101)
    user = db.users.find_one({"user_id": user_id})
    if user:
        return user
    
    # If not found, try _id field (if it's a valid ObjectId)
    if ObjectId.is_valid(user_id):
        user = db.users.find_one({"_id": ObjectId(user_id)})
        if user:
            return user
    
    # If still not found, try id field
    user = db.users.find_one({"id": user_id})
    if user:
        return user
    
    # If still not found, try username
    user = db.users.find_one({"username": user_id})
    if user:
        return user
    
    # If still not found, try email
    user = db.users.find_one({"email": user_id})
    if user:
        return user
    
    return None

@attendance_router.post("/checkin", status_code=201)
async def checkin_attendance(
    payload: Dict = Body(...),
    current_user: UserInfo = Depends(get_current_user)
):
    try:
        db = get_database()
        user_roles = extract_user_roles(current_user.dict())
        
        user_id = payload.get("user_id")
        action = payload.get("action", "checkin")  # checkin or checkout
        notes = payload.get("notes", "")
        latitude = payload.get("latitude")
        longitude = payload.get("longitude")
        
        if not user_id:
            raise HTTPException(status_code=400, detail="user_id is required")
        
        # Authorization check: users can only check in/out for themselves unless they're admin/HR
        current_user_id = current_user.id or getattr(current_user, "user_id", None) or current_user.username
        is_admin_or_hr = has_admin_or_hr_permission(user_roles)
        
        if not is_admin_or_hr and user_id != current_user_id:
            raise HTTPException(status_code=403, detail="You can only manage your own attendance")
        
        # Verify user exists - try multiple ID fields
        user = find_user_by_multiple_ids(db, user_id)
        
        if not user:
            logger.error(f"Employee not found for user_id: {user_id}")
            raise HTTPException(status_code=404, detail="Employee not found")
        
        today = datetime.now().strftime("%Y-%m-%d")
        current_time = datetime.now()
        
        # Check if already has record today
        existing_record = db.attendance.find_one({
            "user_id": user_id,
            "date": today
        })
        
        # Initialize variables to avoid "possibly unbound" errors
        message = "No action performed"
        working_hours = 0
        
        if action == "checkin":
            if existing_record and existing_record.get("checkin_time"):
                raise HTTPException(status_code=400, detail="Already checked in today")
            
            # Create or update checkin record
            attendance_record = {
                "user_id": user_id,
                "user_name": user.get("full_name", user.get("username")),
                "date": today,
                "checkin_time": current_time,
                "checkout_time": None,
                "status": "present",
                "working_hours": 0,
                "notes": notes,
                "location": {
                    "latitude": latitude,
                    "longitude": longitude
                } if latitude and longitude else None,
                "created_at": current_time,
                "updated_at": current_time
            }
            
            if existing_record:
                db.attendance.update_one(
                    {"user_id": user_id, "date": today},
                    {"$set": attendance_record}
                )
            else:
                db.attendance.insert_one(attendance_record)
            
            message = "Checked in successfully"
            
        elif action == "checkout":
            if not existing_record or not existing_record.get("checkin_time"):
                raise HTTPException(status_code=400, detail="No checkin record found for today")
            
            if existing_record.get("checkout_time"):
                raise HTTPException(status_code=400, detail="Already checked out today")
            
            # Calculate working hours
            checkin_time = existing_record["checkin_time"]
            if isinstance(checkin_time, str):
                checkin_time = datetime.fromisoformat(checkin_time.replace('Z', '+00:00'))
            
            working_hours = (current_time - checkin_time).total_seconds() / 3600
            
            # Update checkout
            db.attendance.update_one(
                {"user_id": user_id, "date": today},
                {"$set": {
                    "checkout_time": current_time,
                    "working_hours": round(working_hours, 2),
                    "notes": notes,
                    "updated_at": current_time
                }}
            )
            
            message = "Checked out successfully"
        else:
            raise HTTPException(status_code=400, detail="Invalid action. Must be 'checkin' or 'checkout'")
        
        return {
            "success": True,
            "message": message,
            "timestamp": current_time,
            "working_hours": round(working_hours, 2) if action == "checkout" else 0
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error recording attendance: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to record attendance: {str(e)}")

@attendance_router.post("/{employee_id}/checkin", status_code=201)
async def employee_checkin(
    employee_id: str,
    payload: Dict = Body(...),
    current_user: UserInfo = Depends(get_current_user)
):
    """Check in attendance for specific employee with geolocation support"""
    try:
        db = get_database()
        user_roles = extract_user_roles(current_user.dict())
        
        # Authorization check
        current_user_id = current_user.id or getattr(current_user, "user_id", None) or current_user.username
        is_admin_or_hr = has_admin_or_hr_permission(user_roles)
        
        if not is_admin_or_hr and employee_id != current_user_id:
            raise HTTPException(status_code=403, detail="You can only manage your own attendance")
        
        # Verify user exists
        user = find_user_by_multiple_ids(db, employee_id)
        if not user:
            raise HTTPException(status_code=404, detail="Employee not found")
        
        # Get data from payload
        today = payload.get("date", datetime.now().strftime("%Y-%m-%d"))
        current_time = datetime.now()
        
        # Location data from your attendance system
        geo_lat = payload.get("geo_lat")
        geo_long = payload.get("geo_long") 
        location_name = payload.get("location_name", payload.get("location", "Office"))
        attendance_status = payload.get("status", "present")
        time_provided = payload.get("time")
        notes = payload.get("notes", "")
        
        # Parse time if provided
        if time_provided:
            try:
                if isinstance(time_provided, str):
                    current_time = datetime.fromisoformat(time_provided.replace('Z', '+00:00'))
                else:
                    current_time = time_provided
            except:
                current_time = datetime.now()
        
        # Check if already checked in today
        existing_record = db.attendance.find_one({
            "user_id": employee_id,
            "date": today
        })
        
        # Allow update if status was "absent" and now marking "present" (rescue scenario)
        if existing_record and existing_record.get("checkin_time") and existing_record.get("status") == "present":
            raise HTTPException(status_code=400, detail="Already checked in today")
        
        # Create or update checkin record
        attendance_record = {
            "user_id": employee_id,
            "employee_id": employee_id,
            "employee_name": user.get("full_name", user.get("username")),
            "date": today,
            "checkin_time": current_time,
            "checkout_time": None,
            "status": attendance_status,
            "working_hours": 0,
            "notes": notes,
            "location": location_name,
            "location_name": location_name,
            "geo_lat": geo_lat,
            "geo_long": geo_long,
            "time": current_time,
            "created_at": current_time,
            "updated_at": current_time
        }
        
        if existing_record:
            # Update existing record (rescue scenario)
            db.attendance.update_one(
                {"user_id": employee_id, "date": today},
                {"$set": attendance_record}
            )
            action_message = "Attendance updated successfully"
        else:
            # Create new record
            result = db.attendance.insert_one(attendance_record)
            attendance_record["_id"] = result.inserted_id
            action_message = "Checked in successfully"
        
        return {
            "success": True,
            "message": action_message,
            "timestamp": current_time,
            "data": {
                "employee_id": employee_id,
                "date": today,
                "status": attendance_status,
                "location": location_name,
                "geo_lat": geo_lat,
                "geo_long": geo_long
            }
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error checking in employee: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to check in: {str(e)}")

@attendance_router.post("/{employee_id}/checkout", status_code=201)
async def employee_checkout(
    employee_id: str,
    payload: Dict = Body(...),
    current_user: UserInfo = Depends(get_current_user)
):
    """Check out attendance for specific employee with geolocation support"""
    try:
        db = get_database()
        user_roles = extract_user_roles(current_user.dict())
        
        # Authorization check
        current_user_id = current_user.id or getattr(current_user, "user_id", None) or current_user.username
        is_admin_or_hr = has_admin_or_hr_permission(user_roles)
        
        if not is_admin_or_hr and employee_id != current_user_id:
            raise HTTPException(status_code=403, detail="You can only manage your own attendance")
        
        # Verify user exists
        user = db.users.find_one({"user_id": employee_id})
        if not user:
            raise HTTPException(status_code=404, detail="Employee not found")
        
        today = payload.get("date", datetime.now().strftime("%Y-%m-%d"))
        current_time = datetime.now()
        
        # Location data from your attendance system
        geo_lat = payload.get("geo_lat")
        geo_long = payload.get("geo_long")
        location_name = payload.get("location_name", payload.get("location", "Office"))
        time_provided = payload.get("time")
        notes = payload.get("notes", "")
        
        # Parse time if provided
        if time_provided:
            try:
                if isinstance(time_provided, str):
                    current_time = datetime.fromisoformat(time_provided.replace('Z', '+00:00'))
                else:
                    current_time = time_provided
            except:
                current_time = datetime.now()
        
        # Check if has checkin record today
        existing_record = db.attendance.find_one({
            "user_id": employee_id,
            "date": today
        })
        
        if not existing_record or not existing_record.get("checkin_time"):
            raise HTTPException(status_code=400, detail="No checkin record found for today")
        
        if existing_record.get("checkout_time"):
            raise HTTPException(status_code=400, detail="Already checked out today")
        
        # Calculate working hours - Add None check
        checkin_time = existing_record["checkin_time"]
        if checkin_time is None:
            raise HTTPException(status_code=400, detail="Invalid checkin time")
            
        if isinstance(checkin_time, str):
            checkin_time = datetime.fromisoformat(checkin_time.replace('Z', '+00:00'))
        
        # Ensure both times are valid before calculation
        if current_time is None or checkin_time is None:
            raise HTTPException(status_code=400, detail="Invalid time values for calculation")
        working_hours = (current_time - checkin_time).total_seconds() / 3600
        
        # Update checkout with geolocation data
        checkout_data = {
            "checkout_time": current_time,
            "working_hours": round(working_hours, 2) if working_hours is not None else 0,
            "notes": notes,
            "updated_at": current_time
        }
        
        # Add geolocation data if provided
        if geo_lat is not None:
            checkout_data["checkout_geo_lat"] = geo_lat
            # Also update the main geo_lat for consistency
            checkout_data["geo_lat"] = geo_lat
        if geo_long is not None:
            checkout_data["checkout_geo_long"] = geo_long
            # Also update the main geo_long for consistency
            checkout_data["geo_long"] = geo_long
        if location_name:
            checkout_data["checkout_location"] = location_name
            # Also update the main location fields for consistency
            checkout_data["location"] = location_name
            checkout_data["location_name"] = location_name
        
        # Update the time field to checkout time for consistency
        checkout_data["time"] = current_time
        
        db.attendance.update_one(
            {"user_id": employee_id, "date": today},
            {"$set": checkout_data}
        )
        
        working_hours_result = int(round(working_hours, 2)) if working_hours is not None else 0
        
        return {
            "success": True,
            "message": "Checked out successfully",
            "timestamp": current_time,
            "working_hours": working_hours_result,
            "data": {
                "employee_id": employee_id,
                "date": today,
                "checkout_time": current_time,
                "working_hours": working_hours_result,
                "checkout_location": location_name,
                "checkout_geo_lat": geo_lat,
                "checkout_geo_long": geo_long
            }
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error checking out employee: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to check out: {str(e)}")

@attendance_router.get("/records", status_code=200)
async def get_attendance_records(
    page: int = Query(1, description="Page number"),
    limit: int = Query(100, description="Items per page"),
    date: Optional[str] = Query(None, description="Specific date (YYYY-MM-DD)"),
    month: Optional[int] = Query(None, description="Month (1-12)"),
    year: Optional[int] = Query(None, description="Year"),
    employee_id: Optional[str] = Query(None, description="Filter by employee ID"),
    department: Optional[str] = Query(None, description="Filter by department"),
    status: Optional[str] = Query(None, description="Filter by status (present/absent)"),
    search: Optional[str] = Query(None, description="Search by employee name or ID"),
    current_user: UserInfo = Depends(get_current_user)
):
    """Get all attendance collection data - Admin endpoint with comprehensive filtering"""
    try:
        db = get_database()
        user_roles = extract_user_roles(current_user.dict())
        
        # Check if user has admin/HR permissions
        is_admin_or_hr = has_admin_or_hr_permission(user_roles)
        current_user_id = current_user.id or getattr(current_user, "user_id", None) or current_user.username
        
        # Build query
        query = {}
        
        # Date filtering
        if date:
            query["date"] = date
        elif month and year:
            # Get all dates in the specified month
            start_date = datetime(year, month, 1).strftime("%Y-%m-%d")
            end_date = datetime(year, month, calendar.monthrange(year, month)[1]).strftime("%Y-%m-%d")
            query["date"] = {"$gte": start_date, "$lte": end_date}
        elif not date and not month and not year:
            # Default to current month if no date filters specified
            now = datetime.now()
            start_date = datetime(now.year, now.month, 1).strftime("%Y-%m-%d")
            end_date = datetime(now.year, now.month, calendar.monthrange(now.year, now.month)[1]).strftime("%Y-%m-%d")
            query["date"] = {"$gte": start_date, "$lte": end_date}
        
        # Employee ID filter - role-based access control
        if employee_id:
            if is_admin_or_hr:
                query["user_id"] = employee_id
            elif employee_id == current_user_id:
                query["user_id"] = employee_id
            else:
                raise HTTPException(status_code=403, detail="You can only view your own attendance records")
        elif not is_admin_or_hr:
            # Regular users can only see their own records
            query["user_id"] = current_user_id
        
        # Status filter
        if status:
            query["status"] = status
        
        # Department filter - need to get user IDs from users collection
        user_ids_for_dept = None
        if department:
            dept_users = list(db.users.find({"department": department}, {"user_id": 1}))
            user_ids_for_dept = [user["user_id"] for user in dept_users]
            if user_ids_for_dept:
                if "user_id" in query:
                    # If employee_id filter already exists, combine with department filter
                    if query["user_id"] in user_ids_for_dept:
                        pass  # Keep existing employee_id filter
                    else:
                        query["user_id"] = {"$in": []}  # No match
                else:
                    query["user_id"] = {"$in": user_ids_for_dept}
            else:
                query["user_id"] = {"$in": []}  # No users in department
        
        # Search filter - search by employee name
        search_user_ids = None
        if search:
            search_users = list(db.users.find({
                "$or": [
                    {"full_name": {"$regex": search, "$options": "i"}},
                    {"user_id": {"$regex": search, "$options": "i"}},
                    {"email": {"$regex": search, "$options": "i"}}
                ]
            }, {"user_id": 1}))
            search_user_ids = [user["user_id"] for user in search_users]
            
            if search_user_ids:
                if "user_id" in query:
                    if isinstance(query["user_id"], dict) and "$in" in query["user_id"]:
                        # Intersection with existing user_id filter
                        query["user_id"]["$in"] = list(set(query["user_id"]["$in"]) & set(search_user_ids))
                    elif isinstance(query["user_id"], str):
                        # Check if existing user_id is in search results
                        if query["user_id"] not in search_user_ids:
                            query["user_id"] = {"$in": []}  # No match
                    else:
                        query["user_id"] = {"$in": search_user_ids}
                else:
                    query["user_id"] = {"$in": search_user_ids}
            else:
                query["user_id"] = {"$in": []}  # No matching users found
        
        # Get total count for pagination
        total = db.attendance.count_documents(query)
        
        # Apply pagination
        skip = (page - 1) * limit
        
        # Get attendance records with sorting
        attendance_records = list(
            db.attendance.find(query)
            .sort([("date", -1), ("checkin_time", 1)])
            .skip(skip)
            .limit(limit)
        )
        
        # Enhance records with employee details
        enhanced_records = []
        user_cache = {}  # Cache user details to avoid repeated queries
        
        for record in attendance_records:
            user_id = record.get("user_id")
            
            # Get user details (use cache if available)
            if user_id not in user_cache:
                user = db.users.find_one({"user_id": user_id})
                user_cache[user_id] = user
            else:
                user = user_cache[user_id]
            
            # Get employee details from employees collection
            employee = db.employees.find_one({"user_id": user_id})
            
            # Build enhanced record
            enhanced_record = dict(record)
            enhanced_record["employee_details"] = {
                "employee_id": user_id,
                "user_id": user_id,
                "full_name": user.get("full_name", "") if user else "",
                "email": user.get("email", "") if user else "",
                "phone": user.get("phone", "") if user else "",
                "department": user.get("department", "") if user else "",
                "position": employee.get("position", "") if employee else user.get("position", "") if user else "",
                "emp_id": employee.get("emp_id", "") if employee else "",
                "is_active": user.get("is_active", True) if user else False
            }
            
            # Add calculated fields
            if record.get("checkin_time") and record.get("checkout_time"):
                checkin = record["checkin_time"]
                checkout = record["checkout_time"]
                
                # Ensure datetime objects
                if isinstance(checkin, str):
                    checkin = datetime.fromisoformat(checkin.replace('Z', '+00:00'))
                if isinstance(checkout, str):
                    checkout = datetime.fromisoformat(checkout.replace('Z', '+00:00'))
                
                # Calculate actual working hours if not stored
                # Add None checks to prevent "Operator '>' not supported for 'None'" error
                if checkin is not None and checkout is not None:
                    if not enhanced_record.get("working_hours"):
                        working_hours = (checkout - checkin).total_seconds() / 3600
                        enhanced_record["calculated_working_hours"] = int(round(working_hours, 2))

            
            enhanced_records.append(enhanced_record)
        
        # Calculate summary statistics
        summary_stats = {
            "total_records": total,
            "present_count": db.attendance.count_documents({**query, "status": "present"}),
            "absent_count": db.attendance.count_documents({**query, "status": "absent"}),
            "late_count": db.attendance.count_documents({**query, "status": "late"}),
        }
        
        # Add department-wise breakdown if no specific filters
        department_breakdown = []
        if not department and not employee_id:
            pipeline = [
                {"$match": query},
                {
                    "$lookup": {
                        "from": "users",
                        "localField": "user_id",
                        "foreignField": "user_id",
                        "as": "user_info"
                    }
                },
                {"$unwind": "$user_info"},
                {
                    "$group": {
                        "_id": "$user_info.department",
                        "total": {"$sum": 1},
                        "present": {"$sum": {"$cond": [{"$eq": ["$status", "present"]}, 1, 0]}},
                        "absent": {"$sum": {"$cond": [{"$eq": ["$status", "absent"]}, 1, 0]}}
                    }
                },
                {"$sort": {"_id": 1}}
            ]
            department_breakdown = list(db.attendance.aggregate(pipeline))
        
        return make_serializable({
            "success": True,
            "message": "Attendance data retrieved successfully",
            "data": enhanced_records,
            "pagination": {
                "page": page,
                "limit": limit,
                "total": total,
                "pages": (total + limit - 1) // limit,
                "has_next": page * limit < total,
                "has_prev": page > 1
            },
            "summary": summary_stats,
            "department_breakdown": department_breakdown,
            "filters_applied": {
                "date": date,
                "month": month,
                "year": year,
                "employee_id": employee_id,
                "department": department,
                "status": status,
                "search": search
            }
        })
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting attendance records: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to get attendance data: {str(e)}")

@attendance_router.post("/admin/checkout", status_code=201)
async def admin_checkout_employee(
    payload: Dict = Body(...),
    current_user: UserInfo = Depends(get_current_user)
):
    """Admin checkout endpoint for handling frontend requests"""
    try:
        db = get_database()
        user_roles = extract_user_roles(current_user.dict())
        
        # Check if user has admin/HR permissions
        if not has_admin_or_hr_permission(user_roles):
            raise HTTPException(status_code=403, detail="Insufficient permissions")
        
        # Extract employee_id from payload
        employee_id = payload.get("employee_id") or payload.get("user_id")
        
        if not employee_id:
            raise HTTPException(status_code=400, detail="employee_id is required in payload")
        
        # Verify user exists
        user = db.users.find_one({"user_id": employee_id})
        if not user:
            raise HTTPException(status_code=404, detail="Employee not found")
        
        today = payload.get("date", datetime.now().strftime("%Y-%m-%d"))
        current_time = datetime.now()
        
        # Location data from payload
        geo_lat = payload.get("geo_lat")
        geo_long = payload.get("geo_long")
        location_name = payload.get("location_name", payload.get("location", "Office"))
        time_provided = payload.get("time")
        notes = payload.get("notes", "")
        
        # Parse time if provided
        if time_provided:
            try:
                if isinstance(time_provided, str):
                    current_time = datetime.fromisoformat(time_provided.replace('Z', '+00:00'))
                else:
                    current_time = time_provided
            except:
                current_time = datetime.now()
        
        # Check if has checkin record today
        existing_record = db.attendance.find_one({
            "user_id": employee_id,
            "date": today
        })
        
        if not existing_record or not existing_record.get("checkin_time"):
            raise HTTPException(status_code=400, detail="No checkin record found for today")
        
        if existing_record.get("checkout_time"):
            raise HTTPException(status_code=400, detail="Already checked out today")
        
        # Calculate working hours - Add None check
        checkin_time = existing_record["checkin_time"]
        if checkin_time is None:
            raise HTTPException(status_code=400, detail="Invalid checkin time")
            
        if isinstance(checkin_time, str):
            checkin_time = datetime.fromisoformat(checkin_time.replace('Z', '+00:00'))
        
        # Ensure both times are valid before calculation
        if current_time is None or checkin_time is None:
            raise HTTPException(status_code=400, detail="Invalid time values for calculation")
            
        working_hours = (current_time - checkin_time).total_seconds() / 3600
        
        # Update checkout with geolocation data
        checkout_data = {
            "checkout_time": current_time,
            "working_hours": round(working_hours, 2) if working_hours is not None else 0,
            "notes": notes,
            "updated_at": current_time
        }
        
        # Add geolocation data if provided
        if geo_lat is not None:
            checkout_data["checkout_geo_lat"] = geo_lat
            # Also update the main geo_lat for consistency
            checkout_data["geo_lat"] = geo_lat
        if geo_long is not None:
            checkout_data["checkout_geo_long"] = geo_long
            # Also update the main geo_long for consistency
            checkout_data["geo_long"] = geo_long
        if location_name:
            checkout_data["checkout_location"] = location_name
            # Also update the main location fields for consistency
            checkout_data["location"] = location_name
            checkout_data["location_name"] = location_name
        
        # Update the time field to checkout time for consistency
        checkout_data["time"] = current_time
        
        db.attendance.update_one(
            {"user_id": employee_id, "date": today},
            {"$set": checkout_data}
        )
        
        working_hours_result = round(working_hours, 2) if working_hours is not None else 0
        
        return {
            "success": True,
            "message": "Checked out successfully",
            "timestamp": current_time,
            "working_hours": working_hours_result,
            "data": {
                "employee_id": employee_id,
                "date": today,
                "checkout_time": current_time,
                "working_hours": working_hours_result,
                "checkout_location": location_name,
                "checkout_geo_lat": geo_lat,
                "checkout_geo_long": geo_long
            }
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error in admin checkout: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to check out: {str(e)}")

@attendance_router.put("/records/{record_id}", status_code=200)
async def edit_attendance_record(
    record_id: str,
    payload: Dict = Body(...),
    current_user: UserInfo = Depends(get_current_user)
):
    """Edit attendance record (HR only)"""
    try:
        db = get_database()
        user_roles = extract_user_roles(current_user.dict())
        
        # Check HR permission
        if not has_admin_or_hr_permission(user_roles):
            raise HTTPException(status_code=403, detail="Insufficient permissions")
        
        # Find attendance record
        record = db.attendance.find_one({"_id": ObjectId(record_id)})
        if not record:
            raise HTTPException(status_code=404, detail="Attendance record not found")
        
        # Update fields
        update_data = {}
        editable_fields = ["checkin_time", "checkout_time", "status", "notes", "working_hours"]
        
        for field in editable_fields:
            if field in payload:
                if field in ["checkin_time", "checkout_time"] and payload[field]:
                    # Convert to datetime if string
                    if isinstance(payload[field], str):
                        update_data[field] = datetime.fromisoformat(payload[field].replace('Z', '+00:00'))
                    else:
                        update_data[field] = payload[field]
                else:
                    update_data[field] = payload[field]
        
        # Recalculate working hours if both times are provided
        if "checkin_time" in update_data and "checkout_time" in update_data:
            if update_data["checkin_time"] and update_data["checkout_time"]:
                # Add None checks to prevent "Operator '>' not supported for 'None'" error
                checkin_time = update_data["checkin_time"]
                checkout_time = update_data["checkout_time"]
                if checkin_time is not None and checkout_time is not None:
                    working_hours = (checkout_time - checkin_time).total_seconds() / 3600
                    update_data["working_hours"] = int(round(working_hours, 2))
        
        update_data["updated_at"] = datetime.now()
        
        # Update record
        db.attendance.update_one(
            {"_id": ObjectId(record_id)},
            {"$set": update_data}
        )
        
        return {
            "success": True,
            "message": "Attendance record updated successfully"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error editing attendance record: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to edit attendance record: {str(e)}")

@attendance_router.get("/admin", status_code=200)
async def get_admin_attendance_data(
    page: int = Query(1, description="Page number"),
    limit: int = Query(100, description="Items per page"),
    date: Optional[str] = Query(None, description="Specific date (YYYY-MM-DD)"),
    month: Optional[int] = Query(None, description="Month (1-12)"),
    year: Optional[int] = Query(None, description="Year"),
    employee_id: Optional[str] = Query(None, description="Filter by employee ID"),
    department: Optional[str] = Query(None, description="Filter by department"),
    status: Optional[str] = Query(None, description="Filter by status (present/absent)"),
    search: Optional[str] = Query(None, description="Search by employee name or ID"),
    current_user: UserInfo = Depends(get_current_user)
):
    """Get all attendance collection data - Admin endpoint with comprehensive filtering"""
    try:
        # Check HR permission
        user_roles = extract_user_roles(current_user.dict())
        if not has_admin_or_hr_permission(user_roles):
            raise HTTPException(status_code=403, detail="Insufficient permissions")
        
        db = get_database()
        
        # Build query
        query = {}
        
        # Date filtering
        if date:
            query["date"] = date
        elif month and year:
            # Get all dates in the specified month
            start_date = datetime(year, month, 1).strftime("%Y-%m-%d")
            end_date = datetime(year, month, calendar.monthrange(year, month)[1]).strftime("%Y-%m-%d")
            query["date"] = {"$gte": start_date, "$lte": end_date}
        elif not date and not month and not year:
            # Default to current month if no date filters specified
            now = datetime.now()
            start_date = datetime(now.year, now.month, 1).strftime("%Y-%m-%d")
            end_date = datetime(now.year, now.month, calendar.monthrange(now.year, now.month)[1]).strftime("%Y-%m-%d")
            query["date"] = {"$gte": start_date, "$lte": end_date}
        
        # Employee ID filter
        if employee_id:
            query["user_id"] = employee_id
        
        # Status filter
        if status:
            query["status"] = status
        
        # Department filter - need to get user IDs from users collection
        user_ids_for_dept = None
        if department:
            dept_users = list(db.users.find({"department": department}, {"user_id": 1}))
            user_ids_for_dept = [user["user_id"] for user in dept_users]
            if user_ids_for_dept:
                if "user_id" in query:
                    # If employee_id filter already exists, combine with department filter
                    if query["user_id"] in user_ids_for_dept:
                        pass  # Keep existing employee_id filter
                    else:
                        query["user_id"] = {"$in": []}  # No match
                else:
                    query["user_id"] = {"$in": user_ids_for_dept}
            else:
                query["user_id"] = {"$in": []}  # No users in department
        
        # Search filter - search by employee name
        search_user_ids = None
        if search:
            search_users = list(db.users.find({
                "$or": [
                    {"full_name": {"$regex": search, "$options": "i"}},
                    {"user_id": {"$regex": search, "$options": "i"}},
                    {"email": {"$regex": search, "$options": "i"}}
                ]
            }, {"user_id": 1}))
            search_user_ids = [user["user_id"] for user in search_users]
            
            if search_user_ids:
                if "user_id" in query:
                    if isinstance(query["user_id"], dict) and "$in" in query["user_id"]:
                        # Intersection with existing user_id filter
                        query["user_id"]["$in"] = list(set(query["user_id"]["$in"]) & set(search_user_ids))
                    elif isinstance(query["user_id"], str):
                        # Check if existing user_id is in search results
                        if query["user_id"] not in search_user_ids:
                            query["user_id"] = {"$in": []}  # No match
                    else:
                        query["user_id"] = {"$in": search_user_ids}
                else:
                    query["user_id"] = {"$in": search_user_ids}
            else:
                query["user_id"] = {"$in": []}  # No matching users found
        
        # Get total count for pagination
        total = db.attendance.count_documents(query)
        
        # Apply pagination
        skip = (page - 1) * limit
        
        # Get attendance records with sorting
        attendance_records = list(
            db.attendance.find(query)
            .sort([("date", -1), ("checkin_time", 1)])
            .skip(skip)
            .limit(limit)
        )
        
        # Enhance records with employee details
        enhanced_records = []
        user_cache = {}  # Cache user details to avoid repeated queries
        
        for record in attendance_records:
            user_id = record.get("user_id")
            
            # Get user details (use cache if available)
            if user_id not in user_cache:
                user = db.users.find_one({"user_id": user_id})
                user_cache[user_id] = user
            else:
                user = user_cache[user_id]
            
            # Get employee details from employees collection
            employee = db.employees.find_one({"user_id": user_id})
            
            # Build enhanced record
            enhanced_record = dict(record)
            enhanced_record["employee_details"] = {
                "employee_id": user_id,
                "user_id": user_id,
                "full_name": user.get("full_name", "") if user else "",
                "email": user.get("email", "") if user else "",
                "phone": user.get("phone", "") if user else "",
                "department": user.get("department", "") if user else "",
                "position": employee.get("position", "") if employee else user.get("position", "") if user else "",
                "emp_id": employee.get("emp_id", "") if employee else "",
                "is_active": user.get("is_active", True) if user else False
            }
            
            # Add calculated fields
            if record.get("checkin_time") and record.get("checkout_time"):
                checkin = record["checkin_time"]
                checkout = record["checkout_time"]
                
                # Ensure datetime objects
                if isinstance(checkin, str):
                    checkin = datetime.fromisoformat(checkin.replace('Z', '+00:00'))
                if isinstance(checkout, str):
                    checkout = datetime.fromisoformat(checkout.replace('Z', '+00:00'))
                
                # Calculate actual working hours if not stored
                # Add None checks to prevent "Operator '>' not supported for 'None'" error
                if checkin is not None and checkout is not None:
                    if not enhanced_record.get("working_hours"):
                        working_hours = (checkout - checkin).total_seconds() / 3600
                        enhanced_record["calculated_working_hours"] = int(round(working_hours, 2))

            
            enhanced_records.append(enhanced_record)
        
        # Calculate summary statistics
        summary_stats = {
            "total_records": total,
            "present_count": db.attendance.count_documents({**query, "status": "present"}),
            "absent_count": db.attendance.count_documents({**query, "status": "absent"}),
            "late_count": db.attendance.count_documents({**query, "status": "late"}),
        }
        
        # Add department-wise breakdown if no specific filters
        department_breakdown = []
        if not department and not employee_id:
            pipeline = [
                {"$match": query},
                {
                    "$lookup": {
                        "from": "users",
                        "localField": "user_id",
                        "foreignField": "user_id",
                        "as": "user_info"
                    }
                },
                {"$unwind": "$user_info"},
                {
                    "$group": {
                        "_id": "$user_info.department",
                        "total": {"$sum": 1},
                        "present": {"$sum": {"$cond": [{"$eq": ["$status", "present"]}, 1, 0]}},
                        "absent": {"$sum": {"$cond": [{"$eq": ["$status", "absent"]}, 1, 0]}}
                    }
                },
                {"$sort": {"_id": 1}}
            ]
            department_breakdown = list(db.attendance.aggregate(pipeline))
        
        return make_serializable({
            "success": True,
            "message": "Attendance data retrieved successfully",
            "data": enhanced_records,
            "pagination": {
                "page": page,
                "limit": limit,
                "total": total,
                "pages": (total + limit - 1) // limit,
                "has_next": page * limit < total,
                "has_prev": page > 1
            },
            "summary": summary_stats,
            "department_breakdown": department_breakdown,
            "filters_applied": {
                "date": date,
                "month": month,
                "year": year,
                "employee_id": employee_id,
                "department": department,
                "status": status,
                "search": search
            }
        })
        
    except Exception as e:
        logger.error(f"Error getting admin attendance data: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to get attendance data: {str(e)}")


@attendance_router.get("/export")
async def export_attendance_report(
    month: Optional[int] = Query(None, description="Month (1-12)"),
    year: Optional[int] = Query(None, description="Year"),
    format: str = Query("csv", description="Export format: csv or excel"),
    current_user: UserInfo = Depends(get_current_user)
):
    """Export attendance report for the current user"""
    try:
        db = get_database()
        
        # Set default values if not provided
        if not month:
            month = datetime.now().month
        if not year:
            year = datetime.now().year
            
        # Find user by multiple ID patterns
        user = find_user_by_multiple_ids(db, current_user.id)
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        
        user_id = str(user.get("_id"))
        
        # Create date range for the month
        start_date = datetime(year, month, 1)
        if month == 12:
            end_date = datetime(year + 1, 1, 1) - timedelta(seconds=1)
        else:
            end_date = datetime(year, month + 1, 1) - timedelta(seconds=1)
        
        # Get attendance records for the month
        attendance_records = list(db.attendance.find({
            "user_id": current_user.id,
            "date": {
                "$gte": start_date.strftime("%Y-%m-%d"),
                "$lte": end_date.strftime("%Y-%m-%d")
            }
        }).sort("date", 1))
        
        # Process records for export
        export_data = []
        for record in attendance_records:
            processed_record = {
                "Date": record.get("date", ""),
                "Check In": record.get("checkin_time", ""),
                "Check Out": record.get("checkout_time", ""),
                "Working Hours": record.get("working_hours", ""),
                "Status": record.get("status", ""),
                "Location": record.get("location_name", record.get("location", "")),
                "Notes": record.get("notes", "")
            }
            export_data.append(processed_record)
        
        # Generate filename
        month_name = calendar.month_name[month]
        filename = f"attendance_report_{user.get('name', 'user')}_{month_name}_{year}"
        
        return {
            "success": True,
            "data": export_data,
            "metadata": {
                "filename": filename,
                "month": month,
                "year": year,
                "month_name": month_name,
                "employee_name": user.get("full_name", user.get("name", "Unknown")),
                "employee_id": user.get("user_id", current_user.id),
                "total_records": len(export_data),
                "format": format
            }
        }
        
    except Exception as e:
        logger.error(f"Error exporting attendance report: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to export report: {str(e)}")