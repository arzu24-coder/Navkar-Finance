"""
Employee Utility Functions
Shared helper functions for employee-related operations
"""
from typing import List, Dict, Any
from datetime import datetime
import random
import logging

# Configure logger
logger = logging.getLogger(__name__)

# Define valid employee roles/positions
VALID_EMPLOYEE_ROLES = {
    "hr": "HR",
    "manager": "Manager", 
    "sales": "Sales",
    "sales_executive": "Sales Executive",
    "sales_manager": "Sales Manager",
    "executive": "Executive",
    "team_leader": "Team Leader",
    "admin": "Admin",
    "administrator": "Administrator",
    "hr_manager": "HR Manager",
    "hr_executive": "HR Executive",
    "supervisor": "Supervisor",
    "assistant": "Assistant",
    "intern": "Intern",
    "employee": "Employee",
    "finance": "Finance",
    "finance_manager": "Finance Manager",
    "marketing": "Marketing",
    "marketing_manager": "Marketing Manager",
    "operations": "Operations",
    "operations_manager": "Operations Manager",
    "it": "IT",
    "it_support": "IT Support",
    "developer": "Developer",
    "ceo": "CEO",
    "cfo": "CFO",
    "cto": "CTO",
    "director": "Director",
    "user":"User"
}

def extract_user_roles(current_user: dict) -> List[str]:
    """Extract user roles from current_user dict, handling both string and list formats"""
    roles = current_user.get("roles", [])
    
    # Handle case where roles might be a string
    if isinstance(roles, str):
        return [roles]
    elif isinstance(roles, list):
        return roles
    else:
        # Fallback to empty list if roles format is unexpected
        return []

def has_admin_or_hr_permission(user_roles: List[str]) -> bool:
    """Check if user has Admin or HR permissions"""
    authorized_roles = ["hr", "admin", "hr_manager", "human_resources", "administrator"]
    
    # Handle case where user_roles might be a string instead of list
    if isinstance(user_roles, str):
        user_roles = [user_roles]
    
    # Log for debugging
    logger.info(f"Checking HR permission for roles: {user_roles}")
    
    # Check both direct role matching and case-insensitive matching
    has_permission = any(str(role).lower() in authorized_roles for role in user_roles)
    
    logger.info(f"HR permission check result: {has_permission}")
    return has_permission

def can_manage_leave_requests(user_roles: List[str]) -> bool:
    """Check if user has permissions to approve/reject leave requests (admin or HR roles)"""
    authorized_roles = ["hr", "admin", "hr_manager", "human_resources", "administrator"]

    # Check both direct role matching and case-insensitive matching
    has_permission = any(role.lower() in authorized_roles for role in user_roles)
    return has_permission

def make_serializable(obj):
    """Convert MongoDB document to JSON-serializable dictionary."""
    from bson import ObjectId
    from datetime import datetime, date
    
    if isinstance(obj, dict):
        return {k: make_serializable(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [make_serializable(item) for item in obj]
    elif isinstance(obj, ObjectId):
        return str(obj)
    elif isinstance(obj, datetime):
        return obj.isoformat()
    elif isinstance(obj, date):
        return obj.isoformat()
    else:
        return obj

def is_valid_employee_role(role: str) -> bool:
    """Check if the provided role is a valid employee role"""
    if not role:
        return False
        
    # If role is a dict, extract the name field
    if isinstance(role, dict):
        role = role.get("name", "")
    
    role = role.lower()
    
    # Direct match in VALID_EMPLOYEE_ROLES
    if role in VALID_EMPLOYEE_ROLES:
        return True
        
    # Check if it contains any valid role name
    for valid_role in VALID_EMPLOYEE_ROLES:
        if valid_role in role or role in valid_role:
            return True
            
    return False

def get_role_prefix(role: str) -> str:
    """Get prefix for employee ID based on role"""
    role_prefixes = {
        "hr": "HR",
        "manager": "MGR", 
        "sales": "SLS",
        "executive": "EXE",
        "team_leader": "TL",
        "admin": "ADM",
        "supervisor": "SUP",
        "assistant": "AST",
        "intern": "INT",
        "employee": "EMP"
    }
    return role_prefixes.get(role.lower(), "EMP")

def generate_user_id(db):
    """Generate unique user ID for users collection"""
    while True:
        user_id = f"USR-{random.randint(100, 999)}"
        if not db.users.find_one({"user_id": user_id}):
            return user_id

def generate_employee_id(db, role: str = "employee"):
    """Generate unique employee ID for employees collection with role-based prefix"""
    prefix = get_role_prefix(role)
    while True:
        # Generate ID with role prefix and 4-digit number
        emp_id = f"{prefix}-{random.randint(1000, 9999)}"
        if not db.employees.find_one({"emp_id": emp_id}):
            return emp_id

def check_user_exists(db, email, user_id=None, emp_id=None):
    """Check if user exists in users or employees collection"""
    # Check in users collection
    user_query = {"email": email}
    if user_id:
        user_query["$or"] = [{"email": email}, {"user_id": user_id}]
    
    existing_user = db.users.find_one(user_query)
    
    # Check in employees collection
    emp_query = {"email": email}
    if emp_id:
        emp_query["$or"] = [{"email": email}, {"emp_id": emp_id}]
    
    existing_employee = db.employees.find_one(emp_query)
    
    return existing_user, existing_employee

def should_create_employee_record(roles: List[str], position: str = "") -> bool:
    """Determine if user should have employee record based on roles/position"""
    if not roles:
        roles = []
    
    # Check if any role or position matches employee criteria
    employee_criteria = ["hr", "manager", "sales", "executive", "team_leader", "supervisor", "assistant"]
    
    # Check roles
    for role in roles:
        if isinstance(role, str) and role.lower() in employee_criteria:
            return True
        elif isinstance(role, dict) and role.get("name", "").lower() in employee_criteria:
            return True
    
    # Check position
    if position and position.lower() in employee_criteria:
        return True
    
    # Check for any role that suggests employee status
    if any(is_valid_employee_role(str(role)) for role in roles):
        return True
        
    return True  # Default to creating employee record for all users

def ensure_role_ids(db):
    """Check all roles in the database and ensure they have proper ID fields"""
    try:
        # Find roles without id field
        roles_without_id = list(db.roles.find({"id": {"$exists": False}}))
        
        for role in roles_without_id:
            # Generate a proper role ID
            role_name = role.get("name", "role").lower()
            role_prefix = role_name[:3].upper()
            new_id = f"{role_prefix}-{random.randint(100, 999)}"
            
            # Check if this ID already exists
            while db.roles.find_one({"id": new_id}):
                new_id = f"{role_prefix}-{random.randint(100, 999)}"
            
            # Update the role with the new ID
            db.roles.update_one(
                {"_id": role["_id"]},
                {"$set": {"id": new_id}}
            )
            logger.info(f"Added ID field to role {role.get('name')}: {new_id}")
        
        return len(roles_without_id)
    except Exception as e:
        logger.error(f"Failed to fix role IDs: {str(e)}")
        return 0