import os
import jwt
import json
import traceback
import secrets
from datetime import datetime, timedelta
from fastapi import APIRouter, Request, HTTPException
from fastapi.responses import JSONResponse
from authlib.integrations.starlette_client import OAuth
from fastapi.responses import JSONResponse, RedirectResponse
from app.database.schemas.user_schema import UserBase, UserCreate
from app.database.repositories.auth_repository import AuthRepository
from app.database.repositories.user_repository import UserRepository
import os
from app.services.google_auth import oauth
from app.dependencies import create_access_token
import urllib.parse
import logging

# MongoDB collection for OAuth states (survives backend restarts)
from app.database import db
oauth_states_collection = db["oauth_states"]

def cleanup_expired_states():
    """Remove expired states from database"""
    oauth_states_collection.delete_many({
        "expires_at": {"$lt": datetime.utcnow()}
    })

# -------------------- Google OAuth2 --------------------#
auth_repo = AuthRepository()
user_repo = UserRepository()

google_router = APIRouter(prefix="/api/auth", tags=["Gmail"])

@google_router.get("/login/google")
async def login_via_google(request: Request):
    try:
        logger = logging.getLogger(__name__)
        logger.info("Processing Google login request (custom state)")

        # Cleanup expired states
        cleanup_expired_states()

        # Generate custom state
        state = secrets.token_urlsafe(32)
        oauth_states_collection.insert_one({
            "state": state,
            "created_at": datetime.utcnow(),
            "expires_at": datetime.utcnow() + timedelta(minutes=10)
        })
        logger.info(f"Generated state: {state[:10]}... (stored in MongoDB)")

        # Build OAuth URL manually
        redirect_uri = os.getenv("GMAIL_REDIRECT_URI", "http://localhost:8005/api/auth/google/callback")
        client_id = os.getenv("GMAIL_CLIENT_ID", "731827166415-2hn36eq8pfvo6t3akpanckkln4tan4fv.apps.googleusercontent.com")
        redirect_uri = os.getenv("GMAIL_REDIRECT_URI", "http://localhost:8005/api/auth/google/callback")


        auth_url = "https://accounts.google.com/o/oauth2/auth"
        params = {
            "client_id": client_id,
            "redirect_uri": redirect_uri,
            "response_type": "code",
            "scope": "openid email profile https://www.googleapis.com/auth/gmail.modify", 
            "state": state,
            "access_type": "offline",   # ✅ Required for refresh token
            "prompt": "consent"         # ✅ Forces new refresh token each time
        }

        oauth_url = f"{auth_url}?{urllib.parse.urlencode(params)}"
        logger.info(f"Redirecting to: {oauth_url[:100]}...")

        return RedirectResponse(url=oauth_url, status_code=307)

    except Exception as e:
        logger = logging.getLogger(__name__)
        logger.error(f"Error in login_via_google: {str(e)}")
        logger.error(traceback.format_exc())
        return JSONResponse(
            status_code=500,
            content={
                "success": False,
                "error": "login_failed",
                "message": f"Failed to initiate Google login: {str(e)}"
            }
        )

@google_router.get("/google/callback")
async def auth_google_callback(request: Request):
    logger = logging.getLogger(__name__)
    logger.info("Processing Google OAuth callback (custom state verification)")

    try:
        # -------------------- GET OAUTH CODE + STATE -------------------- #
        state = request.query_params.get("state")
        code = request.query_params.get("code")

        if not state or not code:
            return JSONResponse(
                status_code=400,
                content={
                    "success": False,
                    "error": "missing_parameters",
                    "message": "Missing state or code in callback URL.",
                },
            )

        # -------------------- EXCHANGE CODE FOR TOKENS -------------------- #
        import aiohttp
        client_id = os.getenv("GMAIL_CLIENT_ID", "731827166415-2hn36eq8pfvo6t3akpanckkln4tan4fv.apps.googleusercontent.com")
        client_secret = os.getenv("GMAIL_CLIENT_SECRET", "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")
        redirect_uri = os.getenv("GMAIL_REDIRECT_URI", "http://localhost:8005/api/auth/google/callback")


        async with aiohttp.ClientSession() as session:
            token_data = {
                "code": code,
                "client_id": client_id,
                "client_secret": client_secret,
                "redirect_uri": redirect_uri,
                "grant_type": "authorization_code",
            }

            async with session.post("https://oauth2.googleapis.com/token", data=token_data) as resp:
                token = await resp.json()

        if "error" in token:
            logger.error(f"Token exchange error: {token}")
            return JSONResponse(status_code=400, content=token)

        access_token = token.get("access_token")
        refresh_token = token.get("refresh_token")
        expires_in = token.get("expires_in", 3600)
        id_token = token.get("id_token")

        # -------------------- GET USER INFO -------------------- #
        import jwt
        user_info = {}
        if id_token:
            user_info = jwt.decode(id_token, options={"verify_signature": False})
        else:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    "https://www.googleapis.com/oauth2/v2/userinfo",
                    headers={"Authorization": f"Bearer {access_token}"}
                ) as resp:
                    user_info = await resp.json()

        user_email = user_info.get("email")
        user_name = user_info.get("name", "Google User")
        google_user_id = user_info.get("sub") or user_info.get("id")

        if not user_email:
            return JSONResponse(status_code=400, content={"error": "Missing email in Google user info"})

        # -------------------- SAVE TO DATABASE -------------------- #
        from app.database.async_db import get_async_database
        db = get_async_database()
        if db is None:
            logger.error("Database connection failed")
            return JSONResponse(status_code=500, content={"error": "Database connection failed"})
            
        email_accounts = db.get_collection("email_accounts")

        now = datetime.utcnow()
        expires_at = now + timedelta(seconds=expires_in)

        # First, check if there's an existing application user with this email
        app_users = db.get_collection("users")
        app_user = await app_users.find_one({"email": user_email})
        
        # Use the application user ID if available, otherwise use the Google user ID
        app_user_id = None
        if app_user and "_id" in app_user:
            app_user_id = str(app_user["_id"])
        
        account_data = {
            "user_id": app_user_id,  # Use application user ID if available
            "google_user_id": google_user_id,  # Always store the Google user ID
            "email": user_email,
            "provider": "gmail",
            "account_name": f"{user_name}'s Gmail",
            "access_token": access_token,
            "refresh_token": refresh_token,
            "expires_at": expires_at.isoformat(),
            "scopes": ["https://www.googleapis.com/auth/gmail.modify"],
            "status": "active",
            "updated_at": now.isoformat(),
        }
        # -------------------- UPDATE OR INSERT -------------------- #
        existing = await email_accounts.find_one({"email": user_email, "provider": "gmail"})
        if existing:
            # Update existing account
            update_data = {
                "access_token": access_token,
                "expires_at": expires_at.isoformat(),
                "updated_at": now.isoformat()
            }
            # Fix: Always update the refresh_token if we have a new one
            # This ensures that when a different user logs in with the same email,
            # we have the correct refresh token for that user session
            if refresh_token:
                update_data["refresh_token"] = refresh_token
            
            # Update the user_id and google_user_id fields
            update_data["user_id"] = app_user_id
            update_data["google_user_id"] = google_user_id
            
            await email_accounts.update_one({"_id": existing["_id"]}, {"$set": update_data})
        else:
            # Insert new account
            account_data["created_at"] = now.isoformat()
            await email_accounts.insert_one(account_data)
        # -------------------- CREATE APP ACCESS TOKEN -------------------- #
        # Use the application user ID for the JWT token if available, otherwise use Google user ID
        token_user_id = app_user_id if app_user_id else google_user_id
        
        payload = {
            "sub": str(token_user_id),
            "email": user_email,
            "role": "user"
        }
        jwt_token = create_access_token(payload)

        # -------------------- FETCH SAMPLE EMAILS (optional) -------------------- #
        emails = []
        try:
            async with aiohttp.ClientSession() as session:
                headers = {"Authorization": f"Bearer {access_token}"}
                async with session.get(
                    "https://gmail.googleapis.com/gmail/v1/users/me/messages",
                    headers=headers,
                    params={"maxResults": 5}
                ) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        for msg in data.get("messages", []):
                            msg_id = msg["id"]
                            async with session.get(
                                f"https://gmail.googleapis.com/gmail/v1/users/me/messages/{msg_id}",
                                headers=headers,
                                params={"format": "metadata", "metadataHeaders": ["From", "Subject", "Date"]}
                            ) as msg_resp:
                                if msg_resp.status == 200:
                                    msg_data = await msg_resp.json()
                                    headers_list = msg_data["payload"]["headers"]
                                    emails.append({
                                        "from": next((h["value"] for h in headers_list if h["name"] == "From"), ""),
                                        "subject": next((h["value"] for h in headers_list if h["name"] == "Subject"), ""),
                                        "date": next((h["value"] for h in headers_list if h["name"] == "Date"), ""),
                                        "snippet": msg_data.get("snippet", "")
                                    })
        except Exception as e:
            logger.warning(f"Could not fetch Gmail messages: {e}")

        # -------------------- REDIRECT TO FRONTEND -------------------- #
        import urllib.parse
        encoded_user = urllib.parse.quote(json.dumps({
            "id": str(token_user_id),
            "email": user_email,
            "name": user_name
        }))
        encoded_emails = urllib.parse.quote(json.dumps(emails))

        frontend_url = os.getenv("FRONTEND_URL", "http://localhost:4000")
        redirect_url = f"{frontend_url}/login?success=true&token={jwt_token}&user={encoded_user}&emails={encoded_emails}"

        return RedirectResponse(url=redirect_url)

    except Exception as e:
        logger.error(f"Google OAuth callback failed: {e}")
        logger.error(traceback.format_exc())
        return JSONResponse(
            status_code=500,
            content={"success": False, "error": "google_callback_failed", "details": str(e)},
        )