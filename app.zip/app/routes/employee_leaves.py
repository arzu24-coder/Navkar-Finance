"""
Employee Leave Management API
Handles leave requests, approvals, rejections, and related operations
"""
from fastapi import APIRouter, HTTPException, Query, Body, Depends
from typing import Dict, Optional, List
from bson import ObjectId
from datetime import datetime, timedelta
import logging

from app.database import get_database
from app.dependencies import get_current_user
from app.routes.employees import (
    extract_user_roles, 
    has_admin_or_hr_permission, 
    make_serializable
)
from app.models.auth import UserInfo

# Configure logger
logger = logging.getLogger(__name__)

# Initialize router
employee_leaves_router = APIRouter(prefix="/api/employee-leaves", tags=["employee-leaves"])

@employee_leaves_router.post("/", status_code=201)
async def create_employee_leave_request(
    payload: Dict = Body(...),
    current_user: UserInfo = Depends(get_current_user)
):
    """Create a new employee leave request"""
    try:
        db = get_database()
        user_roles = extract_user_roles(current_user.dict())
        
        user_id = payload.get("user_id")
        leave_type = payload.get("leave_type")
        start_date = payload.get("start_date")
        end_date = payload.get("end_date")
        reason = payload.get("reason", "")
        is_half_day = payload.get("is_half_day", False)
        
        if not all([user_id, leave_type, start_date, end_date]):
            raise HTTPException(status_code=400, detail="Missing required fields")
        
        # Authorization check: users can only create requests for themselves unless they're admin/HR
        current_user_id = current_user.id or getattr(current_user, "user_id", None) or current_user.username
        is_admin_or_hr = has_admin_or_hr_permission(user_roles)
        
        if not is_admin_or_hr and user_id != current_user_id:
            raise HTTPException(status_code=403, detail="You can only create leave requests for yourself")
        
        # Verify user exists
        user = db.users.find_one({"user_id": user_id})
        if not user:
            raise HTTPException(status_code=404, detail="Employee not found")
        
        # Calculate number of days with error handling
        try:
            start = datetime.strptime(start_date, "%Y-%m-%d") if isinstance(start_date, str) else datetime.now()
            end = datetime.strptime(end_date, "%Y-%m-%d") if isinstance(end_date, str) else datetime.now()
            days_requested = (end - start).days + 1
        except (ValueError, TypeError):
            # Fallback calculation
            days_requested = 1
        
        if is_half_day:
            days_requested = 0.5
        
        leave_request = {
            "user_id": user_id,
            "employee_name": user.get("full_name", user.get("username")),
            "leave_type": leave_type,
            "start_date": start_date,
            "end_date": end_date,
            "days_requested": days_requested,
            "reason": reason,
            "is_half_day": is_half_day,
            "status": "pending",
            "requested_at": datetime.now(),
            "approved_by": None,
            "approved_at": None,
            "rejection_reason": None
        }
        
        result = db.leave_requests.insert_one(leave_request)
        leave_request["_id"] = result.inserted_id
        
        return make_serializable({
            "success": True,
            "message": "Leave request created successfully",
            "data": leave_request
        })
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error creating employee leave request: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to create leave request: {str(e)}")

@employee_leaves_router.get("/", status_code=200)
async def get_employee_leave_requests(
    current_user: UserInfo = Depends(get_current_user),
    page: int = Query(1, description="Page number"),
    limit: int = Query(50, description="Items per page"),
    employee_id: Optional[str] = Query(None, description="Filter by employee ID (Admin/HR only)"),
    status: Optional[str] = Query(None, description="Filter by status"),
    start_date: Optional[str] = Query(None, description="Filter from date"),
    end_date: Optional[str] = Query(None, description="Filter to date")
):
    """Get employee leave requests - own requests or all if Admin/HR"""
    try:
        db = get_database()
        user_roles = extract_user_roles(current_user.dict())
        
        current_user_id = current_user.id or getattr(current_user, "user_id", None) or current_user.username
        
        # Check if user has permissions to view all leave requests (admin or HR)
        can_view_all = has_admin_or_hr_permission(user_roles)
        
        query = {}
        
        if can_view_all and employee_id:
            # Admin/HR can view specific employee's requests
            query["user_id"] = employee_id
        elif can_view_all:
            # Admin/HR can view all requests (no user filter)
            pass
        else:
            # Regular users can only see their own requests
            query["user_id"] = current_user_id
        
        # Apply other filters
        if status:
            query["status"] = status
        
        if start_date:
            query["start_date"] = {"$gte": start_date}
        
        if end_date:
            if "start_date" in query:
                query["start_date"]["$lte"] = end_date
            else:
                query["start_date"] = {"$lte": end_date}
        
        # Pagination
        skip = (page - 1) * limit
        
        requests = list(db.leave_requests.find(query).sort("requested_at", -1).skip(skip).limit(limit))
        total = db.leave_requests.count_documents(query)
        
        return make_serializable({
            "success": True,
            "data": requests,
            "page": page,
            "limit": limit,
            "total": total,
            "pages": (total + limit - 1) // limit,
            "can_manage_all": can_view_all
        })
        
    except Exception as e:
        logger.error(f"Error getting employee leave requests: {str(e)}")
        return {"success": False, "error": str(e), "message": "Failed to get leave requests"}

@employee_leaves_router.put("/{request_id}/approve", status_code=200)
async def approve_employee_leave_request(
    request_id: str,
    payload: Dict = Body(default={}),
    current_user: UserInfo = Depends(get_current_user)
):
    """Approve an employee leave request (Admin or HR roles only)"""
    try:
        # Extract user roles and ID from current_user with multiple possible formats
        user_dict = current_user.dict()
        raw_roles = (
            user_dict.get("roles", []) or 
            user_dict.get("role_names", []) or 
            user_dict.get("user_roles", []) or
            user_dict.get("role", []) or
            []
        )
        
        # Handle both string and list formats for roles
        if isinstance(raw_roles, str):
            current_user_roles = [raw_roles]
        elif isinstance(raw_roles, list):
            # Flatten any nested role objects and extract role names
            current_user_roles = []
            for role in raw_roles:
                if isinstance(role, str):
                    current_user_roles.append(role)
                elif isinstance(role, dict):
                    current_user_roles.append(role.get("name", str(role)))
                else:
                    current_user_roles.append(str(role))
        else:
            current_user_roles = []
        
        current_user_id = user_dict.get("user_id") or user_dict.get("id")

        # Check if user has permission to manage leave requests (admin or HR)
        if not has_admin_or_hr_permission(current_user_roles):
            raise HTTPException(
                status_code=403, 
                detail=f"Insufficient permissions. Only Admin or HR roles can approve leave requests. Your roles: {current_user_roles}"
            )
        
        db = get_database()
        
        # Find the leave request
        leave_request = db.leave_requests.find_one({"_id": ObjectId(request_id)})
        if not leave_request:
            raise HTTPException(status_code=404, detail="Leave request not found")
        
        if leave_request["status"] != "pending":
            raise HTTPException(status_code=400, detail="Leave request is not pending")
        
        # Update the request
        update_data = {
            "status": "approved",
            "approved_by": current_user_id,
            "approved_at": datetime.now(),
            "approval_notes": payload.get("notes", "")
        }
        
        db.leave_requests.update_one(
            {"_id": ObjectId(request_id)},
            {"$set": update_data}
        )
        

        return {
            "success": True,
            "message": "Leave request approved successfully"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error approving employee leave request: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to approve leave request: {str(e)}")

@employee_leaves_router.put("/{request_id}/reject", status_code=200)
async def reject_employee_leave_request(
    request_id: str,
    payload: Dict = Body(...),
    current_user: UserInfo = Depends(get_current_user)
):
    """Reject an employee leave request (Admin or HR roles only)"""
    try:
        # Extract user roles and ID from current_user with multiple possible formats
        user_dict = current_user.dict()
        raw_roles = (
            user_dict.get("roles", []) or 
            user_dict.get("role_names", []) or 
            user_dict.get("user_roles", []) or
            user_dict.get("role", []) or
            []
        )
        
        # Handle both string and list formats for roles
        if isinstance(raw_roles, str):
            current_user_roles = [raw_roles]
        elif isinstance(raw_roles, list):
            # Flatten any nested role objects and extract role names
            current_user_roles = []
            for role in raw_roles:
                if isinstance(role, str):
                    current_user_roles.append(role)
                elif isinstance(role, dict):
                    current_user_roles.append(role.get("name", str(role)))
                else:
                    current_user_roles.append(str(role))
        else:
            current_user_roles = []
        
        current_user_id = user_dict.get("user_id") or user_dict.get("id")
        
        # Check if user has permission to manage leave requests (admin or HR)
        if not has_admin_or_hr_permission(current_user_roles):
            raise HTTPException(
                status_code=403, 
                detail=f"Insufficient permissions. Only Admin or HR roles can reject leave requests. Your roles: {current_user_roles}"
            )
        
        db = get_database()
        
        reason = payload.get("reason", "")
        if not reason:
            raise HTTPException(status_code=400, detail="Rejection reason is required")
        
        # Find the leave request
        leave_request = db.leave_requests.find_one({"_id": ObjectId(request_id)})
        if not leave_request:
            raise HTTPException(status_code=404, detail="Leave request not found")
        
        if leave_request["status"] != "pending":
            raise HTTPException(status_code=400, detail="Leave request is not pending")
        
        # Update the request
        update_data = {
            "status": "rejected",
            "approved_by": current_user_id,
            "approved_at": datetime.now(),
            "rejection_reason": reason
        }
        
        db.leave_requests.update_one(
            {"_id": ObjectId(request_id)},
            {"$set": update_data}
        )
        
        return {
            "success": True,
            "message": "Leave request rejected successfully"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error rejecting employee leave request: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to reject leave request: {str(e)}")

@employee_leaves_router.get("/{employee_id}", status_code=200)
async def get_employee_leave_requests_by_id(
    employee_id: str,
    page: int = Query(1, description="Page number"),
    limit: int = Query(20, description="Items per page"),
    status: Optional[str] = Query(None, description="Filter by status"),
    current_user: UserInfo = Depends(get_current_user)
):
    """Get leave requests for specific employee"""
    try:
        db = get_database()
        
        # Debug logging
        logger.info(f"Fetching leave requests for employee_id: {employee_id}")
        
        # Verify user exists
        user = db.users.find_one({"user_id": employee_id})
        if not user:
            raise HTTPException(status_code=404, detail="Employee not found")
                
        query = {"user_id": employee_id}
        
        if status:
            query["status"] = status
        
       
        # Pagination
        skip = (page - 1) * limit
        
        requests = list(db.leave_requests.find(query).sort("requested_at", -1).skip(skip).limit(limit))
        total = db.leave_requests.count_documents(query)
                
        result = make_serializable({
            "success": True,
            "requests": requests,
            "page": page,
            "limit": limit,
            "total": total,
            "pages": (total + limit - 1) // limit
        })
        
        return result
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting employee leave requests by ID: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to get leave requests: {str(e)}")

