from fastapi import APIRouter, HTTPException, Query, Body, Depends, status
from fastapi.responses import JSONResponse
from typing import List, Dict, Optional, Any
from bson import ObjectId
from datetime import datetime, timedelta
import logging
from app.database import get_database
from app.dependencies import get_current_user
from app.database.schemas.announcement_schema import (
    AnnouncementCreate,
    AnnouncementUpdate,
    AnnouncementResponse,
    AnnouncementAcknowledgmentCreate,
    AnnouncementAcknowledgment,
    AnnouncementStats,
    AnnouncementTrackingResponse,
    AnnouncementStatus,
    AnnouncementType,
    AnnouncementPriority
)

# Configure logger
logger = logging.getLogger(__name__)

# Initialize router
announcements_router = APIRouter(prefix="/api/announcements", tags=["announcements"])

def serialize_announcement(announcement: dict) -> dict:
    """Convert announcement from MongoDB format to API response format"""
    # Only remove _id if there's no custom id field, to preserve announcement IDs like ann-001
    if "_id" in announcement:
        if "id" not in announcement:
            announcement["id"] = str(announcement["_id"])
        del announcement["_id"]
    
    # Handle datetime fields
    for field in ["created_at", "updated_at", "expiry_date"]:
        if field in announcement and announcement[field]:
            if isinstance(announcement[field], str):
                try:
                    announcement[field] = datetime.fromisoformat(announcement[field].replace('Z', '+00:00'))
                except:
                    pass
    
    return announcement

def generate_announcement_id(db):
    """Generate unique announcement ID"""
    collection = db["announcements"]
    last_announcement = collection.find_one(
        {"id": {"$regex": "^ann-\\d+$"}},
        sort=[("created_at", -1)]
    )
    
    if last_announcement and "id" in last_announcement:
        try:
            last_num = int(last_announcement["id"].split("-")[1])
            new_num = last_num + 1
        except:
            new_num = 1
    else:
        new_num = 1
    
    return f"ann-{new_num:03d}"

# =================== ANNOUNCEMENT CRUD OPERATIONS ===================

@announcements_router.post("/", status_code=201)
async def create_announcement(
    announcement_data: AnnouncementCreate,
    current_user: dict = Depends(get_current_user)
):
    """Create a new announcement"""
    try:
        db = get_database()
        collection = db["announcements"]
        
        # Generate unique ID
        announcement_id = generate_announcement_id(db)
        
        # Prepare announcement document
        announcement_doc = {
            "id": announcement_id,
            "title": announcement_data.title,
            "content": announcement_data.content,
            "type": announcement_data.type,
            "priority": announcement_data.priority,
            "status": AnnouncementStatus.ACTIVE,
            "target_audience": announcement_data.target_audience,
            "expiry_date": announcement_data.expiry_date,
            "is_mandatory": announcement_data.is_mandatory,
            "custom_audience": announcement_data.custom_audience or [],
            "tags": announcement_data.tags or [],
            "created_by": current_user.get("user_id", "unknown"),
            "created_by_name": current_user.get("username", "Unknown User"),
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow(),
            "view_count": 0,
            "acknowledged_count": 0,
            "pending_count": 0
        }
        
        # Insert announcement
        result = collection.insert_one(announcement_doc)
        
        if result.inserted_id:
            # Fetch created announcement
            created_announcement = collection.find_one({"_id": result.inserted_id})
            return serialize_announcement(created_announcement)
        else:
            raise HTTPException(status_code=500, detail="Failed to create announcement")
            
    except Exception as e:
        logger.error(f"Error creating announcement: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to create announcement: {str(e)}")

@announcements_router.get("/", status_code=200)
async def get_announcements(
    skip: int = Query(0, description="Number of announcements to skip"),
    limit: int = Query(50, description="Number of announcements to return"),
    status: Optional[AnnouncementStatus] = Query(None, description="Filter by status"),
    type: Optional[AnnouncementType] = Query(None, description="Filter by type"),
    priority: Optional[AnnouncementPriority] = Query(None, description="Filter by priority"),
    current_user: dict = Depends(get_current_user)
):
    """Get all announcements with filtering and pagination"""
    try:
        db = get_database()
        collection = db["announcements"]
        
        # Build query
        query = {}
        if status:
            query["status"] = status
        if type:
            query["type"] = type
        if priority:
            query["priority"] = priority
        
        # Auto-expire announcements
        current_time = datetime.utcnow()
        collection.update_many(
            {
                "expiry_date": {"$lt": current_time},
                "status": {"$in": [AnnouncementStatus.ACTIVE, AnnouncementStatus.DRAFT]}
            },
            {"$set": {"status": AnnouncementStatus.EXPIRED}}
        )
        
        # Fetch announcements
        cursor = collection.find(query).sort("created_at", -1).skip(skip).limit(limit)
        announcements = []
        
        # Get acknowledgments for current user
        acknowledgments_collection = db["announcement_acknowledgments"]
        views_collection = db["announcement_views"]
        user_acknowledgments = {}
        user_views = {}
        
        if current_user:
            # Get user acknowledgments
            user_acks = acknowledgments_collection.find({"employee_id": current_user.get("user_id")})
            user_acknowledgments = {ack["announcement_id"]: ack for ack in user_acks}
            
            # Get user views
            user_view_records = views_collection.find({"employee_id": current_user.get("user_id")})
            user_views = {view["announcement_id"]: view for view in user_view_records}
        
        for doc in cursor:
            announcement = serialize_announcement(doc)
            
            # Add user-specific acknowledgment status
            if current_user and announcement["id"] in user_acknowledgments:
                ack = user_acknowledgments[announcement["id"]]
                announcement["acknowledged"] = True
                announcement["acknowledged_at"] = ack.get("acknowledged_at")
                announcement["acknowledgment_comments"] = ack.get("comments")
            else:
                announcement["acknowledged"] = False
                announcement["acknowledged_at"] = None
                
            # Add user-specific view status
            if current_user and announcement["id"] in user_views:
                view = user_views[announcement["id"]]
                announcement["viewed_by_user"] = True
                announcement["viewed_at"] = view.get("viewed_at")
            else:
                announcement["viewed_by_user"] = False
                announcement["viewed_at"] = None
                
            announcements.append(announcement)
        
        # Get total count
        total_count = collection.count_documents(query)
        
        return {
            "data": announcements,
            "total": total_count,
            "skip": skip,
            "limit": limit
        }
        
    except Exception as e:
        logger.error(f"Error fetching announcements: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to fetch announcements: {str(e)}")

@announcements_router.get("/stats", status_code=200)
async def get_announcement_stats(current_user: dict = Depends(get_current_user)):
    """Get announcement statistics"""
    try:
        db = get_database()
        collection = db["announcements"]
        
        # Auto-expire announcements
        current_time = datetime.utcnow()
        collection.update_many(
            {
                "expiry_date": {"$lt": current_time},
                "status": {"$in": [AnnouncementStatus.ACTIVE, AnnouncementStatus.DRAFT]}
            },
            {"$set": {"status": AnnouncementStatus.EXPIRED}}
        )
        
        # Calculate stats
        total_announcements = collection.count_documents({})
        active_announcements = collection.count_documents({"status": AnnouncementStatus.ACTIVE})
        draft_announcements = collection.count_documents({"status": AnnouncementStatus.DRAFT})
        expired_announcements = collection.count_documents({"status": AnnouncementStatus.EXPIRED})
        
        # Calculate mandatory pending
        mandatory_announcements = list(collection.find({
            "is_mandatory": True,
            "status": AnnouncementStatus.ACTIVE
        }, {"pending_count": 1}))
        
        mandatory_pending = sum(ann.get("pending_count", 0) for ann in mandatory_announcements)
        
        # Calculate total views and acknowledgment rate
        all_announcements = list(collection.find({}, {"view_count": 1, "acknowledged_count": 1}))
        total_views = sum(ann.get("view_count", 0) for ann in all_announcements)
        total_acknowledged = sum(ann.get("acknowledged_count", 0) for ann in all_announcements)
        
        acknowledgment_rate = (total_acknowledged / max(total_views, 1)) * 100
        
        stats = {
            "total_announcements": total_announcements,
            "active_announcements": active_announcements,
            "draft_announcements": draft_announcements,
            "expired_announcements": expired_announcements,
            "mandatory_pending": mandatory_pending,
            "total_views": total_views,
            "overall_acknowledgment_rate": round(acknowledgment_rate, 2)
        }
        
        return stats
        
    except Exception as e:
        logger.error(f"Error fetching announcement stats: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to fetch stats: {str(e)}")

@announcements_router.get("/{announcement_id}", status_code=200)
async def get_announcement(
    announcement_id: str,
    current_user: dict = Depends(get_current_user)
):
    """Get a specific announcement by ID"""
    try:
        db = get_database()
        collection = db["announcements"]
        
        # Find announcement
        announcement = collection.find_one({"id": announcement_id})
        
        if not announcement:
            raise HTTPException(status_code=404, detail="Announcement not found")
        
        # Increment view count
        collection.update_one(
            {"id": announcement_id},
            {"$inc": {"view_count": 1}}
        )
        announcement["view_count"] += 1
        
        return serialize_announcement(announcement)
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching announcement {announcement_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to fetch announcement: {str(e)}")

@announcements_router.put("/{announcement_id}", status_code=200)
async def update_announcement(
    announcement_id: str,
    update_data: AnnouncementUpdate,
    current_user: dict = Depends(get_current_user)
):
    """Update an announcement"""
    try:
        db = get_database()
        collection = db["announcements"]
        
        # Find announcement
        announcement = collection.find_one({"id": announcement_id})
        if not announcement:
            raise HTTPException(status_code=404, detail="Announcement not found")
        
        # Prepare update document
        update_doc = {"updated_at": datetime.utcnow()}
        
        # Update fields if provided
        if update_data.title is not None:
            update_doc["title"] = update_data.title
        if update_data.content is not None:
            update_doc["content"] = update_data.content
        if update_data.type is not None:
            update_doc["type"] = update_data.type
        if update_data.priority is not None:
            update_doc["priority"] = update_data.priority
        if update_data.target_audience is not None:
            update_doc["target_audience"] = update_data.target_audience
        if update_data.expiry_date is not None:
            update_doc["expiry_date"] = update_data.expiry_date
        if update_data.is_mandatory is not None:
            update_doc["is_mandatory"] = update_data.is_mandatory
        if update_data.status is not None:
            update_doc["status"] = update_data.status
        if update_data.custom_audience is not None:
            update_doc["custom_audience"] = update_data.custom_audience
        if update_data.tags is not None:
            update_doc["tags"] = update_data.tags
        
        # Update announcement
        result = collection.update_one(
            {"id": announcement_id},
            {"$set": update_doc}
        )
        
        if result.modified_count > 0:
            # Fetch updated announcement
            updated_announcement = collection.find_one({"id": announcement_id})
            return serialize_announcement(updated_announcement)
        else:
            raise HTTPException(status_code=500, detail="Failed to update announcement")
            
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating announcement {announcement_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to update announcement: {str(e)}")

@announcements_router.delete("/{announcement_id}", status_code=200)
async def delete_announcement(
    announcement_id: str,
    current_user: dict = Depends(get_current_user)
):
    """Delete an announcement"""
    try:
        db = get_database()
        collection = db["announcements"]
        
        # Find announcement
        announcement = collection.find_one({"id": announcement_id})
        if not announcement:
            raise HTTPException(status_code=404, detail="Announcement not found")
        
        # Delete announcement
        result = collection.delete_one({"id": announcement_id})
        
        if result.deleted_count > 0:
            # Also delete related acknowledgments
            db["announcement_acknowledgments"].delete_many({"announcement_id": announcement_id})
            return {"message": "Announcement deleted successfully"}
        else:
            raise HTTPException(status_code=500, detail="Failed to delete announcement")
            
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting announcement {announcement_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to delete announcement: {str(e)}")

# =================== ACKNOWLEDGMENT OPERATIONS ===================

@announcements_router.post("/acknowledge", status_code=201)
async def acknowledge_announcement(
    acknowledgment_data: AnnouncementAcknowledgmentCreate,
    current_user: dict = Depends(get_current_user)
):
    """Acknowledge an announcement"""
    try:
        db = get_database()
        announcements_collection = db["announcements"]
        acknowledgments_collection = db["announcement_acknowledgments"]
        
        # Verify announcement exists
        announcement = announcements_collection.find_one({"id": acknowledgment_data.announcement_id})
        if not announcement:
            raise HTTPException(status_code=404, detail="Announcement not found")
        
        # Check if already acknowledged
        existing_ack = acknowledgments_collection.find_one({
            "announcement_id": acknowledgment_data.announcement_id,
            "employee_id": current_user.get("user_id")
        })
        
        if existing_ack:
            raise HTTPException(status_code=400, detail="Announcement already acknowledged")
        
        # Create acknowledgment
        acknowledgment_doc = {
            "announcement_id": acknowledgment_data.announcement_id,
            "employee_id": current_user.get("user_id"),
            "employee_name": current_user.get("username", "Unknown User"),
            "acknowledged_at": datetime.utcnow(),
            "comments": acknowledgment_data.comments
        }
        
        result = acknowledgments_collection.insert_one(acknowledgment_doc)
        
        if result.inserted_id:
            # Update announcement acknowledgment count and view count
            announcements_collection.update_one(
                {"id": acknowledgment_data.announcement_id},
                {
                    "$inc": {
                        "acknowledged_count": 1, 
                        "pending_count": -1,
                        "view_count": 1  # Increment view count when acknowledged
                    }
                }
            )
            
            return {"message": "Announcement acknowledged successfully"}
        else:
            raise HTTPException(status_code=500, detail="Failed to acknowledge announcement")
            
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error acknowledging announcement: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to acknowledge announcement: {str(e)}")

@announcements_router.post("/{announcement_id}/view", status_code=200)
async def mark_announcement_as_viewed(
    announcement_id: str,
    current_user: dict = Depends(get_current_user)
):
    """Mark an announcement as viewed by the current user"""
    try:
        db = get_database()
        announcements_collection = db["announcements"]
        views_collection = db["announcement_views"]
        
        # Verify announcement exists
        announcement = announcements_collection.find_one({"id": announcement_id})
        if not announcement:
            raise HTTPException(status_code=404, detail="Announcement not found")
        
        # Check if already viewed by this user
        existing_view = views_collection.find_one({
            "announcement_id": announcement_id,
            "employee_id": current_user.get("user_id")
        })
        
        if not existing_view:
            # Create view record
            view_doc = {
                "announcement_id": announcement_id,
                "employee_id": current_user.get("user_id"),
                "employee_name": current_user.get("username", "Unknown User"),
                "viewed_at": datetime.utcnow()
            }
            
            views_collection.insert_one(view_doc)
            
            # Increment view count
            announcements_collection.update_one(
                {"id": announcement_id},
                {"$inc": {"view_count": 1}}
            )
            
        return {"message": "Announcement marked as viewed"}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error marking announcement as viewed: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to mark announcement as viewed: {str(e)}")

@announcements_router.get("/{announcement_id}/tracking", status_code=200)
async def get_announcement_tracking(
    announcement_id: str,
    current_user: dict = Depends(get_current_user)
):
    """Get tracking information for an announcement"""
    try:
        db = get_database()
        announcements_collection = db["announcements"]
        acknowledgments_collection = db["announcement_acknowledgments"]
        employees_collection = db["employees"]
        
        # Get announcement
        announcement = announcements_collection.find_one({"id": announcement_id})
        if not announcement:
            raise HTTPException(status_code=404, detail="Announcement not found")
        
        # Get acknowledgments
        acknowledgments = list(acknowledgments_collection.find({"announcement_id": announcement_id}))
        
        # Get all employees for pending calculation
        all_employees = list(employees_collection.find({}, {"id": 1, "name": 1, "full_name": 1, "department": 1, "team": 1}))
        
        # Get acknowledged employee IDs
        acknowledged_ids = [ack["employee_id"] for ack in acknowledgments]
        
        # Find pending employees
        pending_employees = []
        for emp in all_employees:
            emp_id = emp.get("id") or str(emp.get("_id"))
            if emp_id not in acknowledged_ids:
                pending_employees.append({
                    "id": emp_id,
                    "name": emp.get("name") or emp.get("full_name") or "Unknown",
                    "department": emp.get("department") or emp.get("team") or "General"
                })
        
        return {
            "announcement": serialize_announcement(announcement),
            "acknowledgments": acknowledgments,
            "pending_employees": pending_employees
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching tracking for announcement {announcement_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to fetch tracking: {str(e)}")