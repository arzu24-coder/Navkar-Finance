import os
import logging
import json
import requests
import aiohttp
from fastapi import HTTPException
from app.database.repositories.email_account_repository import EmailAccountRepository  # your DB repo
logger = logging.getLogger(__name__)

GMAIL_CLIENT_ID = "731827166415-2hn36eq8pfvo6t3akpanckkln4tan4fv.apps.googleusercontent.com"
GMAIL_CLIENT_SECRET ="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"

async def refresh_google_token_for_user(email: str) -> str:
    try:
        logger.info(f"Starting token refresh for user: {email}")
        repo = EmailAccountRepository()
        account = await repo.get_by_email(email)
        
        logger.info(f"Account lookup result for {email}: {account}")
        
        if account is None:
            logger.error(f"No account found for email: {email}")
            raise HTTPException(status_code=400, detail="No Gmail account linked. Please authenticate.")
            
        # Ensure account is a dictionary and not a coroutine
        if not isinstance(account, dict):
            logger.error(f"Account is not a dictionary: {type(account)}")
            raise HTTPException(status_code=500, detail="Internal error: Account data format invalid.")
            
        if "refresh_token" not in account or not account["refresh_token"]:
            logger.error(f"No refresh token found for email: {email}")
            raise HTTPException(status_code=400, detail="No refresh token found. Please re-authenticate Gmail account.")

        refresh_token = account["refresh_token"]
        logger.info(f"Refreshing Google token for {email}...")

        url = "https://oauth2.googleapis.com/token"
        data = {
            "client_id": GMAIL_CLIENT_ID,
            "client_secret": GMAIL_CLIENT_SECRET,
            "refresh_token": refresh_token,
            "grant_type": "refresh_token"
        }

        async with aiohttp.ClientSession() as session:
            async with session.post(url, data=data) as resp:
                text = await resp.text()
                logger.info(f"Token refresh response status: {resp.status}, body: {text[:200]}...")
                try:
                    token_data = json.loads(text)
                    logger.info(f"Token data: {token_data}")
                except json.JSONDecodeError:
                    logger.error(f"Failed to parse token response for {email}: {text}")
                    token_data = {"error": "Invalid response", "response": text}

                if resp.status != 200 or "access_token" not in token_data:
                    err_msg = token_data.get("error_description") or token_data.get("error") or "Unknown error"
                    logger.error(f"Failed to refresh Gmail token for {email}: {err_msg}")
                    raise HTTPException(status_code=400,
                                        detail=f"Failed to refresh Gmail token: {err_msg}. Please re-authenticate Gmail.")

                access_token = token_data["access_token"]
                expires_in = token_data.get("expires_in", 3600)
                if isinstance(expires_in, str):
                    expires_in = int(expires_in)
                elif not isinstance(expires_in, int):
                    expires_in = 3600

                # Async DB update
                update_result = await repo.update_access_token(email, access_token, expires_in)
                logger.info(f"Token updated in database for {email}, result: {update_result}")

                logger.info(f"[SUCCESS] Google token refreshed for {email}")
                return access_token
    except Exception as e:
        logger.exception(f"Unexpected error in refresh_google_token_for_user for {email}: {str(e)}")
        raise

# New function to refresh token by user_id
async def refresh_google_token_for_user_id(user_id: str) -> tuple[str, str]:
    try:
        logger.info(f"Starting token refresh for user_id: {user_id}")
        repo = EmailAccountRepository()
        account = await repo.get_by_user_id(user_id)
        
        logger.info(f"Account lookup result for user_id {user_id}: {account}")
        
        if account is None:
            logger.error(f"No account found for user_id: {user_id}")
            # Let's also check if there's an account with this email but different user_id
            logger.info(f"Checking if there's an account with user_id as email: {user_id}")
            account = await repo.get_by_email(user_id)
            if account:
                logger.info(f"Found account by email: {account}")
            else:
                raise HTTPException(status_code=400, detail="No Gmail account linked. Please authenticate.")
            
        # Ensure account is a dictionary and not a coroutine
        if not isinstance(account, dict):
            logger.error(f"Account is not a dictionary: {type(account)}")
            raise HTTPException(status_code=500, detail="Internal error: Account data format invalid.")
            
        if "refresh_token" not in account or not account["refresh_token"]:
            logger.error(f"No refresh token found for user_id: {user_id}")
            logger.error(f"Account data: {account}")
            raise HTTPException(status_code=400, detail="No refresh token found. Please re-authenticate Gmail account.")

        refresh_token = account["refresh_token"]
        email = account["email"]
        logger.info(f"Refreshing Google token for user_id {user_id}, email {email}...")

        url = "https://oauth2.googleapis.com/token"
        data = {
            "client_id": GMAIL_CLIENT_ID,
            "client_secret": GMAIL_CLIENT_SECRET,
            "refresh_token": refresh_token,
            "grant_type": "refresh_token"
        }

        async with aiohttp.ClientSession() as session:
            async with session.post(url, data=data) as resp:
                text = await resp.text()
                logger.info(f"Token refresh response status: {resp.status}, body: {text[:200]}...")
                try:
                    token_data = json.loads(text)
                    logger.info(f"Token data: {token_data}")
                except json.JSONDecodeError:
                    logger.error(f"Failed to parse token response for user_id {user_id}: {text}")
                    token_data = {"error": "Invalid response", "response": text}

                if resp.status != 200 or "access_token" not in token_data:
                    err_msg = token_data.get("error_description") or token_data.get("error") or "Unknown error"
                    logger.error(f"Failed to refresh Gmail token for user_id {user_id}: {err_msg}")
                    raise HTTPException(status_code=400,
                                        detail=f"Failed to refresh Gmail token: {err_msg}. Please re-authenticate Gmail.")

                access_token = token_data["access_token"]
                expires_in = token_data.get("expires_in", 3600)
                if isinstance(expires_in, str):
                    expires_in = int(expires_in)
                elif not isinstance(expires_in, int):
                    expires_in = 3600

                # Async DB update
                update_result = await repo.update_access_token(email, access_token, expires_in)
                logger.info(f"Token updated in database for {email}, result: {update_result}")

                logger.info(f"[SUCCESS] Google token refreshed for user_id {user_id}")
                return access_token, email
    except Exception as e:
        logger.exception(f"Unexpected error in refresh_google_token_for_user_id for {user_id}: {str(e)}")
        raise

import aiohttp
from typing import List, Dict, Any
from fastapi import HTTPException # Import HTTPException for proper error handling

# Assumed: This function lives in a service file and handles Gmail API calls.
async def fetch_gmail_messages(access_token: str, max_results: int = 10) -> List[Dict[str, Any]]:
    try:
        logger.info(f"Fetching Gmail messages, max_results: {max_results}")
        messages_result = []
        headers = {"Authorization": f"Bearer {access_token}"}
        
        # FIX 1: Removed labelIds=INBOX filter to get a standard inbox view
        list_url = f"https://gmail.googleapis.com/gmail/v1/users/me/messages?maxResults={max_results}"

        async with aiohttp.ClientSession() as session:
            # 1. Fetch the list of message IDs
            logger.info(f"Calling Gmail API to fetch message list")
            async with session.get(list_url, headers=headers) as resp:
                logger.info(f"Gmail API message list response status: {resp.status}")
                if resp.status != 200:
                    text = await resp.text()
                    # Use HTTPException for FastAPI context
                    logger.error(f"Error fetching message list: {text}")
                    raise HTTPException(status_code=resp.status, detail=f"Gmail API error fetching list: {text}")
                
                data = await resp.json()
                messages = data.get("messages", [])

            # 2. Fetch each message details asynchronously
            for msg in messages:
                msg_id = msg["id"]
                # Validate the message ID to prevent reserved keywords from being used
                reserved_keywords = ['spam', 'drafts', 'trash', 'inbox', 'sent', 'starred']
                if msg_id.lower() in reserved_keywords:
                    logger.warning(f"Skipping message with reserved keyword ID: {msg_id}")
                    continue
                    
                detail_url = f"https://gmail.googleapis.com/gmail/v1/users/me/messages/{msg_id}"
                
                logger.info(f"Fetching details for message {msg_id}")
                async with session.get(detail_url, headers=headers) as msg_resp:
                    logger.info(f"Gmail API message detail response status: {msg_resp.status}")
                    if msg_resp.status != 200:
                        error_text = await msg_resp.text()
                        logger.error(f"Error fetching message ID {msg_id}: {error_text}")
                        continue
                        
                    msg_data = await msg_resp.json()
                    
                    # --------------------------------------------
                    # FIX 2 (The crucial fix): CHECKING THE STARRED LABEL
                    # --------------------------------------------
                    label_ids = msg_data.get("labelIds", [])
                    is_starred = "STARRED" in label_ids
                    # Check if the email is unread
                    is_unread = "UNREAD" in label_ids

                    # Extract Headers
                    payload = msg_data.get("payload", {})
                    headers_list = payload.get("headers", [])

                    subject = next((h["value"] for h in headers_list if h["name"] == "Subject"), "No Subject")
                    sender = next((h["value"] for h in headers_list if h["name"] == "From"), "Unknown Sender")
                    date = next((h["value"] for h in headers_list if h["name"] == "Date"), "Unknown Date")

                    # 3. Include the isStarred flag and the message ID
                    messages_result.append({
                        "id": msg_id,
                        "threadId": msg_data.get("threadId"),
                        "subject": subject,
                        "from": sender,
                        "date": date,
                        "isStarred": is_starred, # <--- THIS IS THE FLAG YOU NEED
                        "isUnread": is_unread,  # <--- ADD THIS FLAG FOR READ/UNREAD STATUS
                        "snippet": msg_data.get("snippet", "No snippet available"),
                        "labelIds": label_ids,
                    })
                        
        logger.info(f"Successfully fetched {len(messages_result)} messages")
        return messages_result
    except Exception as e:
        logger.exception(f"Unexpected error in fetch_gmail_messages: {str(e)}")
        raise


import aiohttp
import base64
from email.mime.text import MIMEText
from fastapi import HTTPException

async def send_gmail_message(access_token: str, to_email: str, subject: str, message_text: str):
    try:
        logger.info(f"Sending email to {to_email} with subject: {subject}")
        # Construct the email
        message = MIMEText(message_text)
        message["to"] = to_email
        message["subject"] = subject

        # Encode the message to base64 URL-safe string
        raw_message = base64.urlsafe_b64encode(message.as_bytes()).decode("utf-8")

        # Gmail API endpoint
        url = "https://gmail.googleapis.com/gmail/v1/users/me/messages/send"
        headers = {"Authorization": f"Bearer {access_token}", "Content-Type": "application/json"}
        body = {"raw": raw_message}

        async with aiohttp.ClientSession() as session:
            logger.info(f"Calling Gmail API to send email")
            async with session.post(url, headers=headers, json=body) as resp:
                logger.info(f"Gmail API send email response status: {resp.status}")
                # Check for 401/UNAUTHENTICATED errors and raise to trigger upstream logic 
                # (though in this new pattern, the token should already be fresh)
                if resp.status not in (200, 201):
                    text = await resp.text()
                    logger.error(f"Error sending email: {text}")
                    raise HTTPException(status_code=resp.status, detail=f"Gmail send error: {text}")
                result = await resp.json()
                logger.info(f"Successfully sent email")
                return result
    except Exception as e:
        logger.exception(f"Unexpected error in send_gmail_message: {str(e)}")
        raise
        
SENDER_EMAIL = "me" # Replace with the actual sender's email (e.g., current_user.email)

async def reply_to_gmail_message(access_token: str, message_id: str, message_text: str):
    try:
        logger.info(f"Replying to email {message_id}")
        # Validate the message ID to prevent reserved keywords from being used
        reserved_keywords = ['spam', 'drafts', 'trash', 'inbox', 'sent', 'starred']
        if message_id.lower() in reserved_keywords:
            raise HTTPException(status_code=400, detail=f"Invalid message ID: '{message_id}' is a reserved keyword")
            
        # --- STEP 1: Fetch Original Message Metadata (CRITICAL for threadId and Recipient) ---
        metadata_url = f"https://gmail.googleapis.com/gmail/v1/users/me/messages/{message_id}?format=metadata&metadataHeaders=From"
        
        headers = {"Authorization": f"Bearer {access_token}"}
        
        async with aiohttp.ClientSession() as session:
            logger.info(f"Fetching original message metadata for {message_id}")
            async with session.get(metadata_url, headers=headers) as resp:
                logger.info(f"Gmail API metadata response status: {resp.status}")
                if resp.status != 200:
                    text = await resp.text()
                    # If we can't find the message, we can't reply to it.
                    logger.error(f"Error fetching original message metadata: {text}")
                    raise HTTPException(status_code=resp.status, detail=f"Failed to retrieve original message metadata: {text}")
                
                original_metadata = await resp.json()
        
        # 1a. Extract the correct threadId
        thread_id = original_metadata.get("threadId")
        if not thread_id:
            logger.error("Original message metadata is missing threadId")
            raise HTTPException(status_code=500, detail="Original message metadata is missing threadId.")

        # 1b. Extract the recipient address (the sender of the original email)
        recipient_address = None
        for header in original_metadata.get("payload", {}).get("headers", []):
            if header["name"].lower() == "from":
                # The 'From' header of the original message is the 'To' header of the reply
                recipient_address = header["value"]
                break
                
        if not recipient_address:
            logger.error("Could not determine recipient address from original message metadata")
            raise HTTPException(status_code=500, detail="Could not determine recipient address from original message metadata.")

        # --- STEP 2: Construct the Correct MIME Message ---
        
        # The MIMEText object requires the 'Subject' and 'To' fields
        reply_body = MIMEText(message_text)
        
        # FIX 1: Add the required 'To' and 'From' headers
        reply_body["To"] = recipient_address 
        reply_body["From"] = SENDER_EMAIL # This MUST be the authenticated user's email
        
        # Optional but highly recommended for better threading visualization
        reply_body["In-Reply-To"] = original_metadata.get("id") # Use the message_id (if 'Message-ID' header not available)
        reply_body["References"] = original_metadata.get("id")

        # The subject line should be the same as the one determined in your frontend or fetched here
        reply_body["Subject"] = "Re: " + original_metadata.get("snippet", "")[:30] 
        
        raw_message = base64.urlsafe_b64encode(reply_body.as_bytes()).decode("utf-8")

        # --- STEP 3: Send the Reply with the Correct threadId ---
        
        url = "https://gmail.googleapis.com/gmail/v1/users/me/messages/send"
        final_body = {
            "raw": raw_message,
            # FIX 2: Use the correctly fetched thread_id
            "threadId": thread_id 
        }

        async with aiohttp.ClientSession() as session:
            logger.info(f"Sending reply to {message_id}")
            async with session.post(url, headers=headers, json=final_body) as resp:
                logger.info(f"Gmail API reply response status: {resp.status}")
                if resp.status not in (200, 201):
                    text = await resp.text()
                    # This will now give you a more detailed error if the problem persists
                    logger.error(f"Error sending reply: {text}")
                    raise HTTPException(status_code=resp.status, detail=f"Gmail reply error: {text}")
                result = await resp.json()
                logger.info(f"Successfully sent reply to {message_id}")
                return result
    except Exception as e:
        logger.exception(f"Unexpected error in reply_to_gmail_message: {str(e)}")
        raise
        
async def forward_gmail_message(access_token: str, original_message_id: str, to_email: str, forward_note: str = ""):
    try:
        logger.info(f"Forwarding email {original_message_id} to {to_email}")
        # Validate the message ID to prevent reserved keywords from being used
        reserved_keywords = ['spam', 'drafts', 'trash', 'inbox', 'sent', 'starred']
        if original_message_id.lower() in reserved_keywords:
            raise HTTPException(status_code=400, detail=f"Invalid message ID: '{original_message_id}' is a reserved keyword")
            
        headers = {"Authorization": f"Bearer {access_token}"}
        get_url = f"https://gmail.googleapis.com/gmail/v1/users/me/messages/{original_message_id}?format=full"

        async with aiohttp.ClientSession() as session:
            # Step 1: Get the original message details
            logger.info(f"Fetching original message {original_message_id} for forwarding")
            async with session.get(get_url, headers=headers) as get_resp:
                logger.info(f"Gmail API fetch original message response status: {get_resp.status}")
                if get_resp.status != 200:
                    text = await get_resp.text()
                    logger.error(f"Error fetching original message: {text}")
                    raise HTTPException(status_code=get_resp.status, detail=f"Failed to fetch original message: {text}")
                original_data = await get_resp.json()

            payload = original_data.get("payload", {})
            headers_list = payload.get("headers", [])
            subject = next((h["value"] for h in headers_list if h["name"].lower() == "subject"), "No Subject")
            from_email = next((h["value"] for h in headers_list if h["name"].lower() == "from"), "Unknown Sender")

            forward_body = f"---------- Forwarded message ----------\nFrom: {from_email}\nSubject: {subject}\n\n{forward_note}"

            message = MIMEText(forward_body)
            message["to"] = to_email
            message["subject"] = f"Fwd: {subject}"

            raw_message = base64.urlsafe_b64encode(message.as_bytes()).decode("utf-8")
            send_url = "https://gmail.googleapis.com/gmail/v1/users/me/messages/send"

            logger.info(f"Sending forwarded message")
            async with session.post(send_url, headers=headers, json={"raw": raw_message}) as send_resp:
                logger.info(f"Gmail API forward message response status: {send_resp.status}")
                if send_resp.status not in (200, 201):
                    text = await send_resp.text()
                    logger.error(f"Error forwarding message: {text}")
                    raise HTTPException(status_code=send_resp.status, detail=f"Gmail forward error: {text}")
                result = await send_resp.json()
                logger.info(f"Successfully forwarded message {original_message_id} to {to_email}")
                return result
    except Exception as e:
        logger.exception(f"Unexpected error in forward_gmail_message: {str(e)}")
        raise

