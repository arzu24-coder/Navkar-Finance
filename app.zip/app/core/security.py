from jose import jwt, JWTError
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from app.config import settings
from bson import ObjectId
from app.database.async_db import get_async_database

from app.database.repositories.token_blacklist import TokenBlacklistRepository
from app.database.repositories.user_repository import UserRepository
from app.models.auth import TokenData, UserInfo

# Function to create a temporary admin user for testing purposes
def create_temporary_admin_user(user_id: str) -> UserInfo:
    """
    Create a temporary admin user for testing purposes when the database
    has issues or when the user cannot be found in the database.
    """
    print(f"Creating temporary admin user with ID: {user_id}")
    return UserInfo(
        id=user_id,
        username="temp_admin",
        email="admin@example.com",
        full_name="Temporary Admin",
        roles=["admin", "hr_manager"]  # Give all necessary roles for testing
    )

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/login")

def verify_token(token: str):
    """Verify a JWT token and check if it's blacklisted"""
    try:
        # First check if the token is blacklisted
        token_blacklist_repo = TokenBlacklistRepository()
        if token_blacklist_repo.is_blacklisted(token):
            print(f"Token is blacklisted: {token[:10]}...")
            raise JWTError("Token has been revoked")
        
        # Then verify the token signature and decode it
        payload = jwt.decode(
            token, 
            settings.SECRET_KEY, 
            algorithms=[settings.ALGORITHM],
            options={"verify_signature": True}
        )
        
        # Log successful token verification
        print(f"Token verified successfully for user ID: {payload.get('sub')}")
        return payload
    except JWTError as e:
        print(f"Token verification JWT error: {str(e)}")
        raise
    except Exception as e:
        print(f"Token verification error: {str(e)}")
        raise JWTError(f"Token verification failed: {str(e)}")