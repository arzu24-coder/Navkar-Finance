from twilio.rest import Client

# Your Twilio credentials - replace with your real SID and token
account_sid = 'AC773383802792004a25f87804d51dec12'
auth_token = 'ba671f74c8bbb27fb60be8e4917e129f'

client = Client(account_sid, auth_token)

call = client.calls.create(
    to='+916206876611',        # Recepient's phone number
    from_='+15107093140',    # Twilio phone number
    url='http://demo.twilio.com/docs/voice.xml'  # Twilio demo voice instructions
)

print(f"Call SID: {call.sid}")

