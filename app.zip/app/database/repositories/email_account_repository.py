from typing import Optional, Dict, Any
from motor.motor_asyncio import AsyncIOMotorDatabase, AsyncIOMotorClient
from app.database.async_db import get_async_database  # assume you have this
from bson.objectid import ObjectId
import datetime
import logging

logger = logging.getLogger(__name__)


class EmailAccountRepository:
    def __init__(self, db: Optional[AsyncIOMotorDatabase] = None):
        self.db = db or get_async_database()
        if self.db is not None:
            self.collection = self.db["email_accounts"]  # MongoDB collection name
        else:
            self.collection = None

    async def get_by_email(self, email: str):
        try:
            if self.db is None:
                self.db = get_async_database()
                if self.db is not None:
                    self.collection = self.db["email_accounts"]
            
            if self.db is None or self.collection is None:
                logger.error("Database connection not available")
                return None
                
            logger.info(f"Looking up email account for: {email}")
            
            # Fix: Ensure we're getting the most recent account data
            # Sort by updated_at to get the latest entry for this email
            result = await self.collection.find_one(
                {"email": email}, 
                sort=[("updated_at", -1)]  # Get the most recently updated record
            )
            logger.info(f"Database lookup result for {email}: {result}")
            if result:
                result["id"] = str(result["_id"])
            return result
        except Exception as e:
            logger.exception(f"Error in get_by_email for {email}: {str(e)}")
            return None
            
    async def get_by_user_id(self, user_id: str):
        try:
            if self.db is None:
                self.db = get_async_database()
                if self.db is not None:
                    self.collection = self.db["email_accounts"]
            
            if self.db is None or self.collection is None:
                logger.error("Database connection not available")
                return None
                
            logger.info(f"Looking up email account for user_id: {user_id}")
            
            # First try to find by application user_id
            result = await self.collection.find_one(
                {"user_id": user_id}, 
                sort=[("updated_at", -1)]  # Get the most recently updated record
            )
            logger.info(f"First lookup result for user_id {user_id}: {result}")
            
            # If not found, try to find by Google user_id (sub field)
            if not result:
                result = await self.collection.find_one(
                    {"google_user_id": user_id}, 
                    sort=[("updated_at", -1)]  # Get the most recently updated record
                )
                logger.info(f"Second lookup result for google_user_id {user_id}: {result}")
            
            # If still not found, try to find by email (in case user_id is actually an email)
            if not result:
                result = await self.collection.find_one(
                    {"email": user_id}, 
                    sort=[("updated_at", -1)]  # Get the most recently updated record
                )
                logger.info(f"Third lookup result for email {user_id}: {result}")
            
            logger.info(f"Database lookup result for user_id {user_id}: {result}")
            if result:
                result["id"] = str(result["_id"])
            return result
        except Exception as e:
            logger.exception(f"Error in get_by_user_id for {user_id}: {str(e)}")
            return None

    async def update_access_token(self, email: str, access_token: str, expires_in: int):
        import datetime
        expires_at = datetime.datetime.utcnow() + datetime.timedelta(seconds=expires_in)
        try:
            if self.db is None:
                self.db = get_async_database()
                if self.db is not None:
                    self.collection = self.db["email_accounts"]
            
            if self.db is None or self.collection is None:
                return 0
                
            result = await self.collection.update_one(
                {"email": email},
                {"$set": {"access_token": access_token, "expires_at": expires_at.isoformat()}}
            )
            return result.modified_count
        except Exception as e:
            logger.exception(f"Error in update_access_token for {email}: {str(e)}")
            return 0

    async def create_account(self, email: str, refresh_token: str, user_id: Optional[str] = None):
        try:
            now = datetime.datetime.utcnow()
            account = {
                "email": email,
                "refresh_token": refresh_token,
                "access_token": None,
                "access_token_expiry": None,
                "user_id": user_id,
                "created_at": now,
                "updated_at": now
            }
            if self.db is None:
                self.db = get_async_database()
                if self.db is not None:
                    self.collection = self.db["email_accounts"]
            
            if self.db is None or self.collection is None:
                raise Exception("Database connection not available")
                
            result = await self.collection.insert_one(account)
            return str(result.inserted_id)
        except Exception as e:
            logger.exception(f"Error in create_account for {email}: {str(e)}")
            raise

    async def delete_account(self, email: str):
        try:
            if self.db is None:
                self.db = get_async_database()
                if self.db is not None:
                    self.collection = self.db["email_accounts"]
            
            if self.db is None or self.collection is None:
                return False
                
            result = await self.collection.delete_one({"email": email})
            return result.deleted_count > 0
        except Exception as e:
            logger.exception(f"Error in delete_account for {email}: {str(e)}")
            return False