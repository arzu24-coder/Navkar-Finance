# app/database/repositories/lead_repository.py
from datetime import datetime
from typing import List, Optional
from app.database import leads_collection, users_collection, serialize_id, get_object_id, find_lead_by_id_or_lead_id
from bson.objectid import ObjectId
import re

class LeadRepository:
    def __init__(self):
        self.collection = leads_collection()
        
    def create_lead(self, lead_data: dict) -> Optional[dict]:
        try:
            current_time = datetime.now()
            lead_data["created_at"] = current_time
            lead_data["updated_at"] = current_time
            
            for field in ["assigned_to", "created_by"]:
                if field in lead_data and lead_data[field] and isinstance(lead_data[field], str):
                    try:
                        lead_data[field] = ObjectId(lead_data[field])
                    except Exception as e:
                        print(f"[WARN] Could not convert {field} to ObjectId: {str(e)}")
            
            result = self.collection.insert_one(lead_data)
            if not result.acknowledged:
                print("[ERROR] MongoDB insert was not acknowledged")
                return None
                
            inserted_id = result.inserted_id
            created_lead = self.collection.find_one({"_id": inserted_id})
            if not created_lead:
                print(f"[ERROR] Could not retrieve newly created lead with ID {inserted_id}")
                return None
                
            return serialize_id(created_lead)
            
        except Exception as e:
            print(f"[ERROR] Exception while creating lead: {str(e)}")
            import traceback
            traceback.print_exc()
            return None
    
    def get_lead_by_id(self, lead_id: str) -> Optional[dict]:
        lead = find_lead_by_id_or_lead_id(lead_id)
        if lead and lead.get("assigned_to"):
            user = users_collection.find_one({"_id": get_object_id(lead["assigned_to"])})
            if user:
                lead["assigned_to_name"] = user.get("username")
        return serialize_id(lead) if lead else None
    
    def get_lead_by_email(self, email: str) -> Optional[dict]:
        if not email:
            return None
        try:    
            lead = self.collection.find_one({"email": {"$regex": f"^{re.escape(email)}$", "$options": "i"}})
            if lead:
                return serialize_id(lead)
            return None
        except Exception as e:
            print(f"[ERROR] Error finding lead by email: {str(e)}")
            return None
        
    def get_lead_by_phone(self, phone: str) -> Optional[dict]:
        if not phone:
            return None
        try:
            clean_phone = re.sub(r'\D', '', phone)
            if not clean_phone:
                return None
                
            leads = self.collection.find({
                "$or": [
                    {"phone": {"$exists": True}},
                    {"alternate_phone": {"$exists": True}}
                ]
            })
            for lead in leads:
                lead_phone = re.sub(r'\D', '', lead.get("phone", ""))
                alternate_phone = re.sub(r'\D', '', lead.get("alternate_phone", ""))
                if clean_phone == lead_phone or clean_phone == alternate_phone:
                    return serialize_id(lead)
            return None
        except Exception as e:
            print(f"[ERROR] Error finding lead by phone: {str(e)}")
            return None
    
    def list_leads(self, filters: dict = None, skip: int = 0, limit: int = 100) -> List[dict]:
        if filters is None:
            filters = {}
        cursor = self.collection.find(filters).skip(skip).limit(limit).sort("created_at", -1)
        leads = list(cursor)
        
        unique_leads = {}
        for lead in leads:
            lead_id = str(lead.get("_id"))
            if lead_id not in unique_leads:
                unique_leads[lead_id] = lead
        
        leads = list(unique_leads.values())
        
        user_ids = []
        for lead in leads:
            if lead.get("assigned_to") and lead["assigned_to"] not in user_ids:
                user_ids.append(lead["assigned_to"])
        
        users = {}
        if user_ids:
            valid_user_ids = [get_object_id(uid) for uid in user_ids if uid]
            if valid_user_ids:
                user_objects = list(users_collection.find({"_id": {"$in": valid_user_ids}}))
                for user in user_objects:
                    users[str(user["_id"])] = user.get("username")
        
        for lead in leads:
            if lead.get("assigned_to") and lead["assigned_to"] in users:
                lead["assigned_to_name"] = users[lead["assigned_to"]]
            else:
                lead["assigned_to_name"] = None
        
        return [serialize_id(lead) for lead in leads]
    
    def update_lead(self, lead_id: str, update_data: dict) -> bool:
        lead = find_lead_by_id_or_lead_id(lead_id)
        if not lead:
            return False
        object_id = lead["_id"]
        update_data["updated_at"] = datetime.now()
        result = self.collection.update_one({"_id": object_id}, {"$set": update_data})
        return result.modified_count > 0
    
    def update_lead_status(self, lead_id: str, status: str) -> bool:
        return self.update_lead(lead_id, {"status": status})
    
    def delete_lead(self, lead_id: str) -> bool:
        lead = find_lead_by_id_or_lead_id(lead_id)
        if not lead:
            return False
        object_id = lead["_id"]
        result = self.collection.delete_one({"_id": object_id})
        return result.deleted_count > 0


# --- CallLogRepository (new repository for call logs) ---

from app.database import call_logs_collection, serialize_id

class CallLogRepository:
    def __init__(self):
        self.collection = call_logs_collection()

    def create_call_log(self, call_log_data: dict) -> Optional[dict]:
        try:
            current_time = datetime.now()
            call_log_data["created_at"] = current_time
            call_log_data["updated_at"] = current_time
            
            if "created_by" in call_log_data and isinstance(call_log_data["created_by"], str):
                try:
                    call_log_data["created_by"] = ObjectId(call_log_data["created_by"])
                except Exception:
                    pass
            
            result = self.collection.insert_one(call_log_data)
            if not result.acknowledged:
                return None
            
            inserted = self.collection.find_one({"_id": result.inserted_id})
            return serialize_id(inserted)
        except Exception as e:
            print(f"[ERROR] Exception while creating call log: {str(e)}")
            return None
    
    def get_call_log_by_sid(self, sid: str) -> Optional[dict]:
        if not sid:
            return None
        try:
            log = self.collection.find_one({"twilio_sid": sid})
            return serialize_id(log) if log else None
        except Exception as e:
            print(f"[ERROR] Exception fetching call log by sid: {str(e)}")
            return None

    def get_call_logs_by_phone(self, phone: str) -> List[dict]:
        try:
            clean_phone = re.sub(r'\D', '', phone)
            cursor = self.collection.find({
                "$or": [
                    {"caller": {"$regex": clean_phone}},
                    {"recipient": {"$regex": clean_phone}}
                ]
            }).sort("call_start", -1)
            return [serialize_id(log) for log in cursor]
        except Exception as e:
            print(f"[ERROR] Exception fetching call logs by phone: {str(e)}")
            return []

    def get_recent_call_logs(self, limit: int = 20) -> List[dict]:
        try:
            cursor = self.collection.find({}, sort=[("created_at", -1)], limit=limit)
            call_logs = list(cursor)
            return [serialize_id(log) for log in call_logs]
        except Exception as e:
            print(f"[ERROR] Exception fetching recent call logs: {str(e)}")
            return []
        
    def get_call_logs_by_type(self, filter_type: str, limit: int = 20) -> List[dict]:
        try:
            query = {"call_type": filter_type}
            cursor = self.collection.find(query, sort=[("created_at", -1)], limit=limit)
            call_logs = list(cursor)
            return [serialize_id(log) for log in call_logs]
        except Exception as e:
            print(f"[ERROR] Exception fetching call logs by type: {str(e)}")
            return []
        
    def delete_all_call_logs(self):
        result = self.collection.delete_many({})
        return result.deleted_count