from datetime import datetime
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, EmailStr, Field, validator
from fastapi import Depends
from app.database import roles_collection

class FixedLocationModel(BaseModel):
    latitude: float
    longitude: float
    address: Optional[str] = None
    updated_at: datetime


class UserBase(BaseModel):
    username: str = Field(..., description="Username")
    email: EmailStr = Field(..., description="Email address")
    full_name: str = Field(..., description="Full name")
    phone: Optional[str] = Field(None, description="Phone number")
    department: Optional[str] = Field(None, description="Department")
    is_active: bool = Field(True, description="Active status")
    fixed_location: Optional[FixedLocationModel] = Field(None, description="Employee fixed office location")


class UserCreate(UserBase):
    password: str = Field(..., description="Password")
    role_ids: List[str] = Field(default_factory=list, description="Role IDs")


class UserResponse(BaseModel):
    id: str = Field(..., description="User ID")
    username: str = Field(..., description="Username")
    email: str = Field(..., description="Email address")
    full_name: Optional[str] = Field(None, description="Full name")
    phone: Optional[str] = Field(None, description="Phone number")
    department: Optional[str] = Field(None, description="Department")
    roles: List[Dict[str, str]] = Field(default_factory=list, description="User roles")
    permissions: List[str] = Field(default_factory=list, description="User permissions")
    is_active: bool = Field(True, description="Active status")
    fixed_location: Optional[FixedLocationModel] = Field(None, description="Employee fixed office location")
    created_at: datetime = Field(..., description="Creation timestamp")
    updated_at: Optional[datetime] = Field(None, description="Last update timestamp")
    
    class Config:
        from_attributes = True
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }


class UserInDB(UserBase):
    """Internal model for user with hashed password"""
    id: Optional[str] = Field(None, description="User ID")
    hashed_password: str = Field(..., description="Hashed password")
    role_ids: List[str] = Field(default_factory=list, description="Role IDs")
    created_at: datetime = Field(default_factory=datetime.now, description="Creation timestamp")
    last_login: Optional[datetime] = Field(None, description="Last login timestamp")
    
    class Config:
        validate_assignment = True


class UserUpdate(BaseModel):
    """Model for updating a user (all fields optional)"""
    id: Optional[str] = Field(None, description="User ID")
    username: Optional[str] = Field(None, description="Username")
    email: Optional[EmailStr] = Field(None, description="Email address")
    password: Optional[str] = Field(None, description="Password")
    full_name: Optional[str] = Field(None, description="Full name")
    phone: Optional[str] = Field(None, description="Phone number")
    department: Optional[str] = Field(None, description="Department")
    is_active: Optional[bool] = Field(None, description="Active status")
    role_ids: Optional[List[str]] = Field(None, description="Role IDs")
    roles: Optional[Any] = Field(None, description="User roles")
    reporting_user_id: Optional[str] = Field(None, description="Reporting user ID")
    fixed_location: Optional[FixedLocationModel] = Field(None, description="Employee fixed office location")
    
    class Config:
        validate_assignment = True
        arbitrary_types_allowed = True
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }


class PasswordReset(BaseModel):
    """Model for password reset request"""
    email: EmailStr = Field(..., description="Email address")


class PasswordChange(BaseModel):
    """Model for changing user password"""
    old_password: str = Field(..., description="Old password")
    new_password: str = Field(..., description="New password")


class RefreshTokenRequest(BaseModel):
    refresh_token: str


def map_roles(role_ids, roles_collection):
    """
    Map a list of role_ids to a list of {id, name} dicts using the roles collection.
    """
    if isinstance(role_ids, str):
        role_ids = [role_ids]
    if not role_ids:
        return []
    result = []
    for rid in role_ids:
        role = roles_collection.find_one({"id": rid})
        if role:
            result.append({"id": role["id"], "name": role["name"]})
        else:
            result.append({"id": rid, "name": rid})
    return result


def user_entity(user, roles_collection):
    # Get permissions list
    permissions = user.get("permissions", [])
    if not isinstance(permissions, list):
        permissions = []
    
    return {
        "id": str(user.get("_id", "")),
        "username": user.get("username", ""),
        "email": user.get("email", ""),
        "full_name": user.get("full_name", ""),
        "phone": user.get("phone", ""),
        "department": user.get("department", ""),
        "is_active": user.get("is_active", True),
        "roles": map_roles(user.get("role_ids", []), roles_collection),
        "permissions": permissions,
        "fixed_location": user.get("fixed_location"),
        "created_at": user.get("created_at"),
        "updated_at": user.get("updated_at"),
        "last_login": user.get("last_login", None),
    }


def user_list_entity(users) -> List[Dict[str, Any]]:
    """Convert a list of MongoDB user documents to UserResponse-compatible dictionaries"""
    # This function needs the roles_collection parameter, but it's not available here
    # We'll need to handle this differently in the actual implementation
    return [user_entity(user, None) for user in users]


def _get_roles_from_role_ids(role_ids: List[str]) -> List[Dict[str, str]]:
    roles = []
    seen = set()
    for rid in role_ids or []:
        if rid in seen:
            continue
        seen.add(rid)
        doc = (
            roles_collection.find_one({"id": rid})
            or roles_collection.find_one({"role_id": rid})
        )
        if doc:
            roles.append({
                "id": doc.get("id", doc.get("role_id", rid)),
                "name": doc.get("name", rid)
            })
        else:
            roles.append({"id": rid, "name": rid})
    return roles