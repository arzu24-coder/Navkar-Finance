# from pydantic import BaseModel, Field
# from typing import Optional, List, Dict
# from datetime import datetime

# class DocumentBase(BaseModel):
#     type: str  # e.g., "MoU", "quotation", "receipt"
#     generated_for: str  # e.g., entity id (franchise, lead, invoice)
#     template_data: Dict = Field(default_factory=dict)
#     pdf_url: str
#     timestamp: datetime = Field(default_factory=datetime.now)
#     linked_lead: Optional[str] = None
#     linked_franchise: Optional[str] = None
#     linked_invoice: Optional[str] = None

# class DocumentCreate(DocumentBase):
#     pass

# class DocumentModel(DocumentBase):
#     id: str


from pydantic import BaseModel, Field
from typing import Optional, Dict
from datetime import datetime

class DocumentBase(BaseModel):
    type: str  # e.g., "ID Proof", "Resume", "Educational Certificate"
    generated_for: str  # e.g., entity id (franchise, lead, invoice, user_id)
    template_data: Dict = Field(default_factory=dict)
    timestamp: datetime = Field(default_factory=datetime.now)
    linked_lead: Optional[str] = None
    linked_franchise: Optional[str] = None
    linked_invoice: Optional[str] = None
    status: Optional[str] = "pending"  # pending, approved, rejected, resubmit
    uploaded_by: Optional[str] = None  # User's name
    uploaded_by_id: Optional[str] = None  # User's ID
    description: Optional[str] = None  # Document description
    hr_comments: Optional[str] = None  # HR review comments
    reviewed_by: Optional[str] = None  # HR reviewer's name
    reviewed_at: Optional[datetime] = None  # Review timestamp

class DocumentCreate(DocumentBase):
    pass

class DocumentModel(DocumentBase):
    id: str
    pdf_url: str