from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime
from enum import Enum

class AnnouncementType(str, Enum):
    GENERAL = "General"
    POLICY = "Policy"
    EVENT = "Event"
    URGENT = "Urgent"
    SYSTEM = "System"

class AnnouncementPriority(str, Enum):
    LOW = "Low"
    MEDIUM = "Medium"
    HIGH = "High"
    CRITICAL = "Critical"

class AnnouncementStatus(str, Enum):
    DRAFT = "Draft"
    ACTIVE = "Active"
    EXPIRED = "Expired"
    ARCHIVED = "Archived"

class TargetAudience(str, Enum):
    ALL_EMPLOYEES = "All Employees"
    HR_TEAM = "HR Team"
    MANAGEMENT = "Management"
    DEVELOPMENT = "Development"
    MARKETING = "Marketing"
    SALES = "Sales"
    FINANCE = "Finance"
    CUSTOM = "Custom"

class AnnouncementCreate(BaseModel):
    title: str = Field(..., min_length=1, max_length=200, description="Announcement title")
    content: str = Field(..., min_length=1, max_length=5000, description="Announcement content")
    type: AnnouncementType = Field(default=AnnouncementType.GENERAL)
    priority: AnnouncementPriority = Field(default=AnnouncementPriority.MEDIUM)
    target_audience: TargetAudience = Field(default=TargetAudience.ALL_EMPLOYEES)
    expiry_date: Optional[datetime] = Field(None, description="Expiry date for the announcement")
    is_mandatory: bool = Field(default=False, description="Whether acknowledgment is required")
    custom_audience: Optional[List[str]] = Field(None, description="Custom list of employee IDs if target_audience is CUSTOM")
    tags: Optional[List[str]] = Field(default_factory=list, description="Tags for categorization")

class AnnouncementUpdate(BaseModel):
    title: Optional[str] = Field(None, min_length=1, max_length=200)
    content: Optional[str] = Field(None, min_length=1, max_length=5000)
    type: Optional[AnnouncementType] = None
    priority: Optional[AnnouncementPriority] = None
    target_audience: Optional[TargetAudience] = None
    expiry_date: Optional[datetime] = None
    is_mandatory: Optional[bool] = None
    status: Optional[AnnouncementStatus] = None
    custom_audience: Optional[List[str]] = None
    tags: Optional[List[str]] = None

class AnnouncementResponse(BaseModel):
    id: str = Field(..., description="Announcement ID")
    title: str
    content: str
    type: AnnouncementType
    priority: AnnouncementPriority
    status: AnnouncementStatus
    target_audience: TargetAudience
    expiry_date: Optional[datetime] = None
    is_mandatory: bool
    custom_audience: Optional[List[str]] = None
    tags: List[str] = []
    created_by: str = Field(..., description="Creator's user ID")
    created_by_name: Optional[str] = Field(None, description="Creator's name")
    created_at: datetime
    updated_at: datetime
    view_count: int = Field(default=0, description="Number of views")
    acknowledged_count: int = Field(default=0, description="Number of acknowledgments")
    pending_count: int = Field(default=0, description="Number of pending acknowledgments")

class AnnouncementAcknowledgment(BaseModel):
    announcement_id: str
    employee_id: str
    employee_name: Optional[str] = None
    acknowledged_at: datetime
    comments: Optional[str] = None

class AnnouncementAcknowledgmentCreate(BaseModel):
    announcement_id: str
    comments: Optional[str] = Field(None, max_length=1000)

class AnnouncementStats(BaseModel):
    total_announcements: int
    active_announcements: int
    draft_announcements: int
    expired_announcements: int
    mandatory_pending: int
    total_views: int
    overall_acknowledgment_rate: float

class AnnouncementTrackingResponse(BaseModel):
    announcement: AnnouncementResponse
    acknowledgments: List[AnnouncementAcknowledgment]
    pending_employees: List[dict]  # List of employees who haven't acknowledged