from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import datetime
from enum import Enum

class RoleBase(BaseModel):
    """Base role model with common fields"""
    name: str
    description: Optional[str] 
    report_to: Optional[str]   # New field for reporting hierarchy

class RoleCreate(RoleBase):
    """Model for creating a new role"""
    permissions: List[str] 
    class Config:
        validate_assignment = True

class RoleUpdate(BaseModel):
    """Model for updating a role (all fields optional)"""
    name: Optional[str] 
    description: Optional[str] 
    report_to: Optional[str] 
    permissions: Optional[List[str]] 

    class Config:
        validate_assignment = True

class RoleInDB(RoleBase):
    """Internal role model for database operations"""
    id: str 
    permissions: List[str] 
    created_at: datetime = datetime.now()
    updated_at: Optional[datetime] 
    created_by: Optional[str]

    class Config:
        validate_assignment = True

class RoleResponse(RoleBase):
    """Response model for returning role data"""
    id: str 
    permissions: List[str] 
    created_at: datetime 
    updated_at: Optional[datetime] = None

    class Config:
        validate_assignment = True
        json_encoders = {
            datetime: lambda v: v.isoformat(),
        }

class Role(str, Enum):
    SALES_EXECUTIVE = "sales_executive"
    SALES_MANAGER = "sales_manager"
    ACCOUNT_MANAGER = "account_manager"
    SUPPORT_AGENT = "support_agent"
    ADMIN = "admin"

# User model
class User(BaseModel):
    id: str
    username: str
    name: str
    email: str
    role: Role
    active: bool = True

# Helper functions for MongoDB document conversion
# def role_entity(role) -> Dict[str, Any]:
#     """Convert a MongoDB role document to a RoleResponse-compatible dictionary"""
#     return {
#         "id": str(role["_id"]),
#         "name": role["name"],
#         "description": role.get("description"),
#         "permissions": role.get("permissions", []),
#         "created_at": role.get("created_at", datetime.now()),
#         "updated_at": role.get("updated_at")
#     }

def role_entity(role) -> Dict[str, Any]:
    permissions = role.get("permissions", [])
    if isinstance(permissions, str):
        permissions = [permissions]  # ✅ normalize single string to list

    return {
        "id": role.get("id", str(role.get("_id", ""))),
        "name": role["name"],
        "description": role.get("description"),
        "report_to": role.get("report_to"),
        "permissions": permissions,
        "created_at": role.get("created_at", datetime.now()),
        "updated_at": role.get("updated_at") or None,  # ✅ safely handle missing
    }

def role_list_entity(roles) -> List[Dict[str, Any]]:
    """Convert a list of MongoDB role documents to RoleResponse-compatible dictionaries"""
    return [role_entity(role) for role in roles]

users = [
    User(id="1", username="alex_sales", name="Alex Johnson", email="alex@bharat.com", role=Role.SALES_EXECUTIVE),
    User(id="2", username="priya_sales", name="Priya Sharma", email="priya@bharat.com", role=Role.SALES_EXECUTIVE),
    User(id="3", username="raj_manager", name="Raj Patel", email="raj@bharat.com", role=Role.SALES_MANAGER),
    User(id="4", username="sarah_account", name="Sarah Khan", email="sarah@bharat.com", role=Role.ACCOUNT_MANAGER),
    User(id="5", username="vikram_support", name="Vikram Singh", email="vikram@bharat.com", role=Role.SUPPORT_AGENT),
    User(id="6", username="neha_sales", name="Neha Gupta", email="neha@bharat.com", role=Role.SALES_EXECUTIVE),
    User(id="7", username="soheru", name="Soher Admin", email="soheru@bharat.com", role=Role.ADMIN),
]