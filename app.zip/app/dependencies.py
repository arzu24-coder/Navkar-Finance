import jwt
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from typing import Dict, List, Any, Set
from bson import ObjectId
from app.database.repositories.user_repository import UserRepository
from app.models.auth import TokenData, UserInfo
from app.database.async_db import get_async_database
from app.config import settings
from datetime import datetime, timedelta
from app.core.security import verify_token
from jwt import PyJWTError as JWTError
from app.database.repositories.role_repository import RoleRepository
from app.database.repositories.user_repository import UserRepository
from app.database.repositories.permission_repository import PermissionRepository
from app.utils.timezone_utils import get_ist_now, get_ist_timestamp



SECRET_KEY = settings.SECRET_KEY
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 10080  # 7 days
REFRESH_TOKEN_EXPIRE_DAYS = 30


# OAuth2 scheme for token extraction
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/login")

# Repositories
user_repo = UserRepository()
role_repo = RoleRepository()
permission_repo = PermissionRepository()

def create_access_token(data: dict) -> str:
    """Create a new access token"""
    to_encode = data.copy()
    
    # Set token expiration using IST time
    expire = get_ist_now() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})
    
    # Create JWT token
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

def create_refresh_token(data: dict) -> str:
    """Create a new refresh token"""
    to_encode = data.copy()
    
    # Set refresh token expiration using IST time
    expire = get_ist_now() + timedelta(days=REFRESH_TOKEN_EXPIRE_DAYS) 
    to_encode.update({"exp": expire})
    
    # Create JWT token
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

from bson import ObjectId

async def get_current_user(token: str = Depends(oauth2_scheme)) -> UserInfo:
    credentials_exception = HTTPException(
        status_code=401,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )

    try:
        payload = verify_token(token)
        user_id = payload.get("sub")
        email = payload.get("email")
        username = payload.get("username")

        print(f"[DEBUG] Token payload - user_id: {user_id}, email: {email}, username: {username}")

        if not user_id and not email and not username:
            print("[ERROR] No user identifier found in token payload")
            raise credentials_exception

        db = get_async_database()
        
        # Check if database connection is available
        if db is None:
            print("[ERROR] Database connection is not available")
            raise credentials_exception

        user = None
        # Try to find user by user_id field first (most common case)
        if user_id:
            user = await db["users"].find_one({"user_id": user_id})
            if user:
                print(f"[DEBUG] Found user by user_id: {user_id}")
        
        # Fallback: try ObjectId if user_id is a valid ObjectId
        if not user and user_id:
            try:
                user = await db["users"].find_one({"_id": ObjectId(user_id)})
                if user:
                    print(f"[DEBUG] Found user by _id: {user_id}")
            except Exception as e:
                print(f"[DEBUG] Error searching by _id: {e}")
                pass
        
        # Fallback: try username
        if not user and username:
            user = await db["users"].find_one({"username": username})
            if user:
                print(f"[DEBUG] Found user by username: {username}")
        
        # Last fallback: try email
        if not user and email:
            user = await db["users"].find_one({"email": email})
            if user:
                print(f"[DEBUG] Found user by email: {email}")

        # If user is still not found, create a temporary user for testing
        if not user:
            print(f"[WARNING] User not found in database. Creating temporary user. user_id: {user_id}, email: {email}, username: {username}")
            # Create a temporary user if not found in database
            # This is useful for testing or when database is not available
            return UserInfo(
                id=user_id or email or username or "unknown",
                username=username or email or "unknown_user",
                email=email or username or "unknown@example.com",
                full_name="Temporary User",
                roles=["user"]
            )

        # Ensure full_name is properly set
        full_name = user.get("full_name", "")
        if not full_name:
            full_name = user.get("name", user.get("username", "User"))
            
        # Ensure roles is properly set
        roles = user.get("roles", [])
        if not roles:
            roles = ["user"]  # Default to user role
        elif isinstance(roles, str):
            roles = [roles]
        elif not isinstance(roles, list):
            roles = ["user"]
            
        print(f"[DEBUG] Returning user info for user: {user.get('username', 'unknown')}")
        return UserInfo(
            id=str(user["_id"]),
            username=user.get("username", ""),
            email=user.get("email", ""),
            full_name=full_name,
            roles=roles
        )
    except Exception as e:
        print(f"[ERROR] Exception in get_current_user: {str(e)}")
        raise credentials_exception

async def get_current_active_user(current_user: Dict[str, Any] = Depends(get_current_user)) -> Dict[str, Any]:
    """Get current active user"""
    if not current_user.get("is_active", True):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Inactive user"
        )
    return current_user


async def get_current_user_id(current_user: Dict[str, Any] = Depends(get_current_user)) -> str:
    """Get current user ID as string"""
    # First try to get user_id from token data (preferred)
    if "token_data" in current_user and "sub" in current_user["token_data"]:
        return current_user["token_data"]["sub"]
    
    # Fallback: try user_id field from user document
    user_id = current_user.get("user_id")
    if user_id is not None:
        return str(user_id)
    
    # Last fallback: try _id field
    user_id = current_user.get("_id")
    if user_id is not None:
        return str(user_id)
    
    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not extract user ID"
    )


class RoleChecker:
    """Check if user has required roles"""
    def __init__(self, allowed_roles: List[str]):
        self.allowed_roles = allowed_roles
    
    async def __call__(self, current_user = Depends(get_current_user)) -> Dict[str, Any]:
        # Get user roles from multiple sources to ensure compatibility
        user_roles = []
        
        # Check roles from token_data
        token_roles = current_user.get("token_data", {}).get("roles", [])
        if isinstance(token_roles, list):
            user_roles.extend(token_roles)
        elif isinstance(token_roles, str):
            user_roles.append(token_roles)
        
        # Check roles from user object directly
        direct_roles = current_user.get("roles", [])
        if isinstance(direct_roles, list):
            user_roles.extend(direct_roles)
        elif isinstance(direct_roles, str):
            user_roles.append(direct_roles)
        
        # Check role field
        role_field = current_user.get("role")
        if role_field and isinstance(role_field, str):
            user_roles.append(role_field)
        
        # Convert all roles to lowercase for case-insensitive comparison
        user_roles = [role.lower() for role in user_roles if role]
        
        # Debug logging
        print(f"[DEBUG] RoleChecker - User roles: {user_roles}")
        print(f"[DEBUG] RoleChecker - Allowed roles: {self.allowed_roles}")
        
        # Check if any of the user's roles is in the allowed roles
        for role in user_roles:
            if role in self.allowed_roles or role in [r.lower() for r in self.allowed_roles]:
                print(f"[DEBUG] RoleChecker - Access granted for role: {role}")
                return current_user
        
        # If no match found, raise access denied with dynamic error message
        allowed_roles_str = ", ".join(self.allowed_roles)
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"Access denied. {allowed_roles_str} role required."
        )


class PermissionChecker:
    """Check if user has required permissions"""
    def __init__(self, resource: str, required_actions: List[str]):
        self.resource = resource
        self.required_actions = required_actions
    
    async def __call__(self, current_user: Dict[str, Any] = Depends(get_current_user)) -> Dict[str, Any]:
        # Get user roles
        role_ids = current_user.get("role_ids", [])
        if not role_ids:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="User has no assigned roles"
            )
        
        # Special case: admin role always has all permissions
        user_roles = current_user.get("token_data", {}).get("roles", [])
        if "admin" in user_roles:
            return current_user
        
        # Get all permissions from roles
        has_permission = False
        roles = role_repo.get_roles_by_ids(role_ids)
        
        for role in roles:
            permission_ids = role.get("permissions", [])
            permissions = permission_repo.get_permissions_by_codes(permission_ids)
            
            for perm in permissions:
                if perm["resource"] == self.resource:
                    # Check if the permission has all required actions
                    has_required_actions = all(action in perm["actions"] for action in self.required_actions)
                    if has_required_actions:
                        has_permission = True
                        break
            
            if has_permission:
                break
        
        if not has_permission:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Insufficient permissions for {self.resource}"
            )
        
        return current_user


# Common role-based dependencies
async def admin_required(current_user: Dict[str, Any] = Depends(get_current_user)) -> Dict[str, Any]:
    """Check if user has admin role"""
    # Get roles from user object and token
    roles = current_user.get("roles", [])
    token_roles = current_user.get("token_data", {}).get("roles", [])
    
    # Debug roles
    print(f"[DEBUG] User roles from user object: {roles}")
    print(f"[DEBUG] User roles from token: {token_roles}")
    
    # FIX: Ensure roles is a list
    if isinstance(roles, str):
        # If roles is a string, convert it to a list with one item
        roles = [roles]
    elif not isinstance(roles, list):
        # If roles is neither a string nor a list, set it to an empty list
        roles = []
    
    # Ensure token_roles is a list (it already seems to be, but just to be safe)
    if not isinstance(token_roles, list):
        token_roles = [token_roles] if token_roles else []
    
    # Now both roles and token_roles are lists, so we can safely concatenate them
    all_roles = set(roles + token_roles)
    
    # Check for admin role
    if "admin" not in all_roles:
        print(f"[ERROR] User {current_user.get('username')} doesn't have admin role. Available roles: {all_roles}")
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You do not have permission to create roles. Admin rights required."
        )
    
    return current_user


def sales_team_required(current_user: Dict[str, Any] = Depends(RoleChecker(["admin", "sales"]))):
    """Requires sales team or admin role"""
    return current_user


def franchise_team_required(current_user: Dict[str, Any] = Depends(RoleChecker(["admin", "franchise"]))):
    """Requires franchise team or admin role"""
    return current_user


def support_team_required(current_user: Dict[str, Any] = Depends(RoleChecker(["admin", "support"]))):
    """Requires support team or admin role"""
    return current_user


def hr_team_required(current_user: Dict[str, Any] = Depends(RoleChecker(["admin", "hr"]))):
    """Requires HR team or admin role"""
    return current_user


# Common permission-based dependencies
def can_manage_users(current_user: Dict[str, Any] = Depends(PermissionChecker("users", ["create", "update", "delete"]))):
    """Requires permission to manage users"""
    return current_user


def can_view_dashboard(current_user: Dict[str, Any] = Depends(PermissionChecker("dashboard", ["read"]))):
    """Requires permission to view dashboard"""
    return current_user
