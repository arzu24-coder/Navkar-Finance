import os
from typing import List
import jwt
from jwt import PyJWTError as JWTError
from app.database.repositories.user_repository import UserRepository
from app.models.auth import TokenData, UserInfo
from app.database.async_db import get_async_database
from app.config import settings
from datetime import datetime, timedelta
from app.core.security import verify_token
from datetime import datetime, timedelta
from typing import Dict, Any, Optional
from fastapi import HTTPException, status, Depends, Header, Request
from fastapi.security import OAuth2PasswordBearer
from bson import ObjectId
from app.database.async_db import get_async_database
from app.database.repositories.user_repository import UserRepository
from app.database.repositories.role_repository import RoleRepository
from app.utils.timezone_utils import get_ist_now, get_ist_timestamp, get_ist_timestamp_for_db

# OAuth2 scheme for token extraction
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/login")

# Get environment variables or use defaults
ACCESS_TOKEN_EXPIRE_MINUTES = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "10080"))  # Default to 7 days
REFRESH_TOKEN_EXPIRE_DAYS = int(os.getenv("REFRESH_TOKEN_EXPIRE_DAYS", "30"))

# Define SECRET_KEY and ALGORITHM directly here to avoid import errors
SECRET_KEY = os.getenv("SECRET_KEY", "your_secret_key")  # Gets the same value as in config.py
ALGORITHM = "HS256"

# Print for debugging
print(f"[DEBUG] AuthService using SECRET_KEY: {SECRET_KEY[:5]}...")

# Password salt - should be kept secret
SALT = os.getenv("PASSWORD_SALT", "some_salt_value_here")

# Function to hash a password using SHA-256
def get_password_hash(password: str) -> str:
    """Generate a hashed password using HMAC-SHA256"""
    try:
        # Use the same SECRET_KEY as your JWT to maintain consistency
        hashed = jwt.encode({"password": password}, SECRET_KEY, algorithm=ALGORITHM)
        print(f"[DEBUG] Password hashed successfully: {hashed[:20]}...")
        return hashed
    except Exception as e:
        print(f"[ERROR] Password hashing error: {str(e)}")
        # Return a fallback hash for development
        return f"password_hash_{password}"

# Function to verify password
def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify a password against a stored JWT hash"""
    # Create a hash of the provided password
    new_hash = get_password_hash(plain_password)
    # Log for debugging
    print(f"[DEBUG] Verifying password - Plain password: {plain_password[:1]}**** New hash: {new_hash[:20]}... Stored hash: {hashed_password[:20]}...")
    # Compare with stored hash
    return new_hash == hashed_password


class AuthService:
    def __init__(self):
        self.user_repo = UserRepository()
        self.role_repo = RoleRepository()
        
        self.SECRET_KEY = SECRET_KEY
        self.ALGORITHM = ALGORITHM
        self.ACCESS_TOKEN_EXPIRE_MINUTES = ACCESS_TOKEN_EXPIRE_MINUTES
        self.REFRESH_TOKEN_EXPIRE_DAYS = REFRESH_TOKEN_EXPIRE_DAYS
    
    # Use the function defined outside the class
    def verify_password(self, plain_password: str, hashed_password: str) -> bool:
        """Verify a password against a hash"""
        # Enhanced debugging
        print(f"[{get_ist_timestamp()}] Password verification attempt")
        print(f"[DEBUG] Plain password length: {len(plain_password)}")
        print(f"[DEBUG] Hashed password format: {hashed_password[:10]}... (length: {len(hashed_password)})")
        
        # Try multiple verification methods
        try:
            # Method 1: Direct JWT verification using function above
            if hashed_password.count('.') == 2:  # Simple JWT format check
                jwt_verified = verify_password(plain_password, hashed_password)
                print(f"[DEBUG] JWT verification result: {jwt_verified}")
                if jwt_verified:
                    return True
            
            # Method 2: Direct comparison (for plain text passwords in dev/test)
            if plain_password and hashed_password and plain_password == hashed_password:
                print(f"[DEBUG] Direct comparison match - THIS IS INSECURE")
                return True
            
            # Method 3: Try direct comparison with the stored hash (legacy)
            new_hash = get_password_hash(plain_password)
            direct_match = new_hash == hashed_password
            print(f"[DEBUG] Direct hash comparison: {direct_match}")
            if direct_match:
                return True
                
            # For development/testing: Accept any password for specific test accounts
            test_accounts = ["admin", "demo", "test"]
            if plain_password and (plain_password == "admin123" or plain_password == "password") and any(name in hashed_password.lower() for name in test_accounts):
                print(f"[DEBUG] Test account accepted with default password")
                return True
                
            # If none of the methods worked, log and return False
            print(f"[{get_ist_timestamp()}] All password verification methods failed")
            return False
            
        except Exception as e:
            print(f"[{get_ist_timestamp()}] Password verification error: {str(e)}")
            # For debugging only - REMOVE IN PRODUCTION:
            print(f"[DEBUG] Allowing login despite error for testing")
            return True
    
    # Use the function defined outside the class 
    def get_password_hash(self, password: str) -> str:
        """Get JWT-based password hash"""
        return get_password_hash(password)
    
    # FIX: Modified create_access_token to use direct SECRET_KEY
    def create_access_token(self, data: dict) -> str:
        """Create access token with extended expiration time"""
        to_encode = data.copy()
        
        # Use 7 days for token expiration with IST time
        expire = get_ist_now() + timedelta(days=7)
        to_encode.update({"exp": expire})
        
        # Create JWT token using direct SECRET_KEY instead of settings.SECRET_KEY
        try:
            encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
            print(f"[DEBUG] Access token created successfully")
            return encoded_jwt
        except Exception as e:
            print(f"[ERROR] Token creation error: {str(e)}")
            raise e
    
    # FIX: Modified create_refresh_token to use direct SECRET_KEY
    def create_refresh_token(self, data: dict) -> str:
        """Create refresh token with extended expiration time"""
        to_encode = data.copy()
        
        # Use 30 days for refresh token with IST time
        expire = get_ist_now() + timedelta(days=30)
        to_encode.update({"exp": expire})
        
        # Create JWT token using direct SECRET_KEY instead of settings.SECRET_KEY
        try:
            encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
            print(f"[DEBUG] Refresh token created successfully")
            return encoded_jwt
        except Exception as e:
            print(f"[ERROR] Token creation error: {str(e)}")
            raise e

    @staticmethod
    async def verify_token(token: str) -> dict:
        """Verify token using the secret key"""
        try:
            print(f"[DEBUG] Trying to verify token with SECRET_KEY...")
            payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
            print(f"[DEBUG] Successfully verified token for user: {payload.get('username', 'unknown')}")
            return payload
        except jwt.ExpiredSignatureError:
            print("[ERROR] Token has expired")
            raise ValueError("Token has expired")
        except jwt.InvalidTokenError as e:
            print(f"[ERROR] Invalid token: {str(e)}")
            raise ValueError(f"Invalid token: {str(e)}")
        except Exception as e:
            print(f"[ERROR] Token verification error: {str(e)}")
            raise ValueError(f"Token verification failed: {str(e)}")
        
    @staticmethod
    async def get_current_user(token: str = Depends(oauth2_scheme)) -> UserInfo:
        credentials_exception = HTTPException(
            status_code=401,
            detail="Could not validate credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )

        try:
            payload = await AuthService.verify_token(token)
            user_id = payload.get("sub")
            email = payload.get("email")
            username = payload.get("username")

            if not user_id and not email and not username:
                raise credentials_exception

            # Use synchronous database access instead of async
            from app.database import db
            users_collection = db["users"]

            # First try to find by user_id field (prioritizing user_id over _id)
            user = None
            if user_id:
                user = users_collection.find_one({"user_id": user_id})
            
            # Fallback: try ObjectId if possible
            if not user and user_id:
                try:
                    user = users_collection.find_one({"_id": ObjectId(user_id)})
                except Exception:
                    pass

            # Fallback: try username
            if not user and username:
                user = users_collection.find_one({"username": username})
            
            # Last fallback: try email
            if not user and email:
                user = users_collection.find_one({"email": email})

            if not user:
                # Create a temporary user for testing purposes
                print(f"[WARNING] User not found in database. Creating temporary user. user_id: {user_id}, email: {email}, username: {username}")
                return UserInfo(
                    id=user_id or email or username or "unknown",
                    username=username or email or "unknown_user",
                    email=email or username or "unknown@example.com",
                    full_name="Temporary User",
                    roles=["user"]
                )

            # Ensure full_name is properly set
            full_name = user.get("full_name", "")
            if not full_name:
                full_name = user.get("name", user.get("username", "User"))
                
            # Ensure roles is properly set
            roles = user.get("roles", [])
            if not roles:
                roles = ["user"]  # Default to user role
            elif isinstance(roles, str):
                roles = [roles]
            elif not isinstance(roles, list):
                roles = ["user"]
                
            return UserInfo(
                id=str(user["_id"]),
                username=user.get("username", ""),
                email=user.get("email", ""),
                full_name=full_name,  # This will now properly show the user's name
                roles=roles
            )
        except Exception as e:
            print(f"[ERROR] Exception in get_current_user: {str(e)}")
            raise credentials_exception

    def get_user_info(self, user_id: str) -> Optional[Dict[str, Any]]:
        """Get user information by user ID"""
        try:
            user = self.user_repo.get_user_by_id(user_id)
            if user:
                # Remove sensitive data
                if "password" in user:
                    del user["password"]
                if "hashed_password" in user:
                    del user["hashed_password"]
                return user
            return None
        except Exception as e:
            print(f"Error getting user info: {str(e)}")
            return None

    def change_password(self, user_id: str, old_password: str, new_password: str) -> bool:
        """Change user password"""
        try:
            user = self.user_repo.get_user_by_id(user_id)
            if not user:
                raise ValueError("User not found")
            
            # Verify old password
            stored_password = user.get("password") or user.get("hashed_password")
            if not stored_password:
                raise ValueError("Password not found for user")
            
            if not self.verify_password(old_password, stored_password):
                raise ValueError("Invalid old password")
            
            # Hash new password
            new_hashed_password = self.get_password_hash(new_password)
            
            # Update password
            update_result = self.user_repo.update_user(user_id, {
                "password": new_hashed_password,
                "updated_at": datetime.now()
            })
            
            return update_result
        except Exception as e:
            print(f"Error changing password: {str(e)}")
            raise ValueError(f"Failed to change password: {str(e)}")

    def refresh_token(self, refresh_token: str) -> Dict[str, Any]:
        """Use refresh token to get a new access token"""
        try:
            # Verify the refresh token
            payload = jwt.decode(refresh_token, self.SECRET_KEY, algorithms=[self.ALGORITHM])
            user_id = payload.get("sub")
            
            if not user_id:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED, 
                    detail="Invalid refresh token"
                )
                
            # Get user from database
            user = self.user_repo.get_user_by_id(user_id)
            
            if not user:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User not found"
                )
                
            # Create new tokens
            token_data = {
                "sub": user["id"],
                "username": user["username"]
            }
            
            # Add roles to token if available
            role_ids = user.get("role_ids", [])
            if role_ids:
                roles = self.role_repo.get_roles_by_ids(role_ids)
                role_names = [role.get("name") for role in roles if role]
                token_data["roles"] = role_names
                
            access_token = self.create_access_token(token_data)
            new_refresh_token = self.create_refresh_token(token_data)
            
            # Use the user_entity method to properly format the user response
            formatted_user = self.user_repo.user_entity(user)
            
            return {
                "access_token": access_token,
                "refresh_token": new_refresh_token,
                "token_type": "bearer",
                "user": formatted_user
            }
        except jwt.ExpiredSignatureError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Refresh token expired"
            )
        except jwt.PyJWTError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid refresh token"
            )
        except Exception as e:
            print(f"Refresh token error: {str(e)}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Error refreshing token"
            )

    def register_user(self, username: str, email: str, password: str, full_name: str, 
                     phone: Optional[str] = None, department: Optional[str] = None, 
                     role_ids: Optional[List[str]] = None, reporting_user_id: Optional[str] = None) -> Dict[str, Any]:
        """Register a new user"""
        try:
            # Check if user already exists
            existing_user = self.user_repo.get_user_by_username(username)
            if existing_user:
                raise ValueError("Username already exists")
            
            existing_email = self.user_repo.get_user_by_email(email)
            if existing_email:
                raise ValueError("Email already exists")
            
            # Hash password
            hashed_password = self.get_password_hash(password)
            
            # Prepare user data
            user_data = {
                "username": username,
                "email": email,
                "full_name": full_name,
                "phone": phone,
                "department": department,
                "password": hashed_password,
                "role_ids": role_ids or [],
                "is_active": True,
                "reporting_user_id": reporting_user_id
            }
            
            # Create user
            created_user = self.user_repo.create_user(user_data)
            if not created_user:
                raise ValueError("Failed to create user")
            
            # Remove sensitive data
            if "password" in created_user:
                del created_user["password"]
                
            return created_user
        except Exception as e:
            print(f"Error registering user: {str(e)}")
            raise ValueError(f"Failed to register user: {str(e)}")