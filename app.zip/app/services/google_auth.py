# app/config/google_oauth2.py
from authlib.integrations.starlette_client import OAuth
import os
import logging

logger = logging.getLogger(__name__)

oauth = OAuth()

try:
    client_id = os.getenv("GMAIL_CLIENT_ID", "731827166415-2hn36eq8pfvo6t3akpanckkln4tan4fv.apps.googleusercontent.com")
    client_secret = os.getenv("GMAIL_CLIENT_SECRET", "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")
    redirect_uri = os.getenv("GMAIL_REDIRECT_URI", "http://localhost:8005/api/auth/google/callback")


    oauth.register(
        name='gmail',
        client_id=client_id,
        client_secret=client_secret,
        access_token_url='https://oauth2.googleapis.com/token',
        redirect_uri=redirect_uri,
        authorize_url='https://accounts.google.com/o/oauth2/auth',
        server_metadata_url='https://accounts.google.com/.well-known/openid-configuration',
        api_base_url='https://www.googleapis.com/',
        userinfo_endpoint='https://www.googleapis.com/oauth2/v2/userinfo',
        client_kwargs={
            'scope': 'openid email profile https://www.googleapis.com/auth/gmail.readonly',
            'prompt': 'consent',
            'access_type': 'offline',
            'refresh_token': 'true',
        },
    )
    logger.info("✅ Gmail OAuth configured successfully")
except Exception as e:
    logger.error(f"❌ Error configuring Gmail OAuth: {str(e)}")
